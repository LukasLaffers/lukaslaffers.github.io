

mainFile.m
The main file. This file discretizes the outcome variable and calculates the bounds on ATE and reproduces the results in Table 1. It takes about …. on i7, 16GB RAM laptop.

LeeData.mat
Dataset studied in
Lee, David S. "Training, wages, and sample selection: Estimating sharp bounds on treatment effects." The Review of Economic Studies 76.3 (2009): 1071-1102.

resultsTable1.mat
Stores the results of Table 1 in array “results”.

getLeeBoundsRelaxed.m
Calculates bounds under relaxed assumptions of monotonicity and exogeneity.

getLeeConfBounds.m
Calculates confidence bounds based on subsampling Politis, Romano and Wolf (1999, Springer).



