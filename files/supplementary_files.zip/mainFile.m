% Main file for Lee (2009) Bounds Sensitivity Analysis.
% This file replicates the Table 1 in the paper.
% Laffers, Nedela (2017)

%% lee 2009 data 

clc

%Set random seed.
rng('default')

%Load data.
load LeeData;
origData = [y, sel, treatmnt, dsgn_wgt];

%Clean nonexistent wage data.
indexPopulation = ~(y==0 & sel==1);

%Select variables.
Y = y(indexPopulation);
S = sel(indexPopulation);
D = treatmnt(indexPopulation);
weight = dsgn_wgt(indexPopulation);


%% define grouping (discretization of continuous Y)
%Equidistant grouping on wages.
%Number of potential categories for wages (the actual number can be
%smaller).
mm = 300; 
groups = exp(min(Y))+((exp(max(Y))-exp(min(Y)))/mm*(1:(mm+1)));


%Sort groups.
groups = [0 groups]; %add 0
groups = unique(groups, 'sorted');


%Round data to their group means and merge empty groups
groupMeans = zeros(size(groups));
sizeGroupMeans = size(groupMeans,2);

 
i=2;
while i<=sizeGroupMeans 
    if(sum( weight .* ( Y>log(groups(i-1)) & Y<=log(groups(i)) ) ) > 0) %check if groups are nonempty
        groupMeans(i) = sum(Y .* weight .* ( Y>log(groups(i-1)) & Y<=log(groups(i))) )/sum(weight .* ( Y>log(groups(i-1)) & Y<=log(groups(i))) );
        i=i+1;
    elseif(i<sizeGroupMeans)
        groups = [groups(1:(i-1)) groups((i+1):sizeGroupMeans)]; %merge with upper
        groupMeans = [groupMeans(1:(i-1)) groupMeans((i+1):sizeGroupMeans)];
        sizeGroupMeans = size(groupMeans,2);
    else
        groups = [groups(1:(i-2)) groups(sizeGroupMeans)]; %merge with lower
        groupMeans = groupMeans(1:(i-1));
        sizeGroupMeans = size(groupMeans,2);
    end
end

disp(['The continuous Y was discretized into ', num2str(sizeGroupMeans),...
                                                ' categories.']);


%Set discretized Y values as group means.
Ygrouped = zeros(size(Y));
for i = 1:size(Y,1)
    if(Y(i)==0)
       Ygrouped(i)=0; 
    else
        for k = 2:size(groupMeans,2)
            if(Y(i)>log(groups(k-1)) && Y(i) <= log(groups(k)))
                Ygrouped(i) = groupMeans(k);
            end
        end
    end
end

%% variable support and observed probability distribution

%Support of variables.
supportOfOutcomeY = groupMeans;
supportOfSelectionS = [1 0];
supportOfPotentialY1  = supportOfOutcomeY; %Potential outcome if D=1
supportOfPotentialY0  = supportOfOutcomeY; %Potential outcome if D=0
supportOfSelectionS1  = [1 0];             %Potential selection if D=1
supportOfSelectionS0  = [1 0];             %Potential selection if D=0
supportOfTreatmentD   = [1 0];             %Treatment.

%Size of the support of variables.
sizeOfSupportOfY = size(supportOfOutcomeY,2);  %Outcome.
sizeOfSupportOfD = 2;                          %Treatment.
sizeOfSupportOfS = 2;                          %Selection.
sizeOfSupportOfYDS = sizeOfSupportOfY*sizeOfSupportOfD*sizeOfSupportOfS;

%Observed proportions.
probDistribution  = zeros(sizeOfSupportOfY, sizeOfSupportOfS, sizeOfSupportOfD); 
for y = 1:sizeOfSupportOfY
    for s = 1:sizeOfSupportOfS
        for d = 1:sizeOfSupportOfD
           probDistribution(y,s,d) = sum(weight .* (D==supportOfTreatmentD(d) & S==supportOfSelectionS(s) & Ygrouped==supportOfOutcomeY(y)))/sum(weight);
        end
    end
end



%% Estimated bounds and confidence bounds.

%Vectors with relaxation parameters
vec_alpha_e = [0 0.01 0.05];
vec_alpha_m = [0 0.01 0.05]; 

%Matrix for storing results.
results = zeros(size(vec_alpha_e,2),size(vec_alpha_m,2),4);


for iE = 1:size(vec_alpha_e,2)
    for iM = 1:size(vec_alpha_m,2)

        %Get relaxed bounds.
        %Set constraints to relaxed assumptions.
        alpha_e = vec_alpha_e(iE); %assumed max nonindependence
        disp([char(10), 'alpha_E: ',num2str(alpha_e)])

        alpha_m  = vec_alpha_m(iM); %assumed max defiers or compliers as 
                                    %specified in s1geqs0=1 or s1geqs0=0
        disp(['alpha_M: ',num2str(alpha_m)])

        s1geqs0 = 1; %assumed q defier if ==1 or q compliers if q~=1
        %(This parameter could be set to 0 in a different application where 
        %the existentce of compliers (rather than defiers) are ruled out.)

        %Bounds on ATE for AT under relaxed exogeneity and monotonicity.
        [thetaHatLow, thetaHatHigh] = getLeeBoundsRelaxed(probDistribution, ...
                        supportOfOutcomeY,s1geqs0, alpha_e, alpha_m);

        disp(['Discrete relaxed bounds on the ATE (for the alwaystakers) '...
                char(10) '  [',num2str(thetaHatLow),', ',num2str(thetaHatHigh),']']);


        %Confidence bounds (based on subsampling),
        nSubs  = 300;   %The higher the quantile the larger # of subsamples.
        alphaConf = 0.1; %1-confidence level for a two sided CB.
        [CBlow,CBhigh,thetaHatLow,thetaHatHigh] = getLeeConfBounds(origData,...
                            probDistribution, supportOfOutcomeY, groupMeans,...
                            groups, s1geqs0, alpha_e, alpha_m, nSubs, alphaConf);

        disp([ num2str(100-100*alphaConf),'\% Confidence bounds based on ',...
            'num2str(nSubs)',' subsamples', char(10) ...
            '  (',num2str(CBlow),', ',num2str(CBhigh),')']);

        toc
        
        %Store the results.
        results(iE,iM,1:4) = [thetaHatLow, thetaHatHigh, CBlow, CBhigh];
        
    end
end

%%
%Alternatively, results are stored in "resultsTable1.mat" file in array
% "results":
% load resultsTable1.mat


