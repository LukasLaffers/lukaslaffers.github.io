function [CBlow,CBhigh,thetaHatLow,thetaHatHigh] = getLeeConfBounds(origData,...
    probDistribution, supportOfOutcomeY, groupMeans, groups, s1geqs0,...
    alpha_e, alpha_m, nSubs, alphaConf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function returns confidence bounds for the 
% relaxed Lee (2009) bounds, see Laffers & Nedela (2017)
%
%INPUT:
% origData         - n-by-4 matrix of data: outcome, selection, treatment,
%                    design weights
%probDistribution  - a probability distribution of (Y,S,D) - array
%supportOfOutcomeY - a vector of support of (discrete) Y
% groupMeans       - 
% groups           - 
%s1geqs0           - binary variable indicating the direction of monotonicity 
%                    (==1 if no defiers) and (==0 if no compliers)
%alpha_e           - relaxation parameter of exogeneity
%alpha_m           - relaxation parameter of monotonicity
% nSubs            - number of subsample
% alphaConf        - 1 - confidence level
%
%OUTPUT:
%CBlow             - Lower (1-alphaConf)100% confidence bound
%CBhigh            - Upper (1-alphaConf)100% confidence bound
%thetaHatLow       - lower bound
%thetaHatHigh      - upper bound
%exitflag          - indicates the type of solution of optimization (==1
%                    succesful) or (==-2 no admissible solution found -> 
%                    bounds are empty)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


tic

%
y        = origData(:,1);
sel      = origData(:,2);
treatmnt = origData(:,3);
dsgn_wgt = origData(:,4);

%This matrix will store the results.
results = zeros(nSubs,3);

%get estimate of the bounds first
[thetaHatLow, thetaHatHigh] = getLeeBoundsRelaxed(probDistribution, supportOfOutcomeY, s1geqs0, alpha_e, alpha_m);

tic
for iSubs = 1:nSubs

    %clean nonexistent wage data
    indexPopulation = ~(y==0 & sel==1);
    
    %select variables
    Y = y(indexPopulation);
    S = sel(indexPopulation);
    D = treatmnt(indexPopulation);
    weight = dsgn_wgt(indexPopulation);

    %Variable "dataset" stores discretized data
    dataset = [Y S D weight];
    n = size(dataset,1);
    m = floor(n^0.6);       %Here we follow Demuynck (2015)
    
    %Sample _without_ replacement
    subsample = datasample(dataset,m,'Replace',false);

    Y = subsample(:,1);
    S = subsample(:,2);
    D = subsample(:,3);
    weight = subsample(:,4);


    %Set discretized Y values as group means
    Ygrouped = zeros(size(Y));
    for i = 1:size(Y,1)
        if(Y(i)==0)
           Ygrouped(i)=0; 
        else
            for k = 2:size(groupMeans,2)
                if(Y(i)>log(groups(k-1)) && Y(i)<=log(groups(k)))
                    Ygrouped(i) = groupMeans(k);
                end
            end
        end
    end

    %Support of variables
    supportOfOutcomeY = groupMeans;
    supportOfSelectionS = [1 0];
    supportOfTreatmentD = [1 0];             %Treatment.

    %Size of the support of variables.
    sizeOfSupportOfY = size(supportOfOutcomeY,2);  %Outcome.
    sizeOfSupportOfD = 2;                          %Treatment.
    sizeOfSupportOfS = 2;                          %Selection.

    %Observed proportions
    probDistribution  = zeros(sizeOfSupportOfY, sizeOfSupportOfS, sizeOfSupportOfD); 
    for iy = 1:sizeOfSupportOfY
        for is = 1:sizeOfSupportOfS
            for id = 1:sizeOfSupportOfD
               probDistribution(iy,is,id) = sum(weight .* (D==supportOfTreatmentD(id) & S==supportOfSelectionS(is) & Ygrouped==supportOfOutcomeY(iy)))/sum(weight);
            end
        end
    end


    % Get relaxed bounds.
    [f_min, f_max, exitflag] = getLeeBoundsRelaxed(probDistribution, supportOfOutcomeY, s1geqs0, alpha_e, alpha_m);
    
    %Store the results.
    results(iSubs,:) = [f_min, f_max, exitflag];
    
    %After 1% of calculations estimate the computational time.
    if iSubs == ceil(nSubs/100)
        elapsedTime = toc;
        disp(['The computation of CB will take approx. ', num2str(elapsedTime*100),' seconds.']);
    end

end


%%

%The rate of convergence is set to 0.5
%(this is in line with our simulations based on chapter 8
% Subsampling with Unknown Convergence Rate
% in Politis, Romano, Wolf: Subsampling (1999, Springer))
rate = 0.5;

%Relevant quantiles have to be adjusted for empty sets.
whichIdx = results(:,3)==1;

%Critical value for the lower bound.
zStarLow = m^rate * (results(whichIdx,1) - thetaHatLow);
critValueLow = quantile(zStarLow,1-alphaConf/mean(whichIdx));

%Critical value for the upper bound.
zStarHigh = m^rate * (results(whichIdx,2) - thetaHatHigh);
critValueHigh = quantile(zStarHigh,alphaConf/mean(whichIdx));

%Store the results.
CBlow  = thetaHatLow - critValueLow/(n^rate);
CBhigh = thetaHatHigh - critValueHigh/(n^rate);
