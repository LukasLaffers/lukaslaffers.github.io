function [thetaHatLow, thetaHatHigh,exitflag] = getLeeBoundsRelaxed(probDistribution,...
    supportOfOutcomeY, s1geqs0, alpha_e, alpha_m) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This function returns relaxed Lee (2009) bounds, see Laffers & Nedela
%(2017)
%
%INPUT:
%probDistribution  - a probability distribution of (Y,S,D) - array
%supportOfOutcomeY - a vector of support of (discrete) Y
%s1geqs0           - binary variable indicating the direction of monotonicity 
%                    (==1 if no defiers) and (==0 if no compliers)
%alpha_e           - relaxation parameter of exogeneity
%alpha_m           - relaxation parameter of monotonicity
%
%OUTPUT:
%thetaHatLow       - lower bound
%thetaHatHigh      - upper bound
%exitflag          - indicates the type of solution of optimization (==1
%                    succesful) or (==-2 no admissible solution found -> 
%                    bounds are empty)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Support of variables.
supportOfPotentialY1  = supportOfOutcomeY; %Potential outcome if D=1
supportOfPotentialY0  = supportOfOutcomeY; %Potential outcome if D=0
supportOfSelectionS1  = [1 0];             %
supportOfSelectionS0  = [1 0];             %
supportOfTreatmentD   = [1 0];             %Treatment.

%Size of the support of variables.
sizeOfSupportOfY = size(supportOfOutcomeY,2);  %Outcome.
sizeOfSupportOfD = 2;                          %Treatment.
sizeOfSupportOfS = 2;                          %Selection.
sizeOfSupportOfYDS = sizeOfSupportOfY*sizeOfSupportOfD*sizeOfSupportOfS;



                  
%Probability of observed variables (Y,S,D) is probDistribution.
PSD = sum(probDistribution); %Probability of (S,D).
PD  = sum(PSD);              %Probability of D.


%We will search in the space of joint prob distributions of 
% (Y1,Y0,S1,S0,D)
sizeOfSupportOfYYSSD = sizeOfSupportOfY^2*sizeOfSupportOfS^2*...
                        sizeOfSupportOfD;

%We will repeatedly make use of this array of zeros                    
zerosHelp            = zeros(sizeOfSupportOfY,sizeOfSupportOfY,...
                        sizeOfSupportOfS,sizeOfSupportOfS,...
                        sizeOfSupportOfD);                    

%
%__________________________________________________________________________
%The joint probability distribution Phi of (Y1,Y0,S1,S0,D) must be
% compatible with the observed distribution of (Y,D,S)
matrixDataAssumption = zeros(sizeOfSupportOfYDS,sizeOfSupportOfYYSSD);
vectorDataAssumption = zeros(sizeOfSupportOfYDS,1);
%We search through the space of (Y1,Y0,S1,S0,D) and save what values of
% observed Y,S,D the values of (Y1,Y0,S1,S0,D) imply. It will be saved in
% the following arrays.
matrixHelpY          = zerosHelp;
matrixHelpS          = zerosHelp;
matrixHelpD          = zerosHelp;

% (Y1,Y0,S1,S0,D) <-> (Y,S,D)
for y1 = 1:sizeOfSupportOfY
    for y0 = 1:sizeOfSupportOfY
        for s1 = 1:sizeOfSupportOfS
            for s0 = 1:sizeOfSupportOfS
                for d = 1:sizeOfSupportOfD
                    % S = S_1.D + S_0.(1-D)
                    matrixHelpS(y1,y0,s1,s0,d) = ...
                        supportOfSelectionS1(s1)*supportOfTreatmentD(d)+...
                        supportOfSelectionS0(s0)*(1-supportOfTreatmentD(d));
                    % Y = S.(Y_1.D + Y_0.(1-D))
                    matrixHelpY(y1,y0,s1,s0,d) = matrixHelpS(y1,y0,s1,s0,d)*...
                        (supportOfPotentialY1(y1)*supportOfTreatmentD(d)+...
                         supportOfPotentialY0(y0)*(1-supportOfTreatmentD(d)));
                end
            end
        end
    end
end

for d = 1:sizeOfSupportOfD
    matrixHelpD(:,:,:,:,d) = supportOfTreatmentD(d)*ones(sizeOfSupportOfY,...
                        sizeOfSupportOfY,sizeOfSupportOfS,sizeOfSupportOfS);
end

iPivot = 1;
for d = 1:sizeOfSupportOfD
    for s = 1:sizeOfSupportOfS
        for y = 1:sizeOfSupportOfY
            matrixHelpData      = ...
            (matrixHelpY == supportOfOutcomeY(y)).*...
            (matrixHelpS == supportOfSelectionS1(s)).*...
            (matrixHelpD == supportOfTreatmentD(d));
            matrixDataAssumption(iPivot,:) = ...
                reshape(matrixHelpData,1,sizeOfSupportOfYYSSD);
            vectorDataAssumption(iPivot) = probDistribution(y,s,d);
            iPivot = iPivot + 1;
        end
    end
end
%Now [matrixDataAssumption*Phi = vectorDataAssumption] is equivalent to 
% say that the joint distribution Phi is compatible with probDistribution

%__________________________________________________________________________
%The joint probability distribution Phi of (Y1,Y0,S1,S0,D) must be
% such that (Y1,Y0,S1,S0) is independent of D
% This is relaxed version of Treatment Exogeneity Assumption 1 in Lee (2009)
% Prob(Y1=y1,Y0=y0,S1=s1,S0=s0).Prob(D=d)=Prob(Y1=y1,Y0=y0,S1=s1,S0=s0,D=d)
% for all y1,y0,s1,s0, this is relaxed to
%|Prob(Y1=y1,Y0=y0,S1=s1,S0=s0|D=1)=Prob(Y1=y1,Y0=y0,S1=s1,S0=s0|D=0)| <= alpha_j
%j corresponds to y1,y0,s1,s0.

matrixAssumptionInd = [eye(sizeOfSupportOfYYSSD/sizeOfSupportOfD)/PD(1),...
                      -eye(sizeOfSupportOfYYSSD/sizeOfSupportOfD)/PD(2)];

sizeAlpha = size(matrixAssumptionInd,1);


%__________________________________________________________________________
%The joint probability distribution Phi of (Y1,Y0,S1,S0,D) must be
% such that S1 >= S0 with probability 1. We will relax this by settting 
% the probability of the event (S1=0,S0=1) to <=alpha_m
% This is the relaxed version of Assumption 2 in Lee (2009)

matrixAssumpSelHelp = zerosHelp;

if s1geqs0==1 
matrixAssumpSelHelp(:,:,2,1,:) = ones(sizeOfSupportOfY,sizeOfSupportOfY,...
                                    sizeOfSupportOfD);
else
matrixAssumpSelHelp(:,:,1,2,:) = ones(sizeOfSupportOfY,sizeOfSupportOfY,...
                                    sizeOfSupportOfD);    
end
                           
matrixAssumptionSel = reshape(matrixAssumpSelHelp,1,sizeOfSupportOfYYSSD);

%__________________________________________________________________________
%The joint probability distribution Phi of (Y1,Y0,S1,S0,D) must be such
%that the share of alwaystakers is theta
%Pr(S1=1,S0=1) = theta
matrixAssumpSAHelp = zerosHelp;
matrixAssumpSAHelp(:,:,1,1,:) = ones(sizeOfSupportOfY,sizeOfSupportOfY,...
                                    sizeOfSupportOfD);
matrixAssumptionSA = reshape(matrixAssumpSAHelp,1,sizeOfSupportOfYYSSD);


%__________________________________________________________________________
%Now we define ATE = E[Y_1 - Y_0] in terms of the joint probability 
% distribution Phi of (Y1,Y0,S1,S0,D)

vectorATEATHelpY1 = zerosHelp;
vectorATEATHelpY0 = zerosHelp;

for y = 1:sizeOfSupportOfY
    vectorATEATHelpY1(y,:,1,1,:) = supportOfOutcomeY(y)*ones(sizeOfSupportOfY,...
                        sizeOfSupportOfD); 
    vectorATEATHelpY0(:,y,1,1,:) = supportOfOutcomeY(y)*ones(sizeOfSupportOfY,...
                        sizeOfSupportOfD);
end


vectorATEAT = reshape(vectorATEATHelpY1 - vectorATEATHelpY0,1,sizeOfSupportOfYYSSD);
%Now [vectorATEAT*Phi = E[Y_1 - Y_0 | S_1=1, S_0=1]] 
%
%________________________________________________________________________
%Complete matrices that will enter the linear programming routine


%Note that we transform the problem in order to search for the upper/lower bounds 
% AND share of always-takers simultaneously.
%Details about this transformation are outlined in the paper.
%This means that we have a single linear program to get the bounds, which
%is fast.
                  
matrixOfEqualities = [matrixDataAssumption, zeros(sizeOfSupportOfYDS,sizeAlpha),-vectorDataAssumption;...
                      zeros(1,sizeOfSupportOfYYSSD),ones(1,sizeAlpha),-alpha_e;...
                      matrixAssumptionSA,zeros(1,sizeAlpha),0];                                

vectorOfEqualities = [zeros(sizeOfSupportOfYDS+1,1);1];



matrixOfInequalities = [matrixAssumptionInd,-eye(sizeAlpha),zeros(sizeOfSupportOfYYSSD/sizeOfSupportOfD,1);...
                        -matrixAssumptionInd,-eye(sizeAlpha),zeros(sizeOfSupportOfYYSSD/sizeOfSupportOfD,1);...
                        matrixAssumptionSel,zeros(1,sizeAlpha),-alpha_m];

vectorOfInequalities = [zeros(2*sizeOfSupportOfYYSSD/sizeOfSupportOfD + 1,1)];


%lower bound on the theta_star \equiv 1/[share_of_alwaystakers]
theta_star_lb = 1;


%________________________________________________________________________
%Create a structure called LinearProgramme.
options = optimset('linprog');
options.LargeScale = 'on';
options.Algorithm = 'interior-point';
options.Display = 'off';
LinearProgramme = struct;
LinearProgramme.f   = [vectorATEAT, zeros(1,sizeAlpha),0];
LinearProgramme.Aineq   =  matrixOfInequalities;
LinearProgramme.bineq   =  vectorOfInequalities;
LinearProgramme.Aeq = matrixOfEqualities;
LinearProgramme.beq = vectorOfEqualities;
%probs must be >=0, alpha-s must be >=0 and theta* >= theta_star_lb
LinearProgramme.lb  = [zeros(1,sizeOfSupportOfYYSSD + sizeAlpha),theta_star_lb]; 
LinearProgramme.ub  = [];
LinearProgramme.x0  = [];
LinearProgramme.solver = 'linprog';
LinearProgramme.options = options;

%Solve it.
%Lower bound.
[~,value] = linprog(LinearProgramme);
thetaHatLow = value;

%Upper bound.
LinearProgramme.f = -LinearProgramme.f;
[~,value,exitflag] = linprog(LinearProgramme);
thetaHatHigh = -value;

end