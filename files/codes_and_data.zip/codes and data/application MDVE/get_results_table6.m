
% results for Table 6

tic

results   = zeros(9,2);
resultsCI = zeros(9,2);


rng('default')
nObs     = 313;
nSamples = 1000;
SignificanceLevel = 0.9;

%generate bootstrap samples
randNums = rand(nSamples, nObs);
distributions = zeros(nSamples,16);
for iSample = 1:nSamples
    for jObs = 1:nObs
        ind = sum(randNums(iSample,jObs) > cumsum(reshape(probDistribution,16,1)))+1;
        distributions(iSample,ind) = distributions(iSample,ind) + 1;
    end
    distributions(iSample,:) = distributions(iSample,:)/nObs;
end

%calculate bounds and CIs
for iAssump = 1:9
    SignificanceLevel = 0.9;
    setOfAssumptions = iAssump;
    [bounds] = mdvelinprog_spec(probDistribution,setOfAssumptions);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(probDistribution, distributions,setOfAssumptions,nObs,SignificanceLevel);
    results  (iAssump,:) = [bounds(1),bounds(2)];
    resultsCI(iAssump,:) = [ImBiasCRlow,ImBiasCRhigh];
end


toc