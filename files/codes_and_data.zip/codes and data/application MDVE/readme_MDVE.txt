readme_MDVE.txt 			-this file

load_data.m				-loads the data

results_MDVE.mat			-stores the results for Figures 7,8 and Tables 6,7,8

mdvelinprog_spec.m			-calculates bounds on ATE
mdvelinprog_relax.m			-calculates bounds on ATE under relaxed ident. assumptions
mdvelinprog_relax_miss.m		-calculates bounds on ATE under relaxed and miss assumptions

confidenceRegionIMBoth.m		-calculates confidence region (Imbens and Manski (2004))
confidenceRegionIMBoth_relax.m 		-calculates confidence region under relaxed assumptions
confidenceRegionIMBoth_relax_miss.m 	-calculates confidence region under relaxed and miss assumptions

get_results_fig_7.m 			-obtains results for Figure 7
get_results_fig_8.m 			-obtains results for Figure 8

prodfig_7.m 				-reproduces Figure 7 in the paper
prodfig_8.m 				-reproduces Figure 8 in the paper

get_results_table6.m 			-obtains results for Table 6
get_results_table7.m 			-obtains results for Table 6
get_results_table8.m 			-obtains results for Table 6

prodtable_6.m				-reproduces Table 6 in the paper
prodtable_7.m				-reproduces Table 7 in the paper
prodtable_8.m 				-reproduces Table 8 in the paper


auxiliary files:
printfigpdf.m 				-prints figure into pdf format

