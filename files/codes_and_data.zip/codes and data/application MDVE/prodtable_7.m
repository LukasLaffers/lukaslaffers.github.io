%
% run get_results_table7.m in order to get results

load results_MDVE

%% 
%write results in tables7.tex

my_folder = pwd;
file_1 = fopen([my_folder,'/tables/tables7','.tex'],'w');

fprintf(file_1,'{\\footnotesize \n ');
fprintf(file_1,'    \\renewcommand\\multirowsetup{\\centering}\n');
fprintf(file_1,'\\begin{center}\n');
fprintf(file_1,'\\begin{tabular}{ccccccccccccccc}\n');
fprintf(file_1,'    \\noalign{\\hrule height 2pt}\n');
fprintf(file_1,'  \\multicolumn{15}{c}{} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{15}{c}{{\\bf Bounds on the Effect of an Arrest Policy on Domestic Violence Recividism}} \\vspace{1mm} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{15}{c}{{\\bf Sensitivity analysis}} \\vspace{3mm} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{15}{c}{ IND+cMIV+cROY+cCBSR \\vspace{2mm} }  \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{15}{c}{ [Lower bound, Upper bound] = [%5.1f\\%%, %5.1f\\%%] }   \\\\  \n',[100*resultsRelaxOpt(1,1), 100*resultsRelaxOpt(1,2)]); 
fprintf(file_1,'  \\multicolumn{15}{c}{ Confidence set = (%5.1f\\%%, %5.1f\\%%) \\vspace{1mm}}   \\\\  \n',[100*resultsRelaxOptCI(1,1), 100*resultsRelaxOptCI(1,2)]); 
fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,' & \\multicolumn{2}{c}{$\\alpha_{MOT}$}  & \\multicolumn{2}{c}{$\\alpha_{cMIV}$} & \\multicolumn{2}{c}{$\\alpha_{cROY}$} & \\multicolumn{2}{c}{$\\alpha_{cCBSR}$} & \\multicolumn{2}{c}{$\\alpha_{MISS}$} & \\multicolumn{2}{c}{all simultaneously} & \\multicolumn{2}{c}{all simultaneously}  \\\\  \n'); 

fprintf(file_1,' Optimistic & \\multicolumn{2}{c}{$0.001$}  & \\multicolumn{2}{c}{$0.01$} & \\multicolumn{2}{c}{$0.01$} & \\multicolumn{2}{c}{$0.01$} & \\multicolumn{2}{c}{$0.01$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0.01$}  \\\\  \n'); 
fprintf(file_1,'      & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]}  \\\\  \n',...
    [100*resultsRelaxOpt(2,1), 100*resultsRelaxOpt(2,2),100*resultsRelaxOpt(4,1), 100*resultsRelaxOpt(4,2),100*resultsRelaxOpt(5,1), 100*resultsRelaxOpt(5,2),100*resultsRelaxOpt(6,1), 100*resultsRelaxOpt(6,2),100*resultsRelaxOpt(8,1), 100*resultsRelaxOpt(8,2),100*resultsRelaxOpt(7,1), 100*resultsRelaxOpt(7,2),100*resultsRelaxOpt(9,1), 100*resultsRelaxOpt(9,2)]); 
fprintf(file_1,'      & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} \\vspace{1mm} \\\\  \n',...
    [100*resultsRelaxOptCI(2,1), 100*resultsRelaxOptCI(2,2),100*resultsRelaxOptCI(4,1), 100*resultsRelaxOptCI(4,2),100*resultsRelaxOptCI(5,1), 100*resultsRelaxOptCI(5,2),100*resultsRelaxOptCI(6,1), 100*resultsRelaxOptCI(6,2),100*resultsRelaxOptCI(8,1), 100*resultsRelaxOptCI(8,2), 100*resultsRelaxOptCI(7,1), 100*resultsRelaxOptCI(7,2),100*resultsRelaxOptCI(9,1), 100*resultsRelaxOptCI(9,2)]); 

fprintf(file_1,' Pessimistic & \\multicolumn{2}{c}{$0.01$}  & \\multicolumn{2}{c}{$0.05$} & \\multicolumn{2}{c}{$0.05$} & \\multicolumn{2}{c}{$0.05$} & \\multicolumn{2}{c}{$0.05$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0.05$}  \\\\  \n'); 
fprintf(file_1,'      & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]}  \\\\  \n',...
    [100*resultsRelaxPes(2,1), 100*resultsRelaxPes(2,2),100*resultsRelaxPes(4,1), 100*resultsRelaxPes(4,2),100*resultsRelaxPes(5,1), 100*resultsRelaxPes(5,2),100*resultsRelaxPes(6,1), 100*resultsRelaxPes(6,2),100*resultsRelaxPes(8,1), 100*resultsRelaxPes(8,2),100*resultsRelaxPes(7,1), 100*resultsRelaxPes(7,2),100*resultsRelaxPes(9,1), 100*resultsRelaxPes(9,2)]); 
fprintf(file_1,'      & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} \\vspace{1mm} \\\\  \n',...
    [100*resultsRelaxPesCI(2,1), 100*resultsRelaxPesCI(2,2),100*resultsRelaxPesCI(4,1), 100*resultsRelaxPesCI(4,2),100*resultsRelaxPesCI(5,1), 100*resultsRelaxPesCI(5,2),100*resultsRelaxPesCI(6,1), 100*resultsRelaxPesCI(6,2),100*resultsRelaxPesCI(8,1), 100*resultsRelaxPesCI(8,2), 100*resultsRelaxPesCI(7,1), 100*resultsRelaxPesCI(7,2),100*resultsRelaxPesCI(9,1), 100*resultsRelaxPesCI(9,2)]); 

fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,'  Sample size & \\multicolumn{13}{c}{} & \\multicolumn{1}{c}{313}  \\\\   \n'); 
fprintf(file_1,'  \\multicolumn{15}{l}{90\\%% confidence intervals in parentheses using the method of \\cite{im} } \\\\  \n'); 
fprintf(file_1,'    \\noalign{\\hrule height 2pt}\n');
fprintf(file_1,'  \\end{tabular}\n');
fprintf(file_1,'\\end{center}\n');
fprintf(file_1,'  } '); 




fclose(file_1);  