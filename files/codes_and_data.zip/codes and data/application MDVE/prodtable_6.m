%
% run get_results_table6.m in order to get results

load results_MDVE

%% 
%write results in tables6.tex

%round these numbers
results   = round(1000*results)/1000;
resultsCI = round(1000*resultsCI)/1000;



my_folder = pwd;
file_1 = fopen([my_folder,'/tables/tables6','.tex'],'w');

fprintf(file_1,'{\\small \n ');
fprintf(file_1,' \\renewcommand\\multirowsetup{\\centering} \n');
fprintf(file_1,' \\begin{center}  \n'); 
fprintf(file_1,' \\begin{tabular}{cc}  \n'); 
fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,'  \\multicolumn{2}{c}{Bounds on the Effect of an Arrest Policy on Domestic Violence Recividism} \\\\  \n'); 
fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n');  
fprintf(file_1,'  \\multirow{2}{220pt}{ No Assumption} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(1,1), 100*results(1,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%)  \\vspace{1mm}\\\\  \n',[ 100*resultsCI(1,1), 100*resultsCI(1,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ Independence of an assigned treatment (IND)} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(2,1), 100*results(2,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%) \\vspace{1mm}\\\\  \n',[100*resultsCI(2,1), 100*resultsCI(2,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ (IND) + Roy model (ROY)} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(3,1), 100*results(3,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%)  \\vspace{1mm}\\\\  \n',[100*resultsCI(3,1), 100*resultsCI(3,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ (IND) + Compliance based on suspected risk type (CBSR)} & [%6.2f\\%%, %6.2f\\%%]\\\\  \n',[100*results(4,1), 100*results(4,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%)  \\vspace{1mm}\\\\  \n',[100*resultsCI(4,1), 100*resultsCI(4,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ (IND) + Aggravating circumstances as cond. monotone instrumental variable (cMIV)} & [%6.2f\\%%, %6.2f\\%%] \\\\  \n',[100*results(5,1), 100*results(5,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%)  \\vspace{1mm}\\\\  \n',[100*resultsCI(5,1), 100*resultsCI(5,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ IND+cMIV+ROY} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(6,1), 100*results(6,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%) \\vspace{1mm}\\\\  \n',[100*resultsCI(6,1), 100*resultsCI(6,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ IND+cMIV+CBSR} & [%6.2f\\%%, %6.2f\\%%] \\\\  \n',[100*results(7,1), 100*results(7,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%)  \\vspace{1mm}\\\\  \n',[100*resultsCI(7,1), 100*resultsCI(7,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ IND+cMIV+cROY} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(8,1), 100*results(8,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%) \\vspace{1mm}\\\\  \n',[100*resultsCI(8,1), 100*resultsCI(8,2)]); 
fprintf(file_1,'  \\multirow{2}{220pt}{ IND+cMIV+cCBSR} & [%6.2f\\%%, %6.2f\\%%]  \\\\  \n',[100*results(9,1), 100*results(9,2)]); 
fprintf(file_1,'  & (%6.2f\\%%, %6.2f\\%%) \\vspace{1mm}\\\\  \n',[100*resultsCI(9,1), 100*resultsCI(9,2)]); 
fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,'  Sample size & \\multicolumn{1}{c}{313}  \\\\   \n'); 
fprintf(file_1,'  \\multicolumn{2}{l}{90\\%% confidence intervals in parentheses using the method of \\cite{im} } \\\\  \n'); 
fprintf(file_1,'  \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,'  \\end{tabular}  \n'); 
fprintf(file_1,'  \\end{center}  \n'); 
fprintf(file_1,'  } '); 

fclose(file_1);  


fid  = fopen([my_folder,'/tables/tables6','.tex'],'r');
f=fread(fid,'*char')';
fclose(fid);
f = regexprep(f,'0\\%,','\\%,');
f = regexprep(f,'0\\%]','\\%]');
f = regexprep(f,'0\\%)','\\%)');
%f = regexprep(f,'.0\\%','\\%');
fid  = fopen([my_folder,'/tables/tables6','.tex'],'w');
fprintf(fid,'%s',f);
fclose(fid);
