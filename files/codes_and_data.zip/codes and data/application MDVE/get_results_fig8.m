
% results for Figure 8

miss_relax  = [0:0.01:0.1];

h = size(miss_relax,2);
resultsSensMiss1 = zeros(h,2);
resultsSensMiss2 = zeros(h,2);
resultsSensMiss3 = zeros(h,2);


whichAssumptions = [0 0 1 1 1];

relaxVector = [0 0 0 0 0 0 0];

x_lb = probDistribution(:);
x_up = probDistribution(:);

for i = 1:h
    tic
    [lb,x_lb,ub,x_up] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector, miss_relax(i),x_lb,x_up);
    resultsSensMiss1(i,1) = lb;
    resultsSensMiss1(i,2) = ub;
    toc
end


whichAssumptions = [0 0 1 1 0];

for i = 1:h
    [lb,x_lb,ub,x_up] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector, miss_relax(i),x_lb,x_up);
    resultsSensMiss2(i,1) = lb;
    resultsSensMiss2(i,2) = ub;
end


whichAssumptions = [0 0 0 1 0];

for i = 1:h
    [lb,x_lb,ub,x_up] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector, miss_relax(i),x_lb,x_up);
    resultsSensMiss3(i,1) = lb;
    resultsSensMiss3(i,2) = ub;
end

