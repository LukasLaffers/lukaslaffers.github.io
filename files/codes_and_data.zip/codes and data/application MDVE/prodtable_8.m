%
% run get_results_table8.m in order to get the results

load results_MDVE

%% 
%write results in tables8.tex

my_folder = pwd;
file_1 = fopen([my_folder,'/tables/tables8','.tex'],'w');

fprintf(file_1,' {\\footnotesize  \n ');
fprintf(file_1,' \\begin{center}   \n ');
fprintf(file_1,' \\noindent \\makebox[\\textwidth][c]{  \n ');
fprintf(file_1,'  \\begin{tabular}{ccccccccccccc}   \n ');
fprintf(file_1,'   \\noalign{\\hrule height 2pt} \\\\  \n ');
fprintf(file_1,'    \\multicolumn{13}{c}{{\\bf Sensitivity Analysis: Lagrange Multipliers}} \\\\  \n ');
fprintf(file_1,'    \\multicolumn{13}{c}{{\\bf for the Bounds on the Effect of an Arrest Policy on Domestic Violence Recividism}} \\vspace{3mm} \\\\  \n ');
fprintf(file_1,'   \\noalign{\\hrule height 2pt} \\\\  \n ');
fprintf(file_1,'   \\multicolumn{1}{c}{ } & \\multicolumn{6}{c}{Relaxation of MOT -- Lower Bound} & \\multicolumn{6}{c}{Relaxation of cMIV -- Upper Bound} \\\\   \n ');
fprintf(file_1,'    \\cmidrule(lr){2-7}\\cmidrule(lr){8-13}  \n ');
fprintf(file_1,'  \\multicolumn{1}{c}{Assumption Set} & \\multicolumn{2}{c}{IND+cMIV+cROY+cCBSR} & \\multicolumn{2}{c}{IND+cMIV}& \\multicolumn{2}{c}{IND} & \\multicolumn{2}{c}{IND+cMIV+cROY+cCBSR} & \\multicolumn{2}{c}{IND+cMIV+cROY}& \\multicolumn{2}{c}{IND+cMIV} \\\\   \n ');
fprintf(file_1,'     \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(lr){8-9}\\cmidrule(lr){10-11}\\cmidrule(lr){12-13}  \n ');
fprintf(file_1,'    \\multicolumn{1}{c}{Relaxation } & \\multicolumn{2}{c}{$\\alpha_{MOT}=$} & \\multicolumn{2}{c}{$\\alpha_{MOT}=$}& \\multicolumn{2}{c}{$\\alpha_{MOT}=$} & \\multicolumn{2}{c}{$\\alpha_{cMIV}=$} & \\multicolumn{2}{c}{$\\alpha_{cMIV}=$}& \\multicolumn{2}{c}{$\\alpha_{cMIV}=$} \\\\   \n ');
fprintf(file_1,'   & $0.01$ & $0.05$  & $0.01$ & $0.05$  & $0.01$ & $0.05$  & $0.01$ & $0.05$  & $0.01$ & $0.05$  & $0.01$ & $0.05$ \\\\  \n ');
fprintf(file_1,'   \\noalign{\\hrule height 2pt}   \n ');

fprintf(file_1,' MOT & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f   \\vspace{1mm} \\\\   \n ', resultsLM(1,1:12) );

fprintf(file_1,' cMIV (t=1, z=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }    \\\\   \n ', resultsLM(2,1:12) );
fprintf(file_1,' cMIV (t=1, z=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }    \\\\   \n ', resultsLM(3,1:12) );
fprintf(file_1,' cMIV (t=0, z=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }    \\\\   \n ', resultsLM(4,1:12) );
fprintf(file_1,' cMIV (t=0, z=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }   \\vspace{1mm} \\\\   \n ', resultsLM(5,1:12) );

fprintf(file_1,' cROY (t=0, v=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(6,1:12) );
fprintf(file_1,' cROY (t=0, v=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\vspace{1mm} \\\\   \n ', resultsLM(7,1:12) );

fprintf(file_1,' cCBSR (t=1, v=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(8,1:12) );
fprintf(file_1,' cCBSR (t=0, v=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(9,1:12) );
fprintf(file_1,' cCBSR (t=0, v=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f   \\vspace{1mm} \\\\   \n ', resultsLM(10,1:12) );

fprintf(file_1,'   \\noalign{\\hrule height 1pt} \\\\  \n ');
fprintf(file_1,'   \\multicolumn{1}{c}{ } & \\multicolumn{6}{c}{Relaxation of cROY -- Upper Bound} & \\multicolumn{6}{c}{Relaxation of cCBSR -- Upper Bound} \\\\   \n ');
fprintf(file_1,'   \\cmidrule(lr){2-7}\\cmidrule(lr){8-13}  \n ');
fprintf(file_1,'  \\multicolumn{1}{c}{Assumption Set}  & \\multicolumn{2}{c}{IND+cMIV+cROY+cCBSR} & \\multicolumn{2}{c}{IND+cMIV+cROY}& \\multicolumn{2}{c}{IND+cROY}& \\multicolumn{2}{c}{IND+cMIV+cROY+cCBSR}& \\multicolumn{2}{c}{IND+cMIV+cCBSR}& \\multicolumn{2}{c}{IND+cCBSR} \\\\   \n ');
fprintf(file_1,'   \\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(lr){8-9}\\cmidrule(lr){10-11}\\cmidrule(lr){12-13}  \n ');
fprintf(file_1,'   \\multicolumn{1}{c}{Relaxation } & \\multicolumn{2}{c}{$\\alpha_{cROY}=$} & \\multicolumn{2}{c}{$\\alpha_{cROY}=$}& \\multicolumn{2}{c}{$\\alpha_{cROY}=$}& \\multicolumn{2}{c}{$\\alpha_{cCBSR}=$}& \\multicolumn{2}{c}{$\\alpha_{cCBSR}=$}& \\multicolumn{2}{c}{$\\alpha_{cCBSR}=$} \\\\   \n ');
fprintf(file_1,'   & $0.01$ & $0.05$   & $0.01$ & $0.05$   & $0.01$ & $0.05$   & $0.01$ & $0.05$   & $0.01$ & $0.05$   & $0.01$ & $0.05$ \\\\  \n ');
fprintf(file_1,'   \\noalign{\\hrule height 2pt}   \n ');

fprintf(file_1,' MOT & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f   \\vspace{1mm} \\\\   \n ', resultsLM(1,13:24) );

fprintf(file_1,' cMIV (t=1, z=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(2,13:24) );
fprintf(file_1,' cMIV (t=1, z=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(3,13:24) );
fprintf(file_1,' cMIV (t=0, z=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(4,13:24) );
fprintf(file_1,' cMIV (t=0, z=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f   \\vspace{1mm} \\\\   \n ', resultsLM(5,13:24) );

fprintf(file_1,' cROY (t=0, v=0) & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\\\   \n ', resultsLM(6,13:24) );
fprintf(file_1,' cROY (t=0, v=1) & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f    \\vspace{1mm} \\\\   \n ', resultsLM(7,13:24) );

fprintf(file_1,' cCBSR (t=1, v=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }    \\\\   \n ', resultsLM(8,13:24) );
fprintf(file_1,' cCBSR (t=0, v=1) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }    \\\\   \n ', resultsLM(9,13:24) );
fprintf(file_1,' cCBSR (t=0, v=0) & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f } & {\\bf %5.3f }   \\vspace{1mm} \\\\   \n ', resultsLM(10,13:24) );

fprintf(file_1,' \\noalign{\\hrule height 2pt}   \n ');
fprintf(file_1,'  \\end{tabular}   \n ');
fprintf(file_1,'  }  \n ');
fprintf(file_1,'  \\end{center}   \n ');
fprintf(file_1,'  }   \n ');

fclose(file_1);  

%%

fid  = fopen([my_folder,'/tables/tables8','.tex'],'r');
f=fread(fid,'*char')';
fclose(fid);
f = regexprep(f,'NaN','--');
f = regexprep(f,'0.000','0');
f = regexprep(f,'-0','0');
fid  = fopen([my_folder,'/tables/tables8','.tex'],'w');
fprintf(fid,'%s',f);
fclose(fid);

