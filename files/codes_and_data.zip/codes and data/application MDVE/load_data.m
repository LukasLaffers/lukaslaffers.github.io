%dataset

clc

%setup
%y - outcome - recividism in the first 6 months
%d - arrested or not
%z - intended arrest
%g - aggravating circumstances

%table 2 from the Siddique 2013 JASA paper
%[1 0]
dataset = zeros(2,2,2,2);

dataset(1,1,1,1) = 7;
dataset(2,1,1,1) = 56;

dataset(1,1,1,2) = 3;
dataset(2,1,1,2) = 25;

dataset(1,2,1,1) = 0;
dataset(2,2,1,1) = 1;

dataset(1,2,1,2) = 0;
dataset(2,2,1,2) = 0;

dataset(1,1,2,1) = 7;
dataset(2,1,2,1) = 33;

dataset(1,1,2,2) = 1;
dataset(2,1,2,2) = 3;

dataset(1,2,2,1) = 19;
dataset(2,2,2,1) = 72;

dataset(1,2,2,2) = 20;
dataset(2,2,2,2) = 66;


dataset(1,1,1,1) = 63*0.11;
dataset(2,1,1,1) = 63*0.89;

dataset(1,1,1,2) = 28*0.11;
dataset(2,1,1,2) = 28*0.89;

dataset(1,2,1,1) = 0;
dataset(2,2,1,1) = 1;

dataset(1,2,1,2) = 0;
dataset(2,2,1,2) = 0;

dataset(1,1,2,1) = 40*0.18;
dataset(2,1,2,1) = 40*0.82;

dataset(1,1,2,2) = 1;
dataset(2,1,2,2) = 3;

dataset(1,2,2,1) = 91*0.21;
dataset(2,2,2,1) = 91*0.79;

dataset(1,2,2,2) = 86*0.23;
dataset(2,2,2,2) = 86*0.77;


probDistribution = dataset/sum(sum(sum(sum(dataset))));


