function [bounds_res,exitflag,lambdaMin,lambdaMax] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector)
% Bounds on ATE using linear programming (with relaxations)

%clc

%(Y(1),Y(0),Y,D,Z,G)
arrayHelp = zeros(2,2,2,2,2,2);

%%
% Consistency

arrayComp = arrayHelp;

%if D = 1 then Y(1) = Y
arrayComp(1,:,1,1,:,:) = ones(2,2,2);
arrayComp(2,:,2,1,:,:) = ones(2,2,2);
%if D = 0 then Y(0) = Y
arrayComp(:,1,1,2,:,:) = ones(2,2,2);
arrayComp(:,2,2,2,:,:) = ones(2,2,2);

matComp = reshape(arrayComp,1,64);
vecComp = 1;

%%
% Compatibility with Data

matData = zeros(16,64);
vecData = zeros(16,1);

iCount = 1;
for iY = 1:2
    for iD = 1:2
        for iZ = 1:2
            for iG = 1:2
                arrayData = arrayHelp;
                arrayData(:,:,iY,iD,iZ,iG) = ones(2,2);
                matData(iCount,:) = reshape(arrayData,1,64);
                vecData(iCount)   = probDistribution(iY,iD,iZ,iG);
                iCount = iCount + 1;
            end
        end
    end
end

%%
% Assigned treatment is random 
% (2.1) in the paper
% P(y(t)) = P(y(t)|z)

matRandom = zeros(4,64);
vecRandom = zeros(4,1);

% T = 1
arrayYT1 = arrayHelp;
arrayYT1(1,:,:,:,:,:) = ones(2,2,2,2,2);
    % Z = 1
    PZ1 = sum(sum(sum(probDistribution(:,:,1,:))));
    arrayYT1gZ1 = arrayHelp;
    arrayYT1gZ1(1,:,:,:,1,:) = ones(2,2,2,2)/PZ1;
    matRandom(1,:) = reshape(arrayYT1 - arrayYT1gZ1,1,64);
    % Z = 0
    PZ0 = 1 - PZ1;
    arrayYT1gZ0 = arrayHelp;
    arrayYT1gZ0(1,:,:,:,2,:) = ones(2,2,2,2)/PZ0;
    matRandom(2,:) = reshape(arrayYT1 - arrayYT1gZ0,1,64); 

% T = 0
arrayYT0 = arrayHelp;
arrayYT0(:,1,:,:,:,:) = ones(2,2,2,2,2);
    % Z = 1
    PZ1 = sum(sum(sum(probDistribution(:,:,1,:))));
    arrayYT0gZ1 = arrayHelp;
    arrayYT0gZ1(:,1,:,:,1,:) = ones(2,2,2,2)/PZ1;
    matRandom(3,:) = reshape(arrayYT0 - arrayYT0gZ1,1,64);
    % Z = 0
    PZ0 = 1 - PZ1;
    arrayYT0gZ0 = arrayHelp;
    arrayYT0gZ0(:,1,:,:,2,:) = ones(2,2,2,2)/PZ0;
    matRandom(4,:) = reshape(arrayYT0 - arrayYT0gZ0,1,64);     


matRoy = zeros(4,64);
vecRoy = zeros(4,1); 

% T = 1
% E[y(t)|z=t, d=t]
arrayRoy1 = arrayHelp;
PZ1D1 = sum(sum(probDistribution(:,1,1,:)));
arrayRoy1(1,:,:,1,1,:) = ones(2,2,2)/PZ1D1;

% E[y(d)|z=t,d!=t]
arrayRoy2 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayRoy2(:,1,:,2,1,:) = ones(2,2,2)/PZ1D0;

matRoy(1,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

% E[y(d)|z!=t, d!=t]
arrayRoy1 = arrayHelp;
PZ0D0 = sum(sum(probDistribution(:,2,2,:)));
arrayRoy1(:,1,:,2,2,:) = ones(2,2,2)/PZ0D0;

% E[y(t)|z!=t,d=t]
arrayRoy2 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayRoy2(1,:,:,1,2,:) = ones(2,2,2)/PZ0D1;

matRoy(2,:) = reshape(arrayRoy1 - arrayRoy2,1,64);


% T = 0
% E[y(t)|z=t, d=t]
arrayRoy1 = arrayHelp;
PZ0D0 = sum(sum(probDistribution(:,2,2,:)));
arrayRoy1(:,1,:,2,2,:) = ones(2,2,2)/PZ0D0;

% E[y(d)|z=t,d!=t]
arrayRoy2 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayRoy2(1,:,:,1,2,:) = ones(2,2,2)/PZ0D1;

matRoy(3,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

% E[y(d)|z!=t, d!=t]
arrayRoy1 = arrayHelp;
PZ1D1 = sum(sum(probDistribution(:,1,1,:)));
arrayRoy1(1,:,:,1,1,:) = ones(2,2,2)/PZ1D1;

% E[y(t)|z!=t,d=t]
arrayRoy2 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayRoy2(:,1,:,2,1,:) = ones(2,2,2)/PZ1D0;

matRoy(4,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

%% 
% Roy model 2
% E[y(d)|z=t, d!=t]  <= E[y(t)|z=t,d!=t]


matRoy2 = zeros(2,64);
vecRoy2 = zeros(2,1); 

% T = 1
% E[y(d)|z=t, d!=t]
arrayRoy1 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayRoy1(:,1,:,2,1,:) = ones(2,2,2)/PZ1D0;

% E[y(t)|z=t,d!=t]
arrayRoy2 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayRoy2(1,:,:,2,1,:) = ones(2,2,2)/PZ1D0;

matRoy2(1,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

% T = 0
% E[y(d)|z=t, d!=t]
arrayRoy1 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayRoy1(1,:,:,1,2,:) = ones(2,2,2)/PZ0D1;

% E[y(t)|z=t,d!=t]
arrayRoy2 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayRoy2(:,1,:,1,2,:) = ones(2,2,2)/PZ0D1;

matRoy2(2,:) = reshape(arrayRoy1 - arrayRoy2,1,64);


%%
% Compliance Based on Suspect Risk Type
% equation (4.1) in the paper
% E[Y(t) | z=t, d=t] < E[Y(t)| z=t, d!=t]
% E[Y(d) | z!=t, d!=t] < E[Y(d)| z!=t, d=t]

matCBSR = zeros(4,64);
vecCBSR = zeros(4,1); 

% T = 1
% E[Y(t)|z=t, d=t]
arrayCBSR1 = arrayHelp;
PZ1D1 = sum(sum(probDistribution(:,1,1,:)));
arrayCBSR1(1,:,:,1,1,:) = ones(2,2,2)/PZ1D1;

% E[Y(t)| z=t, d!=t]
arrayCBSR2 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayCBSR2(1,:,:,2,1,:) = ones(2,2,2)/PZ1D0;

matCBSR(1,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

% E[Y(d) | z!=t, d!=t]
arrayCBSR1 = arrayHelp;
PZ0D0 = sum(sum(probDistribution(:,2,2,:)));
arrayCBSR1(:,1,:,2,2,:) = ones(2,2,2)/PZ0D0;

% E[Y(d)| z!=t, d=t]
arrayCBSR2 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayCBSR2(1,:,:,1,2,:) = ones(2,2,2)/PZ0D1;

matCBSR(2,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);



% T = 0
% E[y(t)|z=t, d=t]
arrayCBSR1 = arrayHelp;
PZ0D0 = sum(sum(probDistribution(:,2,2,:)));
arrayCBSR1(:,1,:,2,2,:) = ones(2,2,2)/PZ0D0;

% E[y(t)|z=t,d!=t]
arrayCBSR2 = arrayHelp;
PZ0D1 = sum(sum(probDistribution(:,1,2,:)));
arrayCBSR2(:,1,:,1,2,:) = ones(2,2,2)/PZ0D1;

matCBSR(3,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

% E[y(d)|z!=t, d!=t]
arrayCBSR1 = arrayHelp;
PZ1D1 = sum(sum(probDistribution(:,1,1,:)));
arrayCBSR1(1,:,:,1,1,:) = ones(2,2,2)/PZ1D1;

% E[y(d)|z!=t,d=t]
arrayCBSR2 = arrayHelp;
PZ1D0 = sum(sum(probDistribution(:,2,1,:)));
arrayCBSR2(:,1,:,2,1,:) = ones(2,2,2)/PZ1D0;

matCBSR(4,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

matCBSR2 = matCBSR([1 3],:);
vecCBSR2 = vecCBSR([1 3],:);

%%
% Aggravating Circumstances as a Monotone Instrumental Variable
% MIV equation (5.1) in the paper
% E[Y(T)|Z, G = 1] >= E[Y(T)|Z, G = 0]

matAgg = zeros(4,64);
vecAgg = zeros(4,1); 

% T = 1
    % Z = 1
    %E[Y(T)|Z, G = 0]
    arrayAgg1 = arrayHelp;
    PZ1G0     = sum(sum(probDistribution(:,:,1,2)));
    arrayAgg1(1,:,:,:,1,2) = ones(2,2,2)/PZ1G0;
    
    %E[Y(T)|Z, G = 1]
    arrayAgg2 = arrayHelp;
    PZ1G1     = sum(sum(probDistribution(:,:,1,1)));
    arrayAgg2(1,:,:,:,1,1) = ones(2,2,2)/PZ1G1;
    
    matAgg(1,:) = reshape(arrayAgg1 - arrayAgg2,1,64);
    
    % Z = 0
    %E[Y(T)|Z, G = 0]
    arrayAgg1 = arrayHelp;
    PZ0G0     = sum(sum(probDistribution(:,:,2,2)));
    arrayAgg1(1,:,:,:,2,2) = ones(2,2,2)/PZ0G0;
    
    %E[Y(T)|Z, G = 1]
    arrayAgg2 = arrayHelp;
    PZ0G1     = sum(sum(probDistribution(:,:,2,1)));
    arrayAgg2(1,:,:,:,2,1) = ones(2,2,2)/PZ0G1;
    
    matAgg(2,:) = reshape(arrayAgg1 - arrayAgg2,1,64);
    
% T = 0
    % Z = 1
    %E[Y(T)|Z, G = 0]
    arrayAgg1 = arrayHelp;
    PZ1G0     = sum(sum(probDistribution(:,:,1,2)));
    arrayAgg1(:,1,:,:,1,2) = ones(2,2,2)/PZ1G0;
    
    %E[Y(T)|Z, G = 1]
    arrayAgg2 = arrayHelp;
    PZ1G1     = sum(sum(probDistribution(:,:,1,1)));
    arrayAgg2(:,1,:,:,1,1) = ones(2,2,2)/PZ1G1;
    
    matAgg(3,:) = reshape(arrayAgg1 - arrayAgg2,1,64);
    
    % Z = 0
    %E[Y(T)|Z, G = 0]
    arrayAgg1 = arrayHelp;
    PZ0G0     = sum(sum(probDistribution(:,:,2,2)));
    arrayAgg1(:,1,:,:,2,2) = ones(2,2,2)/PZ0G0;
    
    %E[Y(T)|Z, G = 1]
    arrayAgg2 = arrayHelp;
    PZ0G1     = sum(sum(probDistribution(:,:,2,1)));
    arrayAgg2(:,1,:,:,2,1) = ones(2,2,2)/PZ0G1;
    
    matAgg(4,:) = reshape(arrayAgg1 - arrayAgg2,1,64);

    

%% 
% Roy model assumption conditional on MIV
% E[y(d)|g=0, z=t, d!=t]  <= E[y(t)|g=0, z=t, d!=t]
% E[y(d)|g=1, z=t, d!=t]  <= E[y(t)|g=1, z=t, d!=t]

matRoy3 = zeros(4,64);
vecRoy3 = zeros(4,1); 

% G = 0
    % T = 1
    % E[y(d)|g=0, z=t, d!=t]
    arrayRoy1 = arrayHelp;
    PG0Z1D0 = sum(probDistribution(:,2,1,2));
    arrayRoy1(:,1,:,2,1,2) = ones(2,2)/PG0Z1D0;

    % E[y(t)|g=0, z=t,d!=t]
    arrayRoy2 = arrayHelp;
    PG0Z1D0 = sum(probDistribution(:,2,1,2));
    arrayRoy2(1,:,:,2,1,2) = ones(2,2)/PG0Z1D0;

    matRoy3(1,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

    % T = 0
    % E[y(d)|g=0, z=t, d!=t]
    arrayRoy1 = arrayHelp;
    PG0Z0D1 = sum(probDistribution(:,1,2,2));
    arrayRoy1(1,:,:,1,2,2) = ones(2,2)/PG0Z0D1;

    % E[y(t)|g=0, z=t,d!=t]
    arrayRoy2 = arrayHelp;
    PG0Z0D1 = sum(probDistribution(:,1,2,2));
    arrayRoy2(:,1,:,1,2,2) = ones(2,2)/PG0Z0D1;

    matRoy3(2,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

% G = 1
    % T = 1
    % E[y(d)|g=1, z=t, d!=t]
    arrayRoy1 = arrayHelp;
    PG1Z1D0 = sum(probDistribution(:,2,1,1));
    arrayRoy1(:,1,:,2,1,1) = ones(2,2)/PG1Z1D0;

    % E[y(t)|g=1, z=t,d!=t]
    arrayRoy2 = arrayHelp;
    PG1Z1D0 = sum(probDistribution(:,2,1,1));
    arrayRoy2(1,:,:,2,1,1) = ones(2,2)/PG1Z1D0;

    matRoy3(3,:) = reshape(arrayRoy1 - arrayRoy2,1,64);

    % T = 0
    % E[y(d)|g=1, z=t, d!=t]
    arrayRoy1 = arrayHelp;
    PG1Z0D1 = sum(probDistribution(:,1,2,1));
    arrayRoy1(1,:,:,1,2,1) = ones(2,2)/PG1Z0D1;

    % E[y(t)|g=1, z=t,d!=t]
    arrayRoy2 = arrayHelp;
    PG1Z0D1 = sum(probDistribution(:,1,2,1));
    arrayRoy2(:,1,:,1,2,1) = ones(2,2)/PG1Z0D1;

    matRoy3(4,:) = reshape(arrayRoy1 - arrayRoy2,1,64);
    
    [PG0Z1D0, PG0Z0D1, PG1Z1D0, PG1Z0D1];
    
    matRoy3 = matRoy3([2 4],:);
    vecRoy3 = vecRoy3([2 4]);

 
%%

%%
% Compliance Based on Suspect Risk Type conditional on MIV
% E[Y(t) | g=1, z=t, d=t] < E[Y(t)|g=1, z=t, d!=t]
% and
% E[Y(t) | g=0, z=t, d=t] < E[Y(t)|g=0, z=t, d!=t]

matCBSR3 = zeros(4,64);
vecCBSR3 = zeros(4,1); 

% G = 1
    % T = 1
    % E[Y(t)| g=1, z=t, d=t]
    arrayCBSR1 = arrayHelp;
    PG1Z1D1 = sum(probDistribution(:,1,1,1));
    arrayCBSR1(1,:,:,1,1,1) = ones(2,2)/PG1Z1D1;

    % E[Y(t)| g=1, z=t, d!=t]
    arrayCBSR2 = arrayHelp;
    PG1Z1D0 = sum(probDistribution(:,2,1,1));
    arrayCBSR2(1,:,:,2,1,1) = ones(2,2)/PG1Z1D0;

    matCBSR3(1,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

    % T = 0
    % E[y(t)| g=1, z=t, d=t]
    arrayCBSR1 = arrayHelp;
    PG1Z0D0 = sum(probDistribution(:,2,2,1));
    arrayCBSR1(:,1,:,2,2,1) = ones(2,2)/PG1Z0D0;

    % E[y(t)| g=1, z=t,d!=t]
    arrayCBSR2 = arrayHelp;
    PG1Z0D1 = sum(probDistribution(:,1,2,1));
    arrayCBSR2(:,1,:,1,2,1) = ones(2,2)/PG1Z0D1;

    matCBSR3(2,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

% G = 0
    % T = 1
    % E[Y(t)| g=0, z=t, d=t]
    arrayCBSR1 = arrayHelp;
    PG0Z1D1 = sum(probDistribution(:,1,1,2));
    arrayCBSR1(1,:,:,1,1,2) = ones(2,2)/PG0Z1D1;

    % E[Y(t)| g=0, z=t, d!=t]
    arrayCBSR2 = arrayHelp;
    PG0Z1D0 = sum(probDistribution(:,2,1,2));
    arrayCBSR2(1,:,:,2,1,2) = ones(2,2)/PG0Z1D0;

    matCBSR3(3,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

    % T = 0
    % E[y(t)| g=0, z=t, d=t]
    arrayCBSR1 = arrayHelp;
    PG0Z0D0 = sum(probDistribution(:,2,2,2));
    arrayCBSR1(:,1,:,2,2,2) = ones(2,2)/PG0Z0D0;

    % E[y(t)| g=0, z=t,d!=t]
    arrayCBSR2 = arrayHelp;
    PG0Z0D1 = sum(probDistribution(:,1,2,2));
    arrayCBSR2(:,1,:,1,2,2) = ones(2,2)/PG0Z0D1;

    matCBSR3(4,:) = reshape(arrayCBSR1 - arrayCBSR2,1,64);

    [PG1Z1D1 PG1Z0D1 PG1Z1D0 PG1Z0D0];
    [PG0Z1D1 PG0Z0D1 PG0Z1D0 PG0Z0D0];
    
matCBSR3 = matCBSR3([1 2 4],:);
vecCBSR3 = vecCBSR3([1 2 4]);   
%we omitt the third one as PG0Z1D0 == 0
    
%%
% Objective function

arrayObj = arrayHelp;
arrayObj(:,1,:,:,:,:) = ones(2,2,2,2,2);
f0 = reshape(arrayObj,64,1);

arrayObj = arrayHelp;
arrayObj(1,:,:,:,:,:) = ones(2,2,2,2,2);
f1 = reshape(arrayObj,64,1);

f_ate = f1 - f0;


lb = zeros(64,1);
ub = ones(64,1);

options=optimset('Display', 'off');


%%

A = [];
b = [];

Aeq = [ matData];
beq = [ vecData];

if relaxVector(1) > 0
    A = [A; -matComp];
    b = [b; relaxVector(1)-1];
else
    Aeq = [Aeq; matComp];
    beq = [beq; vecComp];
end

if relaxVector(2) > 0
    A = [A; -matRandom; matRandom];
    b = [b; relaxVector(2)*ones(4,1); relaxVector(2)*ones(4,1)];
else
    Aeq = [Aeq; matRandom];
    beq = [beq; vecRandom];
end


if whichAssumptions(1) == 1
    A = [A; matRoy2];
    b = [b; ones(2,1)*relaxVector(3)];
end

if whichAssumptions(2) == 1
    A = [A; matCBSR2];
    b = [b; ones(2,1)*relaxVector(4)];
end

if whichAssumptions(3) == 1
    A = [A; matAgg];
    b = [b; ones(4,1)*relaxVector(5)];
end

if whichAssumptions(4) == 1
    A = [A; matRoy3];
    b = [b; ones(2,1)*relaxVector(6)];
end

if whichAssumptions(5) == 1
    A = [A; matCBSR3];
    b = [b; ones(3,1)*relaxVector(7)];
end


[~,fval_min,~,~,lambdaMin] = linprog( f_ate,A,b,Aeq,beq,lb,ub,[],options);
[~,fval_max,exitflag,~,lambdaMax] = linprog(-f_ate,A,b,Aeq,beq,lb,ub,[],options);
[fval_min, -fval_max];


bounds_res = [fval_min, -fval_max];

