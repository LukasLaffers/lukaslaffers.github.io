function [lb,x_down,ub,x_up]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions,...
    relaxVector,missProportion,startPointLb,startPointUb)

if nargin == 4
    startPointLb = probDistribution(:);
    startPointUb = probDistribution(:);
end

nObs = 313;
m    = missProportion*nObs;

ZerosObs = zeros(1,16);
OnesObs = ones(1,16);


options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',5000,...
                   'GradConstr','off','GradObj','off',...
                   'Hessian','lbfgs');

[x_down,fval_down,~] = fmincon(@(p)LowerBoundRelax(reshape(constructMixedProbs(probDistribution(:),p(:),nObs,m),2,2,2,2)...
    , whichAssumptions, relaxVector),...
    startPointLb,[],[],ones(1,16),1,...
    ZerosObs,OnesObs,[],options);

lb = fval_down;
               


[x_up,fval_up,~] = fmincon(@(p)-UpperBoundRelax(reshape(constructMixedProbs(probDistribution(:),p(:),nObs,m),2,2,2,2)...
    , whichAssumptions, relaxVector),...
    startPointUb,[],[],ones(1,16),1,...
    ZerosObs,OnesObs,[],options);

ub = -fval_up;



function [MixedProbs] = constructMixedProbs(ObservedProbs,MissingProbs,n,m)
    MixedProbs = ObservedProbs*(n/(n+m))+MissingProbs*(m/(n+m));
end

function [res] = UpperBoundRelax(probDistribution, whichAssumptions, relaxVector)
  [bounds_res,~] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
  res = bounds_res(2);
end

function [res] = LowerBoundRelax(probDistribution, whichAssumptions, relaxVector)
  [bounds_res,~] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
  res = bounds_res(1);
end

end