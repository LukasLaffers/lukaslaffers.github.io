
% results for Figure 7


% sensitivity SUPP results

supp_relax = 1 - [1:-0.01:0.9];
h = size(supp_relax,2);
resultsSensSUPP1 = zeros(h,2);
resultsSensSUPP2 = zeros(h,2);
resultsSensSUPP3 = zeros(h,2);


whichAssumptions = [0 0 1 1 1];

for i = 1:h
    relaxVector  = [supp_relax(i) 0 0 0 0 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensSUPP1(i,1) = bounds_res(1);
    resultsSensSUPP1(i,2) = bounds_res(2);
end

whichAssumptions = [0 0 1 0 0];

for i = 1:h
    relaxVector  = [supp_relax(i) 0 0 0 0 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensSUPP2(i,1) = bounds_res(1);
    resultsSensSUPP2(i,2) = bounds_res(2);
end

whichAssumptions = [0 0 0 0 0];

for i = 1:h
    relaxVector  = [supp_relax(i) 0 0 0 0 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensSUPP3(i,1) = bounds_res(1);
    resultsSensSUPP3(i,2) = bounds_res(2);
end

%%
% sensitivity cMIV results

cmiv_relax = 1 - [1:-0.01:0.9];
h = size(cmiv_relax,2);
resultsSensCMIV1 = zeros(h,2);
resultsSensCMIV2 = zeros(h,2);
resultsSensCMIV3 = zeros(h,2);


whichAssumptions = [0 0 1 1 1];

for i = 1:h
    relaxVector  = [0 0 0 0 cmiv_relax(i) 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCMIV1(i,1) = bounds_res(1);
    resultsSensCMIV1(i,2) = bounds_res(2);
end

whichAssumptions = [0 0 1 1 0];

for i = 1:h
    relaxVector  = [0 0 0 0 cmiv_relax(i) 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCMIV2(i,1) = bounds_res(1);
    resultsSensCMIV2(i,2) = bounds_res(2);
end

whichAssumptions = [0 0 1 0 0];

for i = 1:h
    relaxVector  = [0 0 0 0 cmiv_relax(i) 0 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCMIV3(i,1) = bounds_res(1);
    resultsSensCMIV3(i,2) = bounds_res(2);
end

%%
% sensitivity cROY results

croy_relax = 1 - [1:-0.01:0.9];
h = size(croy_relax,2);
resultsSensCROY1 = zeros(h,2);
resultsSensCROY2 = zeros(h,2);
resultsSensCROY3 = zeros(h,2);


whichAssumptions = [0 0 1 1 1];

for i = 1:h
    relaxVector  = [0 0 0 0 0 croy_relax(i) 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCROY1(i,1) = bounds_res(1);
    resultsSensCROY1(i,2) = bounds_res(2);
end


whichAssumptions = [0 0 1 1 0];

for i = 1:h
    relaxVector  = [0 0 0 0 0 croy_relax(i) 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCROY2(i,1) = bounds_res(1);
    resultsSensCROY2(i,2) = bounds_res(2);
end


whichAssumptions = [0 0 0 1 0];

for i = 1:h
    relaxVector  = [0 0 0 0 0 croy_relax(i) 0];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCROY3(i,1) = bounds_res(1);
    resultsSensCROY3(i,2) = bounds_res(2);
end

%%
% sensitivity cCBSR results

ccbsr_relax = 1 - [1:-0.01:0.9];
h = size(ccbsr_relax,2);
resultsSensCCBSR1 = zeros(h,2);
resultsSensCCBSR2 = zeros(h,2);
resultsSensCCBSR3 = zeros(h,2);


whichAssumptions = [0 0 1 1 1];

for i = 1:h
    relaxVector  = [0 0 0 0 0 0 ccbsr_relax(i)];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCCBSR1(i,1) = bounds_res(1);
    resultsSensCCBSR1(i,2) = bounds_res(2);
end

whichAssumptions = [0 0 1 0 1];

for i = 1:h
    relaxVector  = [0 0 0 0 0 0 ccbsr_relax(i)];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCCBSR2(i,1) = bounds_res(1);
    resultsSensCCBSR2(i,2) = bounds_res(2);
end


whichAssumptions = [0 0 0 0 1];

for i = 1:h
    relaxVector  = [0 0 0 0 0 0 ccbsr_relax(i)];
    [bounds_res,exitflag] = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
    resultsSensCCBSR3(i,1) = bounds_res(1);
    resultsSensCCBSR3(i,2) = bounds_res(2);
end

