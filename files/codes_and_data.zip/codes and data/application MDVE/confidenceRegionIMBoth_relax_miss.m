function [bounds_res,resLow,resUp,times] = confidenceRegionIMBoth_relax_miss(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector,missProportion)

%nSamples = size(distributions,1)/5
nSamples = 200;


nObs = 313;
SignificanceLevel = 0.9;


% upperbound and lowerbound

[lb,~,ub,~]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);


LowerBoundEst = lb;
UpperBoundEst = ub;

clear PercDeltaUp PercDeltaLow resUp resLow




PercDelta = zeros(nSamples,1);
resUp = zeros(nSamples,1);
resLow = zeros(nSamples,1);
times = zeros(nSamples,1);


for i = 1:nSamples
    i
    tic
    probDistributionBoot = reshape(distributions(i,:),2,2,2,2);
    
    [lb,~,ub,~]  = mdvelinprog_relax_miss(probDistributionBoot, whichAssumptions, relaxVector,missProportion);
    
    [lb,ub]
    
    PercDeltaLow(i) = sqrt(nObs)*(lb - LowerBoundEst);
    resLow(i) = lb;
    
    PercDeltaUp(i) = sqrt(nObs)*(ub - UpperBoundEst);
    resUp(i) = ub;
    times(i) = toc;
end

%
bias_lb = mean(resLow) - LowerBoundEst;
bias_ub = mean(resUp) - UpperBoundEst;

%estimated standard deviation
sigma_IM_high = std(resUp);
sigma_IM_low = std(resLow); 

%get coefficients c_IM
optionsf = optimset('fsolve'); 
optionsf = optimset(optionsf,'Display','Off');

c_IM = fsolve(@(c)imFun(c,SignificanceLevel+(1-SignificanceLevel)/2,UpperBoundEst-LowerBoundEst,max(sigma_IM_low,sigma_IM_high)),0,optionsf);


%Imbens and Manski Bias Corrected
ImBiasCRhigh = UpperBoundEst - bias_ub + c_IM*sigma_IM_high;
ImBiasCRlow  = LowerBoundEst - bias_lb - c_IM*sigma_IM_low;


bounds_res =  [ImBiasCRlow,ImBiasCRhigh]

function F = imFun(c,quan,ubmlb,max_sigma)
    F = normcdf(c+ubmlb/max_sigma)-normcdf(-c)-quan;
end

end

%save res_rush2.mat resUp resLow missProportion relaxVector






























