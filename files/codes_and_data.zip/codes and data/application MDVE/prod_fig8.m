%%
% run get_results_fig8.m

load results_MDVE

%%

h = figure;
colors = hsv(3);


p(1) = plot(miss_relax,resultsSensMiss1(:,1)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(miss_relax,resultsSensMiss1(:,2)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(miss_relax,resultsSensMiss2(:,1)-0.01,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(miss_relax,resultsSensMiss2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(miss_relax,resultsSensMiss3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(miss_relax,resultsSensMiss3(:,2)+0.005,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')



a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to the Missing Data}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Proportion of missing observations}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');

hleg = legend([p(1),p(2),p(3)],'IND+cMIV+cROY+cCBSR','IND+cMIV+cROY','IND+cMIV');
set(hleg,'Location','NorthWest')

mm = max(miss_relax);
mmm = 0:mm/10:mm;
set(a,'XTick',mmm);
xticker = [num2str(100*sort(mmm','ascend')) repmat('%',[size(mmm,2),1])];
set(a,'XTickLabel',xticker)

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])


%%

dim = [10 8];   % [width height], cm
fs = 8;         % font size, points
lw = 2;         % line width
printfigpdf(gcf(), 'figs\fig8.pdf', dim, fs, lw)


