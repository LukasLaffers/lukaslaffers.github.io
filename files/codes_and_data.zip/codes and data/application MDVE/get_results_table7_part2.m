% results for Table 7 (confidence regions under relaxed MISS assumption)
% takes a long time (~14hours on an i7 16GB ram laptop)

load_data

rng('default')
nObs     = 313;
nSamples = 1000;
SignificanceLevel = 0.9;

%generate bootstrap samples
randNums = rand(nSamples, nObs);
distributions = zeros(nSamples,16);
for iSample = 1:nSamples
    for jObs = 1:nObs
        ind = sum(randNums(iSample,jObs) > cumsum(reshape(probDistribution,16,1)))+1;
        distributions(iSample,ind) = distributions(iSample,ind) + 1;
    end
    distributions(iSample,:) = distributions(iSample,:)/nObs;
end


%%

tic
missProportion = 0.01;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];

[lb,~,ub,~]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);
[bounds_res,resLow,resUp,times] = confidenceRegionIMBoth_relax_miss(probDistribution,...
    distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector,missProportion);

resultsRelaxOpt(8,:)   = [lb,ub];
resultsRelaxOptCI(8,:) = [bounds_res];

toc

save('resultsMissOpt8.mat','bounds_res','resLow','resUp','times')


%%

tic


missProportion = 0.01;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.001 0 0 0 0.01 0.01 0.01];

[lb,~,ub,~]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);
[bounds_res,resLow,resUp,times] = confidenceRegionIMBoth_relax_miss(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector,missProportion);

resultsRelaxOpt(9,:)   = [lb,ub];
resultsRelaxOptCI(9,:) = [bounds_res];

toc

save('resultsMissOpt9.mat','bounds_res','resLow','resUp','times')


%%

tic
missProportion = 0.05;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];

[lb,~,ub,~]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);
[bounds_res,resLow,resUp,times] = confidenceRegionIMBoth_relax_miss(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector,missProportion);

resultsRelaxPes(8,:)   = [lb,ub];
resultsRelaxPesCI(8,:) = [bounds_res];
toc


save('resultsMissPes8.mat','bounds_res','resLow','resUp','times')


%%

tic
missProportion = 0.05;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.01 0 0 0 0.05 0.05 0.05];

[lb,~,ub,~]  = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);
[bounds_res,resLow,resUp,times] = confidenceRegionIMBoth_relax_miss(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector,missProportion);

resultsRelaxPes(9,:)   = [lb,ub];
resultsRelaxPesCI(9,:) = [bounds_res];
toc


save('resultsMissPes9.mat','bounds_res','resLow','resUp','times')

