
% results for Table 8

resultsLM = NaN(10,24);

whichAssumpMatrix = zeros(24,5);
relaxVectorMatrix = zeros(24,7);

whichAssumpMatrix(1,:)  = [0 0 1 1 1];
whichAssumpMatrix(2,:)  = [0 0 1 1 1];
whichAssumpMatrix(3,:)  = [0 0 1 0 0];
whichAssumpMatrix(4,:)  = [0 0 1 0 0];
whichAssumpMatrix(5,:)  = [0 0 0 0 0];
whichAssumpMatrix(6,:)  = [0 0 0 0 0];
whichAssumpMatrix(7,:)  = [0 0 1 1 1];
whichAssumpMatrix(8,:)  = [0 0 1 1 1];
whichAssumpMatrix(9,:)  = [0 0 1 1 0];
whichAssumpMatrix(10,:) = [0 0 1 1 0];
whichAssumpMatrix(11,:) = [0 0 1 0 0];
whichAssumpMatrix(12,:) = [0 0 1 0 0];
whichAssumpMatrix(13,:) = [0 0 1 1 1];
whichAssumpMatrix(14,:) = [0 0 1 1 1];
whichAssumpMatrix(15,:) = [0 0 1 1 0];
whichAssumpMatrix(16,:) = [0 0 1 1 0];
whichAssumpMatrix(17,:) = [0 0 0 1 0];
whichAssumpMatrix(18,:) = [0 0 0 1 0];
whichAssumpMatrix(19,:) = [0 0 1 1 1];
whichAssumpMatrix(20,:) = [0 0 1 1 1];
whichAssumpMatrix(21,:) = [0 0 1 0 1];
whichAssumpMatrix(22,:) = [0 0 1 0 1];
whichAssumpMatrix(23,:) = [0 0 0 0 1];
whichAssumpMatrix(24,:) = [0 0 0 0 1];


relaxVectorMatrix(1,:)  = [0.01 0 0 0 0 0 0];
relaxVectorMatrix(2,:)  = [0.05 0 0 0 0 0 0];
relaxVectorMatrix(3,:)  = [0.01 0 0 0 0 0 0];
relaxVectorMatrix(4,:)  = [0.05 0 0 0 0 0 0];
relaxVectorMatrix(5,:)  = [0.01 0 0 0 0 0 0];
relaxVectorMatrix(6,:)  = [0.05 0 0 0 0 0 0];
relaxVectorMatrix(7,:)  = [0.000001 0 0 0 0.01 0 0];
relaxVectorMatrix(8,:)  = [0.000001 0 0 0 0.05 0 0];
relaxVectorMatrix(9,:)  = [0.000001 0 0 0 0.01 0 0];
relaxVectorMatrix(10,:) = [0.000001 0 0 0 0.05 0 0];
relaxVectorMatrix(11,:) = [0.000001 0 0 0 0.01 0 0];
relaxVectorMatrix(12,:) = [0.000001 0 0 0 0.05 0 0];
relaxVectorMatrix(13,:) = [0.000001 0 0 0 0 0.01 0];
relaxVectorMatrix(14,:) = [0.000001 0 0 0 0 0.05 0];
relaxVectorMatrix(15,:) = [0.000001 0 0 0 0 0.01 0];
relaxVectorMatrix(16,:) = [0.000001 0 0 0 0 0.05 0];
relaxVectorMatrix(17,:) = [0.000001 0 0 0 0 0.01 0];
relaxVectorMatrix(18,:) = [0.000001 0 0 0 0 0.05 0];
relaxVectorMatrix(19,:) = [0.000001 0 0 0 0 0 0.01];
relaxVectorMatrix(20,:) = [0.000001 0 0 0 0 0 0.05];
relaxVectorMatrix(21,:) = [0.000001 0 0 0 0 0 0.01];
relaxVectorMatrix(22,:) = [0.000001 0 0 0 0 0 0.05];
relaxVectorMatrix(23,:) = [0.000001 0 0 0 0 0 0.01];
relaxVectorMatrix(24,:) = [0.000001 0 0 0 0 0 0.05];

%%

for iColumn = 1:6    
    [bounds_res,exitflag,lambdaMin,lambdaMax] = ...
    mdvelinprog_relax(probDistribution, whichAssumpMatrix(iColumn,:),...
    relaxVectorMatrix(iColumn,:));

    check = 0;
    
    if relaxVectorMatrix(iColumn,1) > 0
        resultsLM(1,iColumn) = lambdaMin.ineqlin(1);
        check = 1;
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 1 1]) == 3
        resultsLM(2:10,iColumn) = lambdaMin.ineqlin(check+(1:9));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 0 0]) == 3
        resultsLM(2:5,iColumn) = lambdaMin.ineqlin(check+(1:4));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 1 0]) == 3
        resultsLM(2:7,iColumn) = lambdaMin.ineqlin(check+(1:6));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [0 1 0]) == 3
        resultsLM(6:7,iColumn) = lambdaMin.ineqlin(check+(1:2));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 0 1]) == 3
        resultsLM(2:5,iColumn)  = lambdaMin.ineqlin(check+(1:4));
        resultsLM(8:10,iColumn) = lambdaMin.ineqlin(check+(5:7));
    end
        
    if sum(whichAssumpMatrix(iColumn,3:5) == [0 0 1]) == 3
        resultsLM(8:10,iColumn) = lambdaMin.ineqlin(check+(1:3));
    end
    
end


for iColumn = 7:24
    [bounds_res,exitflag,lambdaMin,lambdaMax] = ...
    mdvelinprog_relax(probDistribution, whichAssumpMatrix(iColumn,:),...
    relaxVectorMatrix(iColumn,:));

    check = 0;
    
    if relaxVectorMatrix(iColumn,1) > 0
        resultsLM(1,iColumn) = lambdaMax.ineqlin(1);
        check = 1;
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 1 1]) == 3
        resultsLM(2:10,iColumn) = lambdaMax.ineqlin(check+(1:9));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 0 0]) == 3
        resultsLM(2:5,iColumn) = lambdaMax.ineqlin(check+(1:4));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 1 0]) == 3
        resultsLM(2:7,iColumn) = lambdaMax.ineqlin(check+(1:6));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [0 1 0]) == 3
        resultsLM(6:7,iColumn) = lambdaMax.ineqlin(check+(1:2));
    end
    
    if sum(whichAssumpMatrix(iColumn,3:5) == [1 0 1]) == 3
        resultsLM(2:5,iColumn)  = lambdaMax.ineqlin(check+(1:4));
        resultsLM(8:10,iColumn) = lambdaMax.ineqlin(check+(5:7));
    end
        
    if sum(whichAssumpMatrix(iColumn,3:5) == [0 0 1]) == 3
        resultsLM(8:10,iColumn) = lambdaMax.ineqlin(check+(1:3));
    end
    
end
