function [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(probDistribution,distributions,setOfAssumptions,nObs,SignificanceLevel)

nSamples = size(distributions,1);

clear res

%% upperbound and lowerbound

%find solution
[bounds_res,exitflag1] =  mdvelinprog_spec(probDistribution,setOfAssumptions);
UpperBoundEst = bounds_res(2);
LowerBoundEst = bounds_res(1);

if exitflag1 == 1

    PercDeltaUp = zeros(nSamples,1);
    PercDeltaLow = zeros(nSamples,1);
    resUp = zeros(nSamples,1);
    resLow = zeros(nSamples,1);
    
    goodIndices = [];
    badIndices = [];
    
    for i = 1:nSamples
        probDistributionBoot = reshape(distributions(i,:),2,2,2,2);
        [bounds_res,exitflag] =  mdvelinprog_spec(probDistributionBoot,setOfAssumptions);
                
        if exitflag == 1
            PercDeltaUp(i) = sqrt(nObs)*(bounds_res(2) - UpperBoundEst);
            resUp(i) = bounds_res(2);

            PercDeltaLow(i) = sqrt(nObs)*(bounds_res(1) - LowerBoundEst);
            resLow(i) = bounds_res(1);
            
            goodIndices = [goodIndices i];
        else
            badIndices = [badIndices i];
        end
    end
    
    bias_ub = mean(resUp(goodIndices)) - UpperBoundEst;
    bias_lb = mean(resLow(goodIndices)) - LowerBoundEst;
    
    %estimated standard deviation
    sigma_IM_high = std(resUp(goodIndices));
    sigma_IM_low = std(resLow(goodIndices)); 
    
end



%%
if exitflag1 == 1
    %get coefficients c_IM
    optionsf = optimset('fsolve'); 
    optionsf = optimset(optionsf,'Display','Off');
    c_IM = fsolve(@(c)imFun(c,SignificanceLevel+(1-SignificanceLevel)/2,UpperBoundEst-LowerBoundEst,max(sigma_IM_low,sigma_IM_high)),0,optionsf);

    %Imbens and Manski Bias Correction
    ImBiasCRhigh = UpperBoundEst - bias_ub + c_IM*sigma_IM_high;
    ImBiasCRlow = LowerBoundEst - bias_lb - c_IM*sigma_IM_low;
    
else
    ImBiasCRlow = Inf;
    ImBiasCRhigh = -Inf;
end    



function F = imFun(c,quan,ubmlb,max_sigma)
    F = normcdf(c+ubmlb/max_sigma)-normcdf(-c)-quan;
end



end
