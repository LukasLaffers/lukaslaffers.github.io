
% results for Table 7
tic

load_data

resultsRelaxOpt   = zeros(9,2);
resultsRelaxOptCI = zeros(9,2);


rng('default')
nObs     = 313;
nSamples = 100;
SignificanceLevel = 0.9;

%generate bootstrap samples
randNums = rand(nSamples, nObs);
distributions = zeros(nSamples,16);
for iSample = 1:nSamples
    for jObs = 1:nObs
        ind = sum(randNums(iSample,jObs) > cumsum(reshape(probDistribution,16,1)))+1;
        distributions(iSample,ind) = distributions(iSample,ind) + 1;
    end
    distributions(iSample,:) = distributions(iSample,:)/nObs;
end

%%
%No relaxations
%look inside mdvelinprog_relax.m to see whichAssumptions is
% Roy, CBSR, MIV, cRoy, cCBSR
%relaxVector
% MOT, IND, Roy, CBSR, MIV, cRoy, cCBSR

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];
resultsRelaxOpt(1,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(1,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);

%%
%MOT
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.001 0 0 0 0 0 0];
resultsRelaxOpt(2,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(2,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%IND
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0.01 0 0 0 0 0];
resultsRelaxOpt(3,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(3,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%MIV
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0.01 0 0];
resultsRelaxOpt(4,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(4,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%cROY
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0.01 0];
resultsRelaxOpt(5,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(5,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%cCMBR
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0.01];
resultsRelaxOpt(6,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(6,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%optimistic
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.001 0 0 0 0.01 0.01 0.01];
resultsRelaxOpt(7,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxOptCI(7,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);



%%
%MISSING DATA

tic
missProportion = 0.01;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];

[lb,~,ub,~] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);
toc


resultsRelaxOpt(8,1) = lb;
resultsRelaxOpt(8,2) = ub;

%%
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.001 0 0 0 0.01 0.01 0.01];

tic
[lb,~,ub,~] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);

resultsRelaxOpt(9,1) = lb;
resultsRelaxOpt(9,2) = ub;

toc


%%


resultsRelaxPes   = zeros(9,2);
resultsRelaxPesCI = zeros(9,2);

nObs = 313;
SignificanceLevel = 0.9;

%%
%No relaxations
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];
resultsRelaxPes(1,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(1,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);

%%
%MOT
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.01 0 0 0 0 0 0];
resultsRelaxPes(2,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(2,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%IND
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0.05 0 0 0 0 0];
resultsRelaxPes(3,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(3,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%MIV
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0.05 0 0];
resultsRelaxPes(4,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(4,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%cROY
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0.01 0];
resultsRelaxPes(5,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(5,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%cCMBR
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0.05];
resultsRelaxPes(6,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(6,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%pessimistic
whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.01 0 0 0 0.05 0.05 0.05];
resultsRelaxPes(7,:) = mdvelinprog_relax(probDistribution, whichAssumptions, relaxVector);
resultsRelaxPesCI(7,:) = confidenceRegionIMBoth_relax(probDistribution,distributions,whichAssumptions,nObs,SignificanceLevel,relaxVector);


%%
%MISSING DATA

tic
missProportion = 0.05;

whichAssumptions = [0 0 1 1 1];
relaxVector  = [0 0 0 0 0 0 0];

[lb,~,ub,~] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);

resultsRelaxPes(8,1) = lb;
resultsRelaxPes(8,2) = ub;



whichAssumptions = [0 0 1 1 1];
relaxVector  = [0.01 0 0 0 0.05 0.05 0.05];

[lb,~,ub,~] = mdvelinprog_relax_miss(probDistribution, whichAssumptions, relaxVector,missProportion);

resultsRelaxPes(9,1) = lb;
resultsRelaxPes(9,2) = ub;
toc



toc