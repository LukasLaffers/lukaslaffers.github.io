function printfigpdf(hfig, filename, dims, fsize, lwidth)
% Print figure into eps file.

if nargin < 4
	fsize = 8;
end

if nargin < 5
	lwidth = 1;
end

% set position and size
% if in Octave, must set orientation (why?)
if (exist('OCTAVE_VERSION', 'builtin') == 5)
	if dims(1) > dims(2)
		set(hfig, 'PaperOrientation', 'landscape')
	else
		set(hfig, 'PaperOrientation', 'portrait')
	end
end
set(hfig, 'PaperPositionMode', 'manual');
set(hfig, 'PaperUnits', 'centimeters');
set(hfig, 'PaperPosition', [0 0 dims(1) dims(2)])
set(hfig, 'PaperSize', [dims(1) dims(2)])

% set linewidth
linobj = findall(hfig, 'type','line');
set(linobj, 'linewidth', lwidth)

% set font size
textobj = findall(hfig, '-property', 'fontsize');
set(textobj, 'fontunits', 'points');
set(textobj, 'fontsize', fsize)
set(textobj, 'fontname', 'Helvetica')

% export
print(hfig, '-dpdf', filename)

end

