%%
% run get_results_fig8.m

load results_MDVE


%%
F = figure;
colors = hsv(3);
offset = 0.001;

%%
% sensitivity SUPP
subplot(2,2,1)


p(1) = plot(supp_relax,resultsSensSUPP1(:,1)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(supp_relax,resultsSensSUPP1(:,2)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(supp_relax,resultsSensSUPP2(:,1)+offset,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(supp_relax,resultsSensSUPP2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(supp_relax,resultsSensSUPP3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(supp_relax,resultsSensSUPP3(:,2)+offset,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to MOT}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from MOT ($\alpha_{MOT}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');


hleg = legend([p(1),p(2),p(3)],'IND + cMIV + cROY + cCBSR','IND + cMIV','IND');
set(hleg,'Location','east')

set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(supp_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)

%%
%sensitivity cMIV
subplot(2,2,2)

p(1) = plot(cmiv_relax,resultsSensCMIV1(:,1)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(cmiv_relax,resultsSensCMIV1(:,2)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(cmiv_relax,resultsSensCMIV2(:,1)+offset,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(cmiv_relax,resultsSensCMIV2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(cmiv_relax,resultsSensCMIV3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(cmiv_relax,resultsSensCMIV3(:,2)+offset,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to cMIV}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from cMIV ($\alpha_{cMIV}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');


hleg = legend([p(1),p(2),p(3)],'IND + cMIV + cROY + cCBSR','IND + cMIV + cROY','IND + cMIV');
set(hleg,'Location','east')

set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(cmiv_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)

%%
% sensitivity cROY
subplot(2,2,3)

p(1) = plot(croy_relax,resultsSensCROY1(:,1)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(croy_relax,resultsSensCROY1(:,2)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(croy_relax,resultsSensCROY2(:,1)+offset,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(croy_relax,resultsSensCROY2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(croy_relax,resultsSensCROY3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(croy_relax,resultsSensCROY3(:,2)+offset,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to cROY}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from cROY ($\alpha_{cROY}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');


hleg = legend([p(1),p(2),p(3)],'IND + cMIV + cROY + cCBSR','IND + cMIV + cROY','IND + cRoy');
set(hleg,'Location','east')

set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(croy_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)



%%
% sensitivity cCBSR
subplot(2,2,4)

p(1) = plot(ccbsr_relax,resultsSensCCBSR1(:,1)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(ccbsr_relax,resultsSensCCBSR1(:,2)-offset,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(ccbsr_relax,resultsSensCCBSR2(:,1)+offset,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(ccbsr_relax,resultsSensCCBSR2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(ccbsr_relax,resultsSensCCBSR3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(ccbsr_relax,resultsSensCCBSR3(:,2)+offset,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to cCBSR}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from cCBSR ($\alpha_{cCBSR}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');


hleg = legend([p(1),p(2),p(3)],'IND + cMIV + cROY + cCBSR','IND + cMIV + cCBSR','IND + cCBSR');
set(hleg,'Location','east')

set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(ccbsr_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)



%%

set(F,'Units','Inches');
pos = get(F,'Position');
set(F,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

dim = [21*1.1 16*1.1];  % [width height], cm
fs = 8;                 % font size, points
lw = 2;                 % line width
printfigpdf(gcf(), 'figs\fig7.pdf', dim, fs, lw)