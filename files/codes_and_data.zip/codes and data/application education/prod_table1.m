%% 
% print results to tables1.tex file
% run get_results_table1.m


load('results_education')

my_folder = pwd;
file_1 = fopen([my_folder,'/tables/tables1','.tex'],'w');


Assumptions = {'No Assumption', 'MTR', 'MTS', 'cMTS', 'MTR+MTS', 'MTR+cMTS', 'MTR+MTS+MIV', 'MTR+cMTS+MIV'};

fprintf(file_1,' {\\small  \n');
fprintf(file_1,' \\renewcommand\\multirowsetup{\\centering} \n');
fprintf(file_1,' \\begin{center} \n');
fprintf(file_1,' \\begin{tabular}{ccccc} \n');
fprintf(file_1,'  \\noalign{\\hrule height 2pt} \n');
fprintf(file_1,' \\multicolumn{5}{c}{Bounds on the Effect of an Increase in the Mother''s (Father''s) College Education} \\\\ \n');
fprintf(file_1,' \\multicolumn{5}{c}{on the Probability the Child has a College Degree} \\\\ \n');
fprintf(file_1,'  \\noalign{\\hrule height 2pt} \n');
fprintf(file_1,' Outcome & \\multicolumn{4}{c}{Child''s college} \\\\ \n');
fprintf(file_1,' Treatment & \\multicolumn{2}{c}{Mother''s college} & \\multicolumn{2}{c}{Father''s college}\\\\ \n');
fprintf(file_1,' Instrument  & Father''s & Grandparent''s & Mother''s & Grandparent''s \\\\ \n');
fprintf(file_1,'  \\noalign{\\hrule height 2pt} \n');

for i = 1:length(Assumptions)
    if i == 4 || i == 6 || i == 7 || i == 8
        fprintf(file_1,' \\multirow{2}{90pt}{ %s} & [%g\\%%, %g\\%%] & [%g\\%%, %g\\%%]&[%g\\%%, %g\\%%] &[%g\\%%, %g\\%%] \\\\ \n',Assumptions{i},100*resultsTable1(2*i-1,:));
        fprintf(file_1,' & (%g\\%%, %g\\%%) & (%g\\%%, %g\\%%) & (%g\\%%, %g\\%%) & (%g\\%%, %g\\%%) \\vspace{1mm}\\\\ \n',100*resultsTable1(2*i,:));
    else
        fprintf(file_1,' \\multirow{2}{90pt}{ %s} & \\multicolumn{2}{c}{[%g\\%%, %g\\%%]} & \\multicolumn{2}{c}{[%g\\%%, %g\\%%]} \\\\ \n',Assumptions{i},100*resultsTable1(2*i-1,[1 2 5 6]));
        fprintf(file_1,' & \\multicolumn{2}{c}{(%g\\%%, %g\\%%)} & \\multicolumn{2}{c}{(%g\\%%, %g\\%%)} \\vspace{1mm}\\\\ \n',100*resultsTable1(2*i,[1 2 5 6]));

    end
    
end

fprintf(file_1,'  \\noalign{\\hrule height 2pt} \n');
fprintf(file_1,' Sample size & \\multicolumn{2}{c}{%g} &  \\multicolumn{2}{c}{%g} \\\\  \n', sampleSizes(1:2));
fprintf(file_1,' \\multicolumn{5}{l}{90\\%% confidence intervals in parentheses using the method of \\cite{im}} \\\\ \n');
fprintf(file_1,'  \\noalign{\\hrule height 2pt} \n');
fprintf(file_1,' \\end{tabular} \n');
fprintf(file_1,' \\end{center} \n');
fprintf(file_1,' } \n');



fid  = fopen([my_folder,'/tables/tables1','.tex'],'r');
f=fread(fid,'*char')';
fclose(fid);
f = regexprep(f,'-0\\%','0\\%');
fid  = fopen([my_folder,'/tables/tables1','.tex'],'w');
fprintf(fid,'%s',f);
fclose(fid);