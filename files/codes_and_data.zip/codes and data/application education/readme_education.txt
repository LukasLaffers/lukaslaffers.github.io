readme_education.txt 			-this file

readData.m				-loads the data

results_education.mat			-stores the results for Figures 1,2,3,4,5,6 and Tables 1,2,3,4,5

LowerBound.m				-calculates lower bound on ATE under (relaxed) ident. assumptions
LowerBoundMiss.m			-calculates lower bound on ATE under (relaxed) and miss ident. assumptions
UpperBound.m				-calculates upper bound on ATE under (relaxed) ident. assumptions
UpperBoundMiss.m			-calculates upper bound on ATE under (relaxed) and miss ident. assumptions

translateAssumptionsIntoLP.m 		-translates identifying assumptions into linear programming formulation
translateAssumptionsIntoLP_LM.m 	-translates identifying assumptions into linear programming formulation 
					 (with proper scaling of matrices A_cMTS and A_MIV so the LM have correct interpretation in Tables 3,4,5)

convertToStandardForm.m 		-converts the linear program into it’s standard form
generateBootstrapSamples.m 		-generates bootstrap samples

confidenceRegionIMBoth.m		-calculates confidence region (Imbens and Manski (2004)) under (relaxed) ident. assumptions
confidenceRegionIMBoth_miss.m 		-calculates confidence region under relaxed and miss assumptions

get_results_fig_5.m 			-obtains results for Figure 5
get_results_fig_6.m 			-obtains results for Figure 6

prodfig_1.m 				-reproduces Figure 1 in the paper
prodfig_2.m 				-reproduces Figure 2 in the paper
prodfig_3.m 				-reproduces Figure 3 in the paper
prodfig_4.m 				-reproduces Figure 4 in the paper
prodfig_5.m 				-reproduces Figure 5 in the paper
prodfig_6.m 				-reproduces Figure 6 in the paper

get_results_table1.m 			-obtains results for Table 1
get_results_table2.m 			-obtains results for Table 2
get_results_table2_part2.m 		-obtains results for Table 2 (confidence regions under miss assumption)
					 This takes about 12 hours on a laptop (i7 16GB RAM)
get_results_table3_4_5.m 	        -obtains results for Tables 3, 4 and 5 

prodtable_1.m				-reproduces Table 1 in the paper
prodtable_2.m				-reproduces Table 2 in the paper


auxiliary files:
maxfig.p 				-maximizes figure
allcomb.m 				-creates all combinations of variables with their given supports

