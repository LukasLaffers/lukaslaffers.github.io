%% 
%get results for Table2

resultsTable2 = zeros(4,9);
sampleSizes = zeros(1,4);

SignificanceLevel = 0.9;
nSamples = 500;

%%

%seven columns of Table2

display('Bounds on Average Treatment Effect obtained by Linear Programming');
fprintf(['Loading Data... ']);
clear Setup hlp
Setup = readData(1);
fprintf(['Data loaded.\n']);
observedProbs = array3D2vec(Setup.obs);

rng('default')

hlp = reshape(Setup.obs(:,:,1)',1,[]);
for j = 1:Setup.sizeI-1
    hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
end
ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);

sampleSizes = Setup.nObs;


%%

rng('default')

EconomicModel2.Assumption.Supp.Is = 'On';
EconomicModel2.Assumption.Supp.Relax = 0;
EconomicModel2.Assumption.Mtr.Is = 'On';
EconomicModel2.Assumption.Mtr.Relax = 0;
EconomicModel2.Assumption.Mts.Is = 'Off';
EconomicModel2.Assumption.Mts.Relax = 0;
EconomicModel2.Assumption.Cmts.Is = 'On';
EconomicModel2.Assumption.Cmts.Relax = 0;
EconomicModel2.Assumption.Miv.Is = 'On';
EconomicModel2.Assumption.Miv.Relax = 0;
EconomicModel2.Assumption.Msb.Is = 'Off';
EconomicModel2.Assumption.Msb.Relax = 0;
EconomicModel2.s = 2;
EconomicModel2.t = 1;

BenchmarkEconomicModel = EconomicModel2;

lbBench  = LowerBound(Setup,EconomicModel2);
ubBench  = UpperBound(Setup,EconomicModel2);
[lbBench,ubBench]

%CR
tic
[ImBiasCRlowBench,ImBiasCRhighBench] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlowBench,ImBiasCRhighBench]
toc


%%

%\alpha_MTR = 0.01
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.01;
lb  = LowerBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(1,1) = round(1000*lb)/1000;
resultsTable2(2,1) = round(1000*ImBiasCRlow)/1000;

%\alpha_MTR = 0.05
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.05;
lb  = LowerBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(3,1) = round(1000*lb)/1000;
resultsTable2(4,1) = round(1000*ImBiasCRlow)/1000;

%%

%\alpha_MOT = 0.001
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Supp.Relax = 0.001;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(1,2) = round(1000*ub)/1000;
resultsTable2(2,2) = round(1000*ImBiasCRhigh)/1000;

%\alpha_MOT = 0.01
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Supp.Relax = 0.01;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(3,2) = round(1000*ub)/1000;
resultsTable2(4,2) = round(1000*ImBiasCRhigh)/1000;

%%

%\alpha_cMTS = 0.01
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Cmts.Relax = 0.01;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(1,3) = round(1000*ub)/1000;
resultsTable2(2,3) = round(1000*ImBiasCRhigh)/1000;

%\alpha_cMTS = 0.05
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Cmts.Relax = 0.05;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(3,3) = round(1000*ub)/1000;
resultsTable2(4,3) = round(1000*ImBiasCRhigh)/1000;

%%

%\alpha_MIV = 0.01
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Miv.Relax = 0.01;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(1,4) = round(1000*ub)/1000;
resultsTable2(2,4) = round(1000*ImBiasCRhigh)/1000;

%\alpha_MIV = 0.05
EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Miv.Relax = 0.05;
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(3,4) = round(1000*ub)/1000;
resultsTable2(4,4) = round(1000*ImBiasCRhigh)/1000;


%%
%\alpha_MISS = 0.01
EconomicModel2 = BenchmarkEconomicModel;
miss_relax = 0.01;


ub  = UpperBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);
ub

resultsTable2(1,5) = round(1000*ub)/1000;
%resultsTable2(2,5) is calculated in get_results_table2_part2.m


%\alpha_MISS = 0.1
EconomicModel2 = BenchmarkEconomicModel;
miss_relax = 0.1;

ub  = UpperBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);
ub

resultsTable2(3,5) = round(1000*ub)/1000;
%resultsTable2(4,5) is calculated in get_results_table2_part2.m


%%
%\alpha_MTR = 0.01
%\alpha_MOT = 0.001
%\alpha_cMTS = 0.01
%\alpha_MIV  = 0.01

EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.01;
EconomicModel2.Assumption.Supp.Relax = 0.001;
EconomicModel2.Assumption.Cmts.Relax = 0.01;
EconomicModel2.Assumption.Miv.Relax = 0.01;
lb  = LowerBound(Setup,EconomicModel2);
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(1,6:7) = [round(1000*lb)/1000, round(1000*ub)/1000];
resultsTable2(2,6:7) = [round(1000*ImBiasCRlow)/1000,round(1000*ImBiasCRhigh)/1000];

%
%\alpha_MTR = 0.05
%\alpha_MOT = 0.01
%\alpha_cMTS = 0.05
%\alpha_MIV  = 0.05

EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.05;
EconomicModel2.Assumption.Supp.Relax = 0.01;
EconomicModel2.Assumption.Cmts.Relax = 0.05;
EconomicModel2.Assumption.Miv.Relax = 0.05;
lb  = LowerBound(Setup,EconomicModel2);
ub  = UpperBound(Setup,EconomicModel2);

%CR
tic
[ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
[ImBiasCRlow,ImBiasCRhigh]
toc

resultsTable2(3,6:7) = [round(1000*lb)/1000, round(1000*ub)/1000];
resultsTable2(4,6:7) = [round(1000*ImBiasCRlow)/1000,round(1000*ImBiasCRhigh)/1000];



%%
%\alpha_MTR = 0.01
%\alpha_MOT = 0.001
%\alpha_cMTS = 0.01
%\alpha_MIV  = 0.01
%\alpha_MISS  = 0.01


EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.01;
EconomicModel2.Assumption.Supp.Relax = 0.001;
EconomicModel2.Assumption.Cmts.Relax = 0.01;
EconomicModel2.Assumption.Miv.Relax = 0.01;
miss_relax = 0.01;

lb  = LowerBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);
ub  = UpperBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);
[lb,ub]

resultsTable2(1,8:9) = [round(1000*lb)/1000, round(1000*ub)/1000];
%resultsTable2(2,8:9) is calculated in get_results_table2_part2.m


%\alpha_MTR = 0.05
%\alpha_MOT = 0.01
%\alpha_cMTS = 0.05
%\alpha_MIV  = 0.05
%\alpha_MISS  = 0.1

EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.05;
EconomicModel2.Assumption.Supp.Relax = 0.01;
EconomicModel2.Assumption.Cmts.Relax = 0.05;
EconomicModel2.Assumption.Miv.Relax = 0.05;
miss_relax = 0.1;


lb  = LowerBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);
ub  = UpperBoundMiss(Setup,EconomicModel2,miss_relax,observedProbs);

resultsTable2(3,8:9) = [round(1000*lb)/1000, round(1000*ub)/1000];
%resultsTable2(4,8:9) is calculated in get_results_table2_part2.m

