%
% get results for Figure 5

%bounds on the probability that child with a college educated mother
%will also get college education, monotone instrument is education level
%of a grandparent

Y = [0 1];
sizeY = length(Y);
Z = [1 2];
sizeZ = length(Z);
I = [1 2 3 4];
sizeI = length(I);
s = 1; t = 2;

%vecUnobs = allcomb(Y,Y,Y,Y); %sizeZ times
%vector of unobservables
vecUnobs = allcomb(Y,Y);

%vector of observables
vecObs = allcomb(Y,Z,I);

Setup = readData(1);

obs = Setup.obs;

%%
% results SUPP relaxation

supp_relax = 1 - [1:-0.01:0.9];
h = size(supp_relax,2);
resultsSensSUPP1 = zeros(h,2);
resultsSensSUPP2 = zeros(h,2);
resultsSensSUPP3 = zeros(h,2);


EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Supp.Relax = supp_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensSUPP1(i,1) = low;
    resultsSensSUPP1(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'Off';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Supp.Relax = supp_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensSUPP2(i,1) = low;
    resultsSensSUPP2(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'Off';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;

for i = 1:h
    EconomicModel.Assumption.Supp.Relax = supp_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensSUPP3(i,1) = low;
    resultsSensSUPP3(i,2) = high;
end


%%
% results MTR relaxation
mtr_relax = 1-[1:-0.01:0.9];
h = size(mtr_relax,2);
resultsSensMTR1 = zeros(h,2);
resultsSensMTR2 = zeros(h,2);
resultsSensMTR3 = zeros(h,2);


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Mtr.Relax = mtr_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMTR1(i,1) = low;
    resultsSensMTR1(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Mtr.Relax = mtr_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMTR2(i,1) = low;
    resultsSensMTR2(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'Off';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Mtr.Relax = mtr_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMTR3(i,1) = low;
    resultsSensMTR3(i,2) = high;
end


%%
% results MTS relaxation
cmts_relax = 0:0.01:0.1;
h = size(cmts_relax,2);
resultsSensCMTS1 = zeros(h,2);
resultsSensCMTS2 = zeros(h,2);
resultsSensCMTS3 = zeros(h,2);


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Cmts.Relax = cmts_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensCMTS1(i,1) = low;
    resultsSensCMTS1(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'Off';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Cmts.Relax = cmts_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensCMTS2(i,1) = low;
    resultsSensCMTS2(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'Off';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'Off';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;



for i = 1:h
    EconomicModel.Assumption.Cmts.Relax = cmts_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensCMTS3(i,1) = low;
    resultsSensCMTS3(i,2) = high;
end




%%
% results MIV relaxation

miv_relax = 0:0.01:0.1;
h = size(miv_relax,2);
resultsSensMIV1 = zeros(h,2);
resultsSensMIV2 = zeros(h,2);
resultsSensMIV3 = zeros(h,2);


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Miv.Relax = miv_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMIV1(i,1) = low;
    resultsSensMIV1(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;



for i = 1:h
    EconomicModel.Assumption.Miv.Relax = miv_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMIV2(i,1) = low;
    resultsSensMIV2(i,2) = high;
end


EconomicModel.s = 1;
EconomicModel.t = 2;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'Off';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;


for i = 1:h
    EconomicModel.Assumption.Miv.Relax = miv_relax(i);
    low  = LowerBound(Setup,EconomicModel);
    high = UpperBound(Setup,EconomicModel);
    resultsSensMIV3(i,1) = low;
    resultsSensMIV3(i,2) = high;
end



