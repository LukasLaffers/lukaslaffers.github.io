
display('Bounds on Average Treatment Effect obtained by Linear Programming');
fprintf(['Loading Data... ']);
clear Setup hlp
Setup = readData(1);
fprintf(['Data loaded.\n']);


%%
%MTR+cMTS
EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'Off';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;
lb  = LowerBound(Setup,EconomicModel);
ub  = UpperBound(Setup,EconomicModel);


LinearProgram   =  translateAssumptionsIntoLP(EconomicModel,Setup,0);

nIneq    = length(LinearProgram.InVector);
nEq      = length(LinearProgram.EqVector);

problem.Aeq = [LinearProgram.EqMatrix];
problem.Aineq = [LinearProgram.IneqMatrix];
problem.beq = [LinearProgram.EqVector];
problem.bineq = [ LinearProgram.InVector];
problem.lb = [zeros(1, length(LinearProgram.Ate))];
problem.ub = [];
problem.f = [LinearProgram.Ate];
problem.solver = 'linprog';
problem.options = optimset('linprog');
problem.options = optimset(problem.options,'TolFun',1e-8,'Algorithm','simplex','Display','off','LargeScale','off');


[~,fval] = linprog(problem);
ub = -fval;

display(['Upper bound on ATE under MTR+cMTS = ', num2str(ub)])


problem.Aineq = LinearProgram.IneqMatrix([2:4 6:8],:);
problem.bineq = [ LinearProgram.InVector([2:4 6:8])];
[~,fval] = linprog(problem);
ub = -fval;

display(['Upper bound on ATE under MTR+cMTS (for v = 2,3,4 only) = ', num2str(ub)])


%%
%MTR+cMTS+MIV
EconomicModel2.s = 2;
EconomicModel2.t = 1;
EconomicModel2.Assumption.Supp.Is = 'On';
EconomicModel2.Assumption.Supp.Relax = 0;
EconomicModel2.Assumption.Mtr.Is = 'On';
EconomicModel2.Assumption.Mtr.Relax = 0;
EconomicModel2.Assumption.Mts.Is = 'Off';
EconomicModel2.Assumption.Mts.Relax = 0;
EconomicModel2.Assumption.Cmts.Is = 'On';
EconomicModel2.Assumption.Cmts.Relax = 0;
EconomicModel2.Assumption.Miv.Is = 'On';
EconomicModel2.Assumption.Miv.Relax = 0;
EconomicModel2.Assumption.Msb.Is = 'Off';
EconomicModel2.Assumption.Msb.Relax = 0;
lb  = LowerBound(Setup,EconomicModel2)
ub  = UpperBound(Setup,EconomicModel2)

%%
LinearProgram   =  translateAssumptionsIntoLP_LM(EconomicModel2,Setup,0);


nIneq    = length(LinearProgram.InVector);
nEq      = length(LinearProgram.EqVector);

problem.Aeq = [LinearProgram.EqMatrix];
problem.Aineq = [LinearProgram.IneqMatrix];
problem.beq = [LinearProgram.EqVector];
problem.bineq = [ LinearProgram.InVector];
problem.lb = [zeros(1, length(LinearProgram.Ate))];
problem.ub = [];
problem.f = [LinearProgram.Ate];
problem.solver = 'linprog';

problem.options = optimset('linprog');
problem.options = optimset(problem.options,'TolFun',1e-8,'Algorithm','simplex','Display','off','LargeScale','off');
[~,fval,exitflag,output,lambda] = linprog(problem);
ub = -fval;

display(['Upper bound on ATE under MTR+cMTS+MIV = ', num2str(ub)])

%Table 4 results
round(1000*lambda.ineqlin)/1000




%%

problem.Aineq = LinearProgram.IneqMatrix([2:7 9:14],:);
problem.bineq = [ LinearProgram.InVector([2:7 9:14])];


[~,fval,exitflag,output,lambda] = linprog(problem);
ub = -fval;

display(['Upper bound on ATE under MTR+cMTS+MIV (for v = 2,3,4 only) = ', num2str(ub)])

%Table 5 results
round(1000*lambda.ineqlin)/1000
