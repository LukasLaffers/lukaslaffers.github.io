%% 
%get results for Table1

resultsTable1 = zeros(16,4);
sampleSizes = zeros(1,4);

SignificanceLevel = 0.9;
nSamples = 500;

%%
rng('default')

for i = 1:4 %four columns of Table1
    i
    display('Bounds on Average Treatment Effect obtained by Linear Programming');
    fprintf(['Loading Data... ']);
    clear Setup hlp
    Setup = readData(i);
    fprintf(['Data loaded.\n']);

    sampleSizes(i) = Setup.nObs;
    Setup.nObs
    
    %no assumptions
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'Off';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'Off';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'Off';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(1,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(2,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    %MTR
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'On';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'Off';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'Off';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(3,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(4,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    
    %MTS
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'Off';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'On';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'Off';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(5,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(6,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    
    %cMTS
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'Off';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'Off';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'On';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(7,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(8,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    %MTR + MTS
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'On';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'On';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'Off';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(9,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(10,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    %MTR+cMTS
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'On';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'Off';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'On';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'Off';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(11,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(12,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    %MTR+MTS+MIV
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'On';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'On';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'Off';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'On';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(13,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(14,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
    %MTR+cMTS+MIV
    EconomicModel.s = 2;
    EconomicModel.t = 1;
    EconomicModel.Assumption.Supp.Is = 'On';
    EconomicModel.Assumption.Supp.Relax = 0;
    EconomicModel.Assumption.Mtr.Is = 'On';
    EconomicModel.Assumption.Mtr.Relax = 0;
    EconomicModel.Assumption.Mts.Is = 'Off';
    EconomicModel.Assumption.Mts.Relax = 0;
    EconomicModel.Assumption.Cmts.Is = 'On';
    EconomicModel.Assumption.Cmts.Relax = 0;
    EconomicModel.Assumption.Miv.Is = 'On';
    EconomicModel.Assumption.Miv.Relax = 0;
    EconomicModel.Assumption.Msb.Is = 'Off';
    EconomicModel.Assumption.Msb.Relax = 0;
    lb  = LowerBound(Setup,EconomicModel);
    ub  = UpperBound(Setup,EconomicModel);
    resultsTable1(15,[(2*i-1) 2*i]) = [round(1000*lb)/1000 round(1000*ub)/1000];
    [lb,ub]
    
    %CR
    tic
    hlp = reshape(Setup.obs(:,:,1)',1,[]);
    for j = 1:Setup.sizeI-1
        hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
    end
    ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
    MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);
    [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbs,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs);
    resultsTable1(16,[(2*i-1) 2*i]) = [round(1000*ImBiasCRlow)/1000 round(1000*ImBiasCRhigh)/1000];
    [ImBiasCRlow,ImBiasCRhigh]
    toc
    
end