function [lb,x_lo,exitflag_lo] = LowerBoundMiss(Setup,EconomicModel,miss,vobs)

    
tic
LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,Setup,0);

SizeOfObsVariables = size(Setup.vecObs,1);

ZerosObs = zeros(1,SizeOfObsVariables);
OnesObs = ones(1,SizeOfObsVariables);


n = Setup.nObs;
m = miss*Setup.nObs;

SetupHelp = Setup;
SetupHelp.obs = vec2array3D(vobs,Setup);

options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',5000,...
                   'GradConstr','off','GradObj','off',...
                   'Hessian','lbfgs');

[x_lo,fval_lo,exitflag_lo] = fmincon(@(p)LowerBound(SetupHelp,EconomicModel,constructMixedProbs(vobs,p,n,m)),...
    LinearProgramHelp.DataVector,[],[],ones(1,SizeOfObsVariables),1,...
    ZerosObs,OnesObs,[],options);

lb = fval_lo;
toc



function [array3D] = vec2array3D(vector,Setup)
    hlp = reshape(vector,Setup.sizeI,Setup.sizeY*Setup.sizeZ);
    for i = 1:Setup.sizeI
        array3D(:,:,i) = reshape(hlp(i,:),Setup.sizeZ,Setup.sizeY)';
    end
end


function [MixedProbs] = constructMixedProbs(ObservedProbs,MissingProbs,n,m)
    MixedProbs = ObservedProbs*(n/(n+m))+MissingProbs*(m/(n+m));
end

end