% reproduces Figure 1 in the paper

Setup = readData(1);

F = figure;
maxfig(F,1);

Y = [0 1];
sizeY = length(Y);
Z = [1 2];
sizeZ = length(Z);
I = [1 2 3 4];
sizeI = length(I);


%vecUnobs = allcomb(Y,Y,Y,Y); %sizeZ times
%vector of unobservables
vecUnobs = allcomb(Y,Y);

%vector of observables
vecObs = allcomb(Y,Z,I);



%%
%matrix SUPP stores so called "support restrictions", it is a restriction
%that every individual has a deterministic (yet unknown) function from the
%space of treatments to the space of outcomes
SUPP = ones(sizeY^sizeZ,sizeY*sizeZ*sizeI);
for i = 1:sizeY
    for j = 1:sizeZ
        for k = 1:sizeI
            %set penalty equal to zero only to those pairs of obs-s and
            %unobser-s that are compatible. If I observe some fraction of
            %people with (Y,Z) equal to (0,1), it means that these people
            %will always have Y(1)=1, regardless of what Y(0) or Y(2) is.
            %find those rows in vecUnobs for which there is Y(i) in the
            %j-th column.
            where = find(vecUnobs(:,j) == Y(i));
            %pick column which corresponds to observed value (i,j,k)
            SUPP(where,(i-1)*sizeZ*sizeI + (j-1)*sizeI+k) = zeros(length(where),1);
        end
    end
end
%%
%matrix MTR stores the restriction that for every individual, outcome must
%be monotonous in potential outcomes.
MTR = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
check = zeros(sizeY^sizeZ,1); 
for i = 1:sizeY^sizeZ
    for j = 1:sizeZ-1
        if vecUnobs(i,j)>vecUnobs(i,j+1)
        check(i) =  1;
        end
    end
end
%put a penalty of one to the corresponding rows (those where MTR is violated)
MTR(find(check),:) = ones(sum(check),sizeY*sizeZ*sizeI);

%%    
    
[row_supp,col_supp] = find(1-SUPP');
[row_supp1,col_supp1] = find(SUPP');
[row_mtr,col_mtr] = find((1-SUPP').*(MTR'));
so = size(vecObs,1);
su = size(vecUnobs,1);

EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0.01;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;
[lb,sol_l]  = LowerBound2(Setup,EconomicModel);
[ub,sol_u]  = UpperBound2(Setup,EconomicModel);


reset(gca);
a = gca;
scatter(row_supp,col_supp,200,'black','filled')
hold on;
scatter(row_supp1,col_supp1,450,[0.95 0.95 0.95],'Marker','x','LineWidth',3)
hold on;

scatter(row_supp1,col_supp1,200,[0.95 0.95 0.95],'filled')

vecObs2 = vecObs;
vecObs2(:,2) = vecObs(:,2) - 1; 

xticker = [repmat('(',[so,1]),num2str(vecObs(:,1))];
yticker = [repmat('(',[su,1]),num2str(vecUnobs(:,1))];

for i = 1:2
    xticker = [xticker,repmat(',',[so,1]), num2str(vecObs2(:,i+1))];
end
for i = 1:sizeZ-1
    yticker = [yticker,repmat(',',[su,1]), num2str(vecUnobs(:,i+1))];
end

xticker = [xticker,repmat([')'],[so,1])];
yticker = [yticker,repmat(')',[su,1])];

set(a,'FontSize',20)
set(a,'Title',text('String','\textsf{\bf{Correct specification:} $\forall i,t: D_i=t \ \Longrightarrow \ Y_i = Y_i(t)$}','Color','black','FontSize',30,'FontWeight','bold','Interpreter','latex'))
set(get(a,'XLabel'),'String',{'';'';'\bf Observed $(Y,D,V)$'},'Color','black','FontSize',30,'Interpreter','latex')
set(get(a,'YLabel'),'String','\bf Unobserved $\left(Y(0),Y(1)\right)$','Color','black','FontSize',30,'Interpreter','latex')
set(a,'Xlim',[0.5,so+0.5])
set(a,'Ylim',[0.5,su+1])
set(a,'XTick',[1:so])
set(a,'YTick',[1:su])
set(a,'XTickLabel',xticker)
set(a,'YTickLabel',yticker)

hleg = legend('Observed and unobserved component are compatible','Observed and unobserved component are not compatible');
set(hleg,'Location','NorthWest')

M = findobj(hleg,'type','patch'); % Find objects of type 'patch'
set(M,'MarkerSize', 10,'LineWidth',3)

set(gca, 'xticklabel', [])

% Get tick positions
yTicks = get(gca,'ytick');
xTicks = get(gca, 'xtick');

% Reset the XTicklabels onto multiple lines, 2nd line being twice of first
minY = min(yTicks);
% You will have to adjust the offset based on the size of figure
VerticalOffset = 0.6;
HorizontalOffset = 0.0;

for xx = 1:length(xTicks)
% Create a text box at every Tick label position
% String is specified as LaTeX string and other appropriate properties are set
%text(xTicks(xx) - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}',xticker(xx,:),'\\',num2str(round(2000*vobs(xx))/2000),'\end{array}$$'],'FontSize',20, 'Interpreter', 'latex','FontWeight','bold')
text(xTicks(xx) - HorizontalOffset, minY - VerticalOffset, [xticker(xx,:)],'FontSize',20,...
                    'HorizontalAlignment','center')
% {c} specifies that the elements of the different lines will be center
% aligned. It may be replaced by {l} or {r} for left or right alignment
end

xlabh = get(gca,'XLabel');
set(xlabh,'Units','data');
set(xlabh,'Position',get(xlabh,'Position') + [0 0.2 0])


set(F,'Units','Inches');
pos = get(F,'Position');
set(F,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

print -depsc2 figs\fig1.eps

