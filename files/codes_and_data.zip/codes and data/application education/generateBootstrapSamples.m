function [MatrixOfSamples] = generateBootstrapSamples(probabilityVector,n,nSamples)
%generate samples WITH replacement

ecdf = cumsum(probabilityVector);
MatrixOfSamples = zeros(length(probabilityVector),nSamples);

for i = 1:nSamples
    sim = rand(n,1);  %now generate the matrix of random numbers
    ssim = sort(sim);   %sort them, every row is in ascending order
    h = histc(ssim(:,:),[0;ecdf])/n;
    h = h(1:end-1,:);
    MatrixOfSamples(:,i) = h;
end



