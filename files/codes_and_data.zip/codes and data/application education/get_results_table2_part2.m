%% 
% results for Table 2 (confidence regions under relaxed MISS assumption)
% takes a long time (6hours on an i7 16GB ram laptop)
% results are saved separately in
% resultsMiss1.mat
% resultsMiss2.mat
% resultsMiss3.mat
% resultsMiss4.mat

rng('default')

SignificanceLevel = 0.9;
nSamples = 200; %reduced from 500


display('Bounds on Average Treatment Effect obtained by Linear Programming');
fprintf(['Loading Data... ']);
clear Setup hlp
Setup = readData(1);
fprintf(['Data loaded.\n']);
observedProbs = array3D2vec(Setup.obs);


EconomicModel2.Assumption.Supp.Is = 'On';
EconomicModel2.Assumption.Supp.Relax = 0;
EconomicModel2.Assumption.Mtr.Is = 'On';
EconomicModel2.Assumption.Mtr.Relax = 0;
EconomicModel2.Assumption.Mts.Is = 'Off';
EconomicModel2.Assumption.Mts.Relax = 0;
EconomicModel2.Assumption.Cmts.Is = 'On';
EconomicModel2.Assumption.Cmts.Relax = 0;
EconomicModel2.Assumption.Miv.Is = 'On';
EconomicModel2.Assumption.Miv.Relax = 0;
EconomicModel2.Assumption.Msb.Is = 'Off';
EconomicModel2.Assumption.Msb.Relax = 0;
EconomicModel2.s = 2;
EconomicModel2.t = 1;

BenchmarkEconomicModel = EconomicModel2;


rng('default')

hlp = reshape(Setup.obs(:,:,1)',1,[]);
for j = 1:Setup.sizeI-1
    hlp = [hlp;reshape(Setup.obs(:,:,j+1)',1,[])];
end
ObservedProbs = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);
MatrixOfSamples = generateBootstrapSamples(ObservedProbs,Setup.nObs,nSamples);



%%
%\alpha_MISS = 0.01
EconomicModel2 = BenchmarkEconomicModel;
miss_relax = 0.01;


%CR
tic
[ImBiasCRlow,ImBiasCRhigh,resLow,resUp,times] = confidenceRegionIMBoth_miss(ObservedProbs,Setup,...
    EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs,miss_relax);
[ImBiasCRlow,ImBiasCRhigh]
toc


%resultsTable2(1,5) is calculated in get_results_table2.m
resultsTable2(2,5) = round(1000*ImBiasCRhigh)/1000;


%save('resultsMiss1.mat','ImBiasCRlow','ImBiasCRhigh','resLow','resUp','times');


%%

%\alpha_MISS = 0.1
EconomicModel2 = BenchmarkEconomicModel;
miss_relax = 0.1;

%CR
tic
[ImBiasCRlow,ImBiasCRhigh,resLow,resUp,times] = confidenceRegionIMBoth_miss(ObservedProbs,Setup,...
    EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs,miss_relax);
[ImBiasCRlow,ImBiasCRhigh]
toc


%resultsTable2(3,5) is calculated in get_results_table2.m
resultsTable2(4,5) = round(1000*ImBiasCRhigh)/1000;


%save('resultsMiss2.mat','ImBiasCRlow','ImBiasCRhigh','resLow','resUp','times');


%%

%\alpha_MTR = 0.01
%\alpha_MOT = 0.001
%\alpha_cMTS = 0.01
%\alpha_MIV  = 0.01
%\alpha_MISS  = 0.01


EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.01;
EconomicModel2.Assumption.Supp.Relax = 0.001;
EconomicModel2.Assumption.Cmts.Relax = 0.01;
EconomicModel2.Assumption.Miv.Relax = 0.01;
miss_relax = 0.01;

%CR
tic
[ImBiasCRlow,ImBiasCRhigh,resLow,resUp,times] = confidenceRegionIMBoth_miss(ObservedProbs,Setup,...
    EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs,miss_relax);
[ImBiasCRlow,ImBiasCRhigh]
toc

%resultsTable2(1,8:9) is calculated in get_results_table2.m
resultsTable2(2,8:9) = [round(1000*ImBiasCRlow), round(1000*ImBiasCRhigh)/1000];


%save('resultsMiss3.mat','ImBiasCRlow','ImBiasCRhigh','resLow','resUp','times');



%\alpha_MTR = 0.05
%\alpha_MOT = 0.01
%\alpha_cMTS = 0.05
%\alpha_MIV  = 0.05
%\alpha_MISS  = 0.1

EconomicModel2 = BenchmarkEconomicModel;
EconomicModel2.Assumption.Mtr.Relax = 0.05;
EconomicModel2.Assumption.Supp.Relax = 0.01;
EconomicModel2.Assumption.Cmts.Relax = 0.05;
EconomicModel2.Assumption.Miv.Relax = 0.05;
miss_relax = 0.1;

%CR
tic
[ImBiasCRlow,ImBiasCRhigh,resLow,resUp,times] = confidenceRegionIMBoth_miss(ObservedProbs,Setup,...
    EconomicModel2,SignificanceLevel,nSamples,MatrixOfSamples,Setup.nObs,miss_relax);
[ImBiasCRlow,ImBiasCRhigh]
toc

%resultsTable2(3,8:9) is calculated in get_results_table2.m
resultsTable2(4,8:9) = [round(1000*ImBiasCRlow), round(1000*ImBiasCRhigh)/1000];

%save('resultsMiss4.mat','ImBiasCRlow','ImBiasCRhigh','resLow','resUp','times');

