function [ImBiasCRlow,ImBiasCRhigh] = confidenceRegionIMBoth(ObservedProbabilities,Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples2,n)

clear res

%% upperbound
%create a LP
SetupHelp = Setup;
SetupHelp.obs = vec2array3D(ObservedProbabilities,Setup);
LinearProgram   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);

%convert it into the standard form
problem = convertToStandardForm(LinearProgram);
problem.f = -problem.f;

%find solution
[~,fval1,exitflag1] = linprog(problem);
UpperBoundEst = -fval1;

if exitflag1 == 1

    PercDelta = zeros(nSamples,1);
    res = zeros(nSamples,1);

    for i = 1:nSamples
        %i
        SetupHelp = Setup;
        SetupHelp.obs = vec2array3D(MatrixOfSamples2(:,i),Setup);
        LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
        problemHelp = convertToStandardForm(LinearProgramHelp);
        problemHelp.f = -problemHelp.f;
        [~,fval2] = linprog(problemHelp);
        PercDelta(i) = sqrt(n)*((-fval2) - UpperBoundEst);
        res(i) = -fval2;
    end
    
    bias_ub = mean(res) - UpperBoundEst;
    
    %estimated standard deviation
    sigma_IM_high = std(res);
end

%% lower bound
%create a LP
SetupHelp = Setup;
SetupHelp.obs = vec2array3D(ObservedProbabilities,Setup);
LinearProgram   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);

%convert it into the standard form
problem = convertToStandardForm(LinearProgram);

%find solution
[~,fval1,exitflag1] = linprog(problem);
LowerBoundEst = fval1;

if exitflag1 == 1

    PercDelta = zeros(nSamples,1);
    res = zeros(nSamples,1);

    for i = 1:nSamples
        %i
        SetupHelp = Setup;
        SetupHelp.obs = vec2array3D(MatrixOfSamples2(:,i),Setup);
        LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
        problemHelp = convertToStandardForm(LinearProgramHelp);
        [~,fval2] = linprog(problemHelp);
        PercDelta(i) = sqrt(n)*((fval2) - LowerBoundEst);
        res(i) = fval2;
    end

    bias_lb = mean(res) - LowerBoundEst;
    
    %estimated standard deviation
    sigma_IM_low = std(res);
end




if exitflag1 == 1
    %get coefficients c_IM
    optionsf = optimset('fsolve'); 
    optionsf = optimset(optionsf,'Display','Off');
    c_IM = zeros(length(SignificanceLevel),1);
    for i = 1:length(SignificanceLevel)
        c_IM(i) = fsolve(@(c)imFun(c,SignificanceLevel(i)+(1-SignificanceLevel(i))/2,UpperBoundEst-LowerBoundEst,max(sigma_IM_low,sigma_IM_high)),0,optionsf);
    end
    

    %Imbens and Manski Bias Corrected
    ImBiasCRhigh = UpperBoundEst - bias_ub + c_IM*sigma_IM_high;
    ImBiasCRlow = LowerBoundEst - bias_lb - c_IM*sigma_IM_low;
    
else
    ImBiasCRlow = Inf;
    ImBiasCRhigh = -Inf;
end  


function F = imFun(c,quan,ubmlb,max_sigma)
    F = normcdf(c+ubmlb/max_sigma)-normcdf(-c)-quan;
end

function [array3D] = vec2array3D(vector,Setup)
    hlp = reshape(vector,Setup.sizeI,Setup.sizeY*Setup.sizeZ);
    for iArray = 1:Setup.sizeI
        array3D(:,:,iArray) = reshape(hlp(iArray,:),Setup.sizeZ,Setup.sizeY)';
    end
end

end

