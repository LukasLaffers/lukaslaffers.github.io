function [ImBiasCRlow,ImBiasCRhigh,resLow,resUp,times] = confidenceRegionIMBoth_miss(ObservedProbabilities,...
    Setup,EconomicModel,SignificanceLevel,nSamples,MatrixOfSamples2,n,missProportion)

clear res

%% upperbound

UpperBoundEst = UpperBoundMiss(Setup,EconomicModel,missProportion,ObservedProbabilities);

PercDelta = zeros(nSamples,1);
resUp = zeros(nSamples,1);
times = zeros(2*nSamples,1);

for i = 1:nSamples
    i
    tic
    fval2 = UpperBoundMiss(Setup,EconomicModel,missProportion,MatrixOfSamples2(:,i))

    PercDelta(i) = sqrt(n)*((fval2) - UpperBoundEst);
    resUp(i) = fval2;
    
    times(i) = toc;
end


bias_ub = mean(resUp) - UpperBoundEst;

%estimated standard deviation
sigma_IM_high = std(resUp);

%% lower bound
%create a LP
LowerBoundEst = LowerBoundMiss(Setup,EconomicModel,missProportion,ObservedProbabilities);


PercDelta = zeros(nSamples,1);
resLow = zeros(nSamples,1);

for i = 1:nSamples
    i 
    tic
    fval2 = LowerBoundMiss(Setup,EconomicModel,missProportion,MatrixOfSamples2(:,i));

    PercDelta(i) = sqrt(n)*((fval2) - LowerBoundEst);
    resLow(i) = fval2;
    times(nSamples+i) = toc;
end

bias_lb = mean(resLow) - LowerBoundEst;

%estimated standard deviation
sigma_IM_low = std(resLow);


%get coefficients c_IM
optionsf = optimset('fsolve'); 
optionsf = optimset(optionsf,'Display','Off');
c_IM = zeros(length(SignificanceLevel),1);
for i = 1:length(SignificanceLevel)
    c_IM(i) = fsolve(@(c)imFun(c,SignificanceLevel(i)+(1-SignificanceLevel(i))/2,UpperBoundEst-LowerBoundEst,max(sigma_IM_low,sigma_IM_high)),0,optionsf);
end



%Imbens and Manski Bias Corrected
ImBiasCRhigh = UpperBoundEst - bias_ub + c_IM*sigma_IM_high;
ImBiasCRlow = LowerBoundEst - bias_lb - c_IM*sigma_IM_low;
     


function F = imFun(c,quan,ubmlb,max_sigma)
    F = normcdf(c+ubmlb/max_sigma)-normcdf(-c)-quan;
end



end

