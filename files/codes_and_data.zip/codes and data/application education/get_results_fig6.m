% get results for Figure 6

Setup = readData(1);
miss_relax  = [0:0.025:0.1];
h = size(miss_relax,2);
resultsSensMiss1 = zeros(h,2);
resultsSensMiss2 = zeros(h,2);
resultsSensMiss3 = zeros(h,2);



%%
EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'On';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;



for i = 1:h
     
    low  = LowerBoundMiss(Setup,EconomicModel,miss_relax(i));
    high = UpperBoundMiss(Setup,EconomicModel,miss_relax(i));
    resultsSensMiss1(i,1) = low;
    resultsSensMiss1(i,2) = high;
end

%%
EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'On';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;



for i = 1:h
     
    low  = LowerBoundMiss(Setup,EconomicModel,miss_relax(i));
    high = UpperBoundMiss(Setup,EconomicModel,miss_relax(i));
    resultsSensMiss2(i,1) = low;
    resultsSensMiss2(i,2) = high;
end

%%
EconomicModel.s = 2;
EconomicModel.t = 1;
EconomicModel.Assumption.Supp.Is = 'On';
EconomicModel.Assumption.Supp.Relax = 0;
EconomicModel.Assumption.Mtr.Is = 'Off';
EconomicModel.Assumption.Mtr.Relax = 0;
EconomicModel.Assumption.Mts.Is = 'Off';
EconomicModel.Assumption.Mts.Relax = 0;
EconomicModel.Assumption.Cmts.Is = 'Off';
EconomicModel.Assumption.Cmts.Relax = 0;
EconomicModel.Assumption.Miv.Is = 'On';
EconomicModel.Assumption.Miv.Relax = 0;
EconomicModel.Assumption.Msb.Is = 'Off';
EconomicModel.Assumption.Msb.Relax = 0;



for i = 1:h
     
    low  = LowerBoundMiss(Setup,EconomicModel,miss_relax(i));
    high = UpperBoundMiss(Setup,EconomicModel,miss_relax(i));
    resultsSensMiss3(i,1) = low;
    resultsSensMiss3(i,2) = high;
end