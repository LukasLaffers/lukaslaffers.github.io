function [LinearProgram] = translateAssumptionsIntoLP(EconomicModel,Setup,gradientYesNo)

suppMatrix  = [];
suppVec     = [];
suppGrad    = [];

mtrMatrix   = [];
mtrVec      = [];
mtrGrad     = [];

mtsMatrix   = [];
mtsVec      = [];
mtsGrad     = [];

cmtsMatrix  = [];
cmtsVec     = [];
cmtsGrad    = [];

mivMatrix   = [];
mivVec      = [];
mivGrad     = [];

msbMatrix   = [];
msbVec      = [];
msbGrad     = [];

eqMatrix    = [];
eqVector    = [];
eqGrad      = [];

ineqMatrix  = [];
inVector    = [];
inGrad      = [];

if gradientYesNo == 1
    helpGradVector   = 1:size(Setup.vecObs,1);
    helpGradVector3D = vec2array3D(helpGradVector,Setup); 
end
    %helpGradVector3D = zeros(Setup.sizeY,Setup.sizeZ,Setup.sizeI);

%% data

%compatibility with observed probabilities obs
sizeOfJointDistribution = (Setup.sizeY^Setup.sizeZ)*Setup.sizeY*Setup.sizeZ*Setup.sizeI;
dataMatrix = zeros(Setup.sizeY*Setup.sizeZ*Setup.sizeI,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);
for i = 1:Setup.sizeY*Setup.sizeZ*Setup.sizeI
    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    hlp(:,i) = ones(Setup.sizeY^Setup.sizeZ,1);
    dataMatrix(i,:) = reshape(hlp,1,[]);
end

%reshape the 3D array obs into vobs so that the ordering is compatible with
%allcomb function
hlp = reshape(Setup.obs(:,:,1)',1,[]);
for i = 1:Setup.sizeI-1
    %i
    %size(Setup.obs)
    hlp = [hlp;reshape(Setup.obs(:,:,i+1)',1,[])];
end
dataVec = reshape(hlp,Setup.sizeY*Setup.sizeZ*Setup.sizeI,1);

eqMatrix = [eqMatrix; dataMatrix];
eqVector = [eqVector; dataVec];

%%   E[Y(.)]
ey = zeros(2,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);
j = 0;
for iTreatment = [EconomicModel.s EconomicModel.t]
    j = j+1;
    hlp2 = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    atemat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    %take only t-th column of vecUnobs where the value of Y is 1
    for i = 1:Setup.sizeY
        hlp2 = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
        hlp2(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(i)),:) = ones(sum(Setup.vecUnobs(:,iTreatment)...
            ==Setup.Y(i)),Setup.sizeY*Setup.sizeZ*Setup.sizeI);
        atemat(i,:) = reshape(hlp2,1,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    end
    ey(j,:) = Setup.Y*atemat;
end

%ATE = E[y(t)] - E[y(s)]
ate = ey(2,:) - ey(1,:);
    
%% supp

if strcmp(EconomicModel.Assumption.Supp.Is,'On')
    suppMatrix = ones(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    for i = 1:Setup.sizeY
        for j = 1:Setup.sizeZ
            for k = 1:Setup.sizeI
                %set penalty equal to zero only to those pairs of obs-s and
                %unobser-s that are compatible. If I observe some fraction of
                %people with (Y,Z) equal to (0,1), it means that these people
                %will always have Y(1)=1, regardless of what Y(0) or Y(2) is.
                %find those rows in vecUnobs for which there is Y(i) in the
                %j-th column.
                where = find(Setup.vecUnobs(:,j) == Setup.Y(i));
                %pick column which corresponds to observed value (i,j,k)
                suppMatrix(where,(i-1)*Setup.sizeZ*Setup.sizeI + (j-1)*Setup.sizeI+k)...
                    = zeros(length(where),1);
            end
        end
    end
    suppMatrix = reshape(suppMatrix,1,[]);
    suppVec = EconomicModel.Assumption.Supp.Relax;

    if suppVec == 0
        eqMatrix = [eqMatrix; suppMatrix];
        eqVector = [eqVector; suppVec];
    else
        ineqMatrix  = [ineqMatrix; suppMatrix];
        inVector    = [inVector; suppVec];
    end
end

%% mtr
%for all t1>=t2: y(t1)>=y(t2)

if strcmp(EconomicModel.Assumption.Mtr.Is,'On')
    %check all the rows in vecUnobs, if you find violation of mtr, set
    %check to 1.
    mtrMatrix = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    check = zeros(Setup.sizeY^Setup.sizeZ,1);
    for i = 1:Setup.sizeY^Setup.sizeZ
        for j = 1:Setup.sizeZ-1
            if Setup.vecUnobs(i,j)>Setup.vecUnobs(i,j+1)
                check(i) =  1;
            end
        end
    end
    %put a penalty of one to the corresponding rows (those where mtr is violated)
    mtrMatrix(find(check),:) = ones(sum(check),Setup.sizeY*Setup.sizeZ*Setup.sizeI);
    mtrMatrix = reshape(mtrMatrix,1,[]);
    mtrVec = EconomicModel.Assumption.Mtr.Relax;

    if mtrVec == 0
        eqMatrix = [eqMatrix; mtrMatrix];
        eqVector = [eqVector; mtrVec];
    else
        ineqMatrix = [ineqMatrix; mtrMatrix];
        inVector = [inVector; mtrVec];
    end

end

%%
for iTreatment = Setup.Z
    % mts(unconditional)

    if strcmp(EconomicModel.Assumption.Mts.Is,'On')
        %inequality is stored in mts, so that mts*pi <= 0
        mtsMatrix = zeros(Setup.sizeZ-1,sizeOfJointDistribution);%mts
        %mat3 is an auxilliary matrix
        mat3 = zeros(Setup.sizeZ,sizeOfJointDistribution);

        for i = 1:Setup.sizeZ
            %the i-th row in mat3(i,:) stands for P(y(s)==1 && Z==Z(i))
            meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
            for k = 1:Setup.sizeY
                hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find(Setup.vecObs(:,2)==Setup.Z(i)))...
                    = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(Setup.vecObs(:,2)==Setup.Z(i)));
                meanmat(k,:) = reshape(hlp,1,[]);
            end
                mat3(i,:) = Setup.Y*meanmat;  
        end

        vecMts = zeros(Setup.sizeZ-1,1);
        for i = 1:Setup.sizeZ-1
            %P(y(s)==1 && Z==Z(i))/Pr(Z==Z(i)) <= P(y(s)==1 && Z==Z(i+1))/Pr(Z==Z(i+1))
            % which is equivalent to
            %P(y(s)==1 && Z==Z(i))*Pr(Z==Z(i+1)) <= P(y(s)==1 && Z==Z(i+1))*Pr(Z==Z(i)) 
            mtsMatrix(i,:) =mat3(i,:)*(sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i+1),:))))) ...
                - mat3(i+1,:)*(sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i),:)))));
            vecMts(i) = (sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i),:)))))*...
                (sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i+1),:)))));
            if gradientYesNo == 1
                for j = 1:size(Setup.vecObs,1)
                    mtsGrad(j,:,i) = zeros(1,sizeOfJointDistribution,1);
                    a = reshape(helpGradVector3D(:,Setup.Z==Setup.Z(i+1),:),1,[]);
                    if sum(a==j)>0
                        mtsGrad(j,:,i) = mtsGrad(j,:,i) + mat3(i,:);
                    end
                    b = reshape(helpGradVector3D(:,Setup.Z==Setup.Z(i),:),1,[]);
                    if sum(b==j)>0
                        mtsGrad(j,:,i) = mtsGrad(j,:,i) - mat3(i+1,:);
                    end
                end
                inGrad      = [inGrad; mtsGrad];
            end
        end
        mtsVec = EconomicModel.Assumption.Mts.Relax*vecMts;

        ineqMatrix  = [ineqMatrix; mtsMatrix];
        inVector    = [inVector; mtsVec];
        
    end

    %% cmts (conditional)

    if strcmp(EconomicModel.Assumption.Cmts.Is,'On')
        %inequality is stored in cmts, so that cmts*pi >=0
        cmtsMatrix = zeros(Setup.sizeI*(Setup.sizeZ-1),sizeOfJointDistribution);%cmts
        %mat3 is auxilliary matrix
        mat3 = zeros(Setup.sizeZ,sizeOfJointDistribution);

        vecCmts = zeros(Setup.sizeI*(Setup.sizeZ-1),1);
        for j = 1:Setup.sizeI    
            for i = 1:Setup.sizeZ
                meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
                for k = 1:Setup.sizeY
                    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                    hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find((Setup.vecObs(:,2)==Setup.Z(i)) ...
                        .* (Setup.vecObs(:,3)==Setup.I(j))))...
                        = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum((Setup.vecObs(:,2)==Setup.Z(i)) ...
                        .* (Setup.vecObs(:,3)==Setup.I(j))));
                    meanmat(k,:) = reshape(hlp,1,[]);
                end
                    mat3(i,:) = Setup.Y*meanmat;   
            end


            for i = 1:Setup.sizeZ-1
                %P(y(s)==1 && Z==Z(i) && I==I(j))/Pr(Z==Z(i) && I==I(j)) <= P(y(s)==1 && Z==Z(i+1) && I==I(j))/Pr(Z==Z(i+1) && I==I(j))
                % which is equivalent to
                %P(y(s)==1 && Z==Z(i) && I==I(j))*Pr(Z==Z(i+1) && I==I(j)) <= P(y(s)==1 && Z==Z(i+1) && I==I(j))*Pr(Z==Z(i) && I==I(j))
                cmtsMatrix((j-1)*(Setup.sizeZ-1)+i,:) = mat3(i,:)*(sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i+1),Setup.I==Setup.I(j))))))...
                    - mat3(i+1,:)*(sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i),Setup.I==Setup.I(j))))));
                vecCmts((j-1)*(Setup.sizeZ-1)+i) = (sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i),Setup.I==Setup.I(j))))))...
                    *(sum(sum(sum(Setup.obs(:,Setup.Z==Setup.Z(i+1),Setup.I==Setup.I(j))))));
                if gradientYesNo == 1
                    for jj = 1:size(Setup.vecObs,1)
                        cmtsGrad(jj,:) = zeros(1,sizeOfJointDistribution);
                        a = reshape(helpGradVector3D(:,Setup.Z==Setup.Z(i+1),Setup.I==Setup.I(j)),1,[]);
                        if sum(a==jj)>0
                            cmtsGrad(jj,:) = cmtsGrad(jj,:) + mat3(i,:);
                        end
                        b = reshape(helpGradVector3D(:,Setup.Z==Setup.Z(i),Setup.I==Setup.I(j)),1,[]);
                        if sum(b==jj)>0
                            cmtsGrad(jj,:) = cmtsGrad(jj,:) - mat3(i+1,:);
                        end
                    end
                    inGrad = [inGrad; cmtsGrad];
                end
            end
        end

        cmtsVec = EconomicModel.Assumption.Cmts.Relax*vecCmts;
        
        %cmtsMatrix = bsxfun(@times,cmtsMatrix,1./vecCmts);
        %cmtsVec    = EconomicModel.Assumption.Miv.Relax*ones(length(cmtsVec),1);

        ineqMatrix  = [ineqMatrix; cmtsMatrix];
        inVector    = [inVector; cmtsVec];
        
    end
    
    %% miv

    if strcmp(EconomicModel.Assumption.Miv.Is,'On')
        %inequality is stored in mts, so that miv*pi <= 0
        mivMatrix = zeros(Setup.sizeI-1,sizeOfJointDistribution);
        %mat3 is an auxilliary matrix
        mat3 = zeros(Setup.sizeI,sizeOfJointDistribution);

        for i = 1:Setup.sizeI
            %the i-th row in mat3(i,:) stands for P(y(s)==1 && Z==Z(i))
            meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
            for k = 1:Setup.sizeY
                hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find(Setup.vecObs(:,3)==Setup.I(i)))...
                    = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(Setup.vecObs(:,3)==Setup.I(i)));
                meanmat(k,:) = reshape(hlp,1,[]);
            end
                mat3(i,:) = Setup.Y*meanmat;  
        end

        vecMiv = zeros(Setup.sizeI-1,1);
        for i = 1:Setup.sizeI-1
            %P(y(s)==1 && Z==Z(i))/Pr(Z==Z(i)) <= P(y(s)==1 && Z==Z(i+1))/Pr(Z==Z(i+1))
            % which is equivalent to
            %P(y(s)==1 && Z==Z(i))*Pr(Z==Z(i+1)) <= P(y(s)==1 && Z==Z(i+1))*Pr(Z==Z(i)) 
            mivMatrix(i,:) =mat3(i,:)*(sum(sum(sum(Setup.obs(:,:,Setup.I==Setup.I(i+1)))))) ...
                - mat3(i+1,:)*(sum(sum(sum(Setup.obs(:,:,Setup.I==Setup.I(i))))));
            vecMiv(i) = (sum(sum(sum(Setup.obs(:,:,Setup.I==Setup.I(i+1))))))*...
                (sum(sum(sum(Setup.obs(:,:,Setup.I==Setup.I(i))))));
            if gradientYesNo == 1
                for jj = 1:size(Setup.vecObs,1)
                    mivGrad(jj,:) = zeros(1,sizeOfJointDistribution);
                    a = reshape(helpGradVector3D(:,:,Setup.I==Setup.I(i+1)),1,[]);
                    if sum(a==jj)>0
                        mivGrad(jj,:) = mivGrad(jj,:) + mat3(i,:);
                    end
                    b = reshape(helpGradVector3D(:,:,Setup.I==Setup.I(i)),1,[]);
                    if sum(b==jj)>0
                        mivGrad(jj,:) = mivGrad(jj,:) - mat3(i+1,:);
                    end
                end
                inGrad      = [inGrad; mivGrad];
            end
        end
        mivVec = EconomicModel.Assumption.Miv.Relax*vecMiv;
        
        
        %mivMatrix = bsxfun(@times,mivMatrix,1./vecMiv);
        %mivVec    = EconomicModel.Assumption.Miv.Relax*ones(length(mivVec),1);
        
        ineqMatrix  = [ineqMatrix; mivMatrix];
        inVector    = [inVector; mivVec];
        
    end
    
    %% monotone selection bias
    
    if strcmp(EconomicModel.Assumption.Msb.Is,'On')
        
        howManyInequalities = (Setup.sizeZ*(Setup.sizeZ-1)/2)*(Setup.sizeI*(Setup.sizeI-1)/2);
        msbMatrix = zeros(howManyInequalities,sizeOfJointDistribution);
        combZ = monotoneCombinations(Setup.Z);
        combI = monotoneCombinations(Setup.I);
        
        vecMsb = zeros(howManyInequalities,1);
        
        for ii = 1:size(combZ,1)
            for jj = 1:size(combI,1)
                matmsb1 = 0;
                meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
                for k = 1:Setup.sizeY
                    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                    hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find((Setup.vecObs(:,2)==combZ(ii,1)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,1))))...
                        = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(((Setup.vecObs(:,2)==combZ(ii,1)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,1)))));
                    meanmat(k,:) = reshape(hlp,1,[]);
                end
                matmsb1 = Setup.Y*meanmat/sum(Setup.obs(:,Setup.Z==combZ(ii,1),Setup.I==combI(jj,1)));  
                
                matmsb2 = 0;
                meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
                for k = 1:Setup.sizeY
                    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                    hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find((Setup.vecObs(:,2)==combZ(ii,2)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,1))))...
                        = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(((Setup.vecObs(:,2)==combZ(ii,2)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,1)))));
                    meanmat(k,:) = reshape(hlp,1,[]);
                end
                matmsb2 = Setup.Y*meanmat/sum(Setup.obs(:,Setup.Z==combZ(ii,2),Setup.I==combI(jj,1)));  

                matmsb3 = 0;
                meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
                for k = 1:Setup.sizeY
                    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                    hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find((Setup.vecObs(:,2)==combZ(ii,1)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,2))))...
                        = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(((Setup.vecObs(:,2)==combZ(ii,1)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,2)))));
                    meanmat(k,:) = reshape(hlp,1,[]);
                end
                matmsb3 = Setup.Y*meanmat/sum(Setup.obs(:,Setup.Z==combZ(ii,1),Setup.I==combI(jj,2)));  
                
                matmsb4 = 0;
                meanmat = zeros(Setup.sizeY,Setup.sizeY^Setup.sizeZ*Setup.sizeY*Setup.sizeZ*Setup.sizeI);            
                for k = 1:Setup.sizeY
                    hlp = zeros(Setup.sizeY^Setup.sizeZ,Setup.sizeY*Setup.sizeZ*Setup.sizeI);
                    hlp(find(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),find((Setup.vecObs(:,2)==combZ(ii,2)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,2))))...
                        = ones(sum(Setup.vecUnobs(:,iTreatment)==Setup.Y(k)),sum(((Setup.vecObs(:,2)==combZ(ii,2)) ...
                        .* (Setup.vecObs(:,3)==combI(jj,2)))));
                    meanmat(k,:) = reshape(hlp,1,[]);
                end
                matmsb4 = Setup.Y*meanmat/sum(Setup.obs(:,Setup.Z==combZ(ii,2),Setup.I==combI(jj,2)));                  
                
                msbMatrix((ii-1)*size(combI,1)+jj,:)= - matmsb1 + matmsb2 + matmsb3 - matmsb4;
                msbVec((ii-1)*size(combI,1)+jj,:) = 0;
                
                if gradientYesNo == 1
                    for jjj = 1:size(Setup.vecObs,1)
                        msbGrad(jjj,:) = zeros(1,sizeOfJointDistribution);

                        a = reshape(helpGradVector3D(:,Setup.Z==combZ(ii,1),Setup.I==combI(jj,1)),1,[]);
                        if sum(a==jjj)>0
                            msbGrad(jjj,:) = msbGrad(jjj,:) + matmsb1/(dataVec(jjj)^2);
                        end

                        b = reshape(helpGradVector3D(:,Setup.Z==combZ(ii,2),Setup.I==combI(jj,1)),1,[]);
                        if sum(b==jjj)>0
                            msbGrad(jjj,:) = msbGrad(jjj,:) - matmsb2/(dataVec(jjj)^2);
                        end

                        c = reshape(helpGradVector3D(:,Setup.Z==combZ(ii,1),Setup.I==combI(jj,2)),1,[]);
                        if sum(c==jjj)>0
                            msbGrad(jjj,:) = msbGrad(jjj,:) - matmsb3/(dataVec(jjj)^2);
                        end

                        d = reshape(helpGradVector3D(:,Setup.Z==combZ(ii,2),Setup.I==combI(jj,2)),1,[]);
                        if sum(d==jjj)>0
                            msbGrad(jjj,:) = msbGrad(jjj,:) + matmsb4/(dataVec(jjj)^2);
                        end
                    end
                    inGrad      = [inGrad; msbGrad];
                end
            end
        end
        
        
        
        msbVec = EconomicModel.Assumption.Msb.Relax*vecMsb;
        
        ineqMatrix  = [ineqMatrix; msbMatrix];
        inVector    = [inVector; msbVec];  
    end

end

%%

LinearProgram.Ate           = ate;
LinearProgram.EqMatrix      = eqMatrix;
LinearProgram.EqVector      = eqVector;
LinearProgram.IneqMatrix    = ineqMatrix;
LinearProgram.InVector      = inVector;
LinearProgram.InGradient    = inGrad;
LinearProgram.RangeLower    = zeros(1,sizeOfJointDistribution);
LinearProgram.RangeUpper    = ones(1,sizeOfJointDistribution);

LinearProgram.DataMatrix    = dataMatrix;
LinearProgram.DataVector    = dataVec;
LinearProgram.SuppMatrix    = suppMatrix;
LinearProgram.SuppVector    = suppVec;
LinearProgram.SuppGradient  = suppGrad;
LinearProgram.MtrMatrix     = mtrMatrix;
LinearProgram.MtrVector     = mtrVec;
LinearProgram.MtrGradient   = mtrGrad;
LinearProgram.MtsMatrix     = mtsMatrix;
LinearProgram.MtsVector     = mtsVec;
LinearProgram.MtsGradient   = mtsGrad;
LinearProgram.CmtsMatrix    = cmtsMatrix;
LinearProgram.CmtsVector    = cmtsVec;
LinearProgram.CmtsGradient  = cmtsGrad;
LinearProgram.MivMatrix     = mivMatrix;
LinearProgram.MivVector     = mivVec;
LinearProgram.MivGradient   = mivGrad;
LinearProgram.MsbMatrix     = msbMatrix;
LinearProgram.MsbVector     = msbVec;
LinearProgram.MsbGradient   = msbGrad;


%%




