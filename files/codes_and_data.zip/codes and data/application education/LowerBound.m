function [lb,sol] =  LowerBound(Setup,EconomicModel,vobs)


if nargin==2
    
    SetupHelp = Setup;
    LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
    problemHelp = convertToStandardForm(LinearProgramHelp);
    [sol,fval2,exitflag2,output2,lambda2] = linprog(problemHelp);

    lb = fval2;

else
    
    SetupHelp = Setup;
    SetupHelp.obs = vec2array3D(vobs,Setup);
    LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
    problemHelp = convertToStandardForm(LinearProgramHelp);
    [sol,fval2,exitflag2,output2,lambda2] = linprog(problemHelp);

    lb = fval2;
    
end

function [array3D] = vec2array3D(vector,Setup)
    hlp = reshape(vector,Setup.sizeI,Setup.sizeY*Setup.sizeZ);
    for i = 1:Setup.sizeI
        array3D(:,:,i) = reshape(hlp(i,:),Setup.sizeZ,Setup.sizeY)';
    end
end


end