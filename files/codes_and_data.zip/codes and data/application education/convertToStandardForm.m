function problem = convertToStandardForm(LinearProgram)

nIneq    = length(LinearProgram.InVector);
nEq      = length(LinearProgram.EqVector);

problem.Aeq = [LinearProgram.EqMatrix zeros(nEq,nIneq);...
    LinearProgram.IneqMatrix eye(nIneq)];

problem.Aineq = [];

problem.beq = [LinearProgram.EqVector ; LinearProgram.InVector];

problem.bineq = [];

problem.lb = [zeros(1, length(LinearProgram.Ate)) zeros(1, nIneq)];

problem.ub = [];

problem.f = -[LinearProgram.Ate zeros(1,nIneq)];

problem.solver = 'linprog';

problem.options = optimset('linprog');
problem.options = optimset(problem.options,'TolFun',1e-8,'Algorithm','simplex','Display','off','LargeScale','off');