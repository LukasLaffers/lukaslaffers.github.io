% reproduces Figure 5 in the paper

% run get_results_fig5.m

load results_education.mat

%%
F = figure;
maxfig(F,1);
colors = hsv(3);

%%
subplot(2,2,1)

p(1) = plot(supp_relax,resultsSensSUPP1(:,1)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(supp_relax,resultsSensSUPP1(:,2)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(supp_relax,resultsSensSUPP2(:,1)+0.005,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(supp_relax,resultsSensSUPP2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(supp_relax,resultsSensSUPP3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(supp_relax,resultsSensSUPP3(:,2)+0.005,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')
axis([0 0.1 -0.6 0.8])

a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to MOT}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from MOT ($\alpha_{MOT}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');
hleg = legend([p(1),p(2),p(3)],'MTR+cMTS+MIV','MTR','MIV');
%set(hleg,'Location','best')
set(hleg,'Position',[0.31 0.73 0.2 0.1])
set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(supp_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)


%%
subplot(2,2,2)

p(1) = plot(mtr_relax,resultsSensMTR1(:,1)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(mtr_relax,resultsSensMTR1(:,2)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(mtr_relax,resultsSensMTR2(:,1)-0.01,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(mtr_relax,resultsSensMTR2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(mtr_relax,resultsSensMTR3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(mtr_relax,resultsSensMTR3(:,2)+0.01,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

axis([0 0.1 -0.6 0.8])
a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to MTR}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from MTR ($\alpha_{MTR}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');
hleg = legend([p(1),p(2),p(3)],'MTR+cMTS+MIV','MTR+MIV','MTR');
set(hleg,'Location','east')
%set(hleg,'Position',[0.31 1.73 0.2 0.1])
set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(mtr_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)

%%
subplot(2,2,3)

p(1) = plot(cmts_relax,resultsSensCMTS1(:,1)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(cmts_relax,resultsSensCMTS1(:,2)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(cmts_relax,resultsSensCMTS2(:,1)-0.005,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(cmts_relax,resultsSensCMTS2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;
p(3) = plot(cmts_relax,resultsSensCMTS3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(cmts_relax,resultsSensCMTS3(:,2)+0.005,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')

axis([0 0.1 -0.6 0.8])
a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to  cMTS}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from cMTS ($\alpha_{cMTS}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');
hleg = legend([p(1),p(2),p(3)],'MTR+cMTS+MIV','cMTS+MIV','cMTS');
set(hleg,'Location','east')
%set(hleg,'Position',[0.31 1.73 0.2 0.1])
set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(cmts_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)

%%
subplot(2,2,4)

p(1) = plot(miv_relax,resultsSensMIV1(:,1),'LineWidth',2,'Color',colors(1,:),'LineStyle','-');
hold on;
plot(miv_relax,resultsSensMIV1(:,2)-0.005,'LineWidth',2,'Color',colors(1,:),'LineStyle','-')
hold on;

p(2) = plot(miv_relax,resultsSensMIV2(:,1)-0.01,'LineWidth',2,'Color',colors(2,:),'LineStyle','--');
hold on;
plot(miv_relax,resultsSensMIV2(:,2),'LineWidth',2,'Color',colors(2,:),'LineStyle','--')
hold on;

p(3) = plot(miv_relax,resultsSensMIV3(:,1),'LineWidth',2,'Color',colors(3,:),'LineStyle',':');
hold on;
plot(miv_relax,resultsSensMIV3(:,2)+0.01,'LineWidth',2,'Color',colors(3,:),'LineStyle',':')


axis([0 0.1 -0.6 0.8])
a = gca;
set(a,'FontSize',10);
set(a,'Title',text('String','\textsf{ {\bf Sensitivity to MIV}}','FontSize',20,'Interpreter','latex'));
set(get(a,'XLabel'),'String','\textsf{ {\bf Deviation from MIV ($\alpha_{MIV}$)}} ','FontSize',15,'Interpreter','latex');
set(get(a,'YLabel'),'String','\textsf{ {\bf Bounds}}','FontSize',15,'Interpreter','latex');
hleg = legend([p(1),p(2),p(3)],'MTR+cMTS+MIV','MTR+MIV','MIV');
set(hleg,'Location','east')
set(a,'XTick',0:0.01:0.1)
xticker = [num2str(100*sort(miv_relax','ascend')) repmat('%',[11,1])];
set(a,'XTickLabel',xticker)


%%
set(F,'Units','Inches');
pos = get(F,'Position');
set(F,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])

print -depsc2 figs\fig5.eps


