function [ub,sol] =  UpperBound(Setup,EconomicModel,vobs)


if nargin==2
    
    SetupHelp = Setup;
    %SetupHelp.obs = vec2array3D(vobs,Setup);
    LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
    problemHelp = convertToStandardForm(LinearProgramHelp);
    problemHelp.f = -problemHelp.f;
    [sol,fval2,exitflag2,output2,lambda2] = linprog(problemHelp);

    ub = -fval2;

else

    SetupHelp = Setup;
    SetupHelp.obs = vec2array3D(vobs,Setup);
    LinearProgramHelp   =  translateAssumptionsIntoLP(EconomicModel,SetupHelp,0);
    problemHelp = convertToStandardForm(LinearProgramHelp);
    problemHelp.f = -problemHelp.f;
    [sol,fval2,exitflag2,output2,lambda2] = linprog(problemHelp);

    ub = -fval2;
    
end


function [array3D] = vec2array3D(vector,Setup)
    hlp = reshape(vector,Setup.sizeI,Setup.sizeY*Setup.sizeZ);
    for i = 1:Setup.sizeI
        array3D(:,:,i) = reshape(hlp(i,:),Setup.sizeZ,Setup.sizeY)';
    end
end


end