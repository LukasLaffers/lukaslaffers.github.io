%
% run get_results_table2.m in order to get results

load results_education

%% 
%write results in tables2.tex

my_folder = pwd;
file_1 = fopen([my_folder,'/tables/tables2','.tex'],'w');

fprintf(file_1,'{\\footnotesize \n ');
fprintf(file_1,'    \\renewcommand\\multirowsetup{\\centering}\n');
fprintf(file_1,'\\begin{center}\n');
fprintf(file_1,'\\begin{tabular}{cccccccccc}\n');
fprintf(file_1,'    \\noalign{\\hrule height 2pt}\n');
fprintf(file_1,'  \\multicolumn{10}{c}{} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{10}{c}{{\\bf Bounds on Effect of an Increase in the Mother''s College Education }} \\vspace{1mm} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{10}{c}{{\\bf on the Probability that the Child has a College Degree}} \\vspace{1mm} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{10}{c}{{\\bf Sensitivity analysis}} \\vspace{3mm} \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{10}{c}{ MTR+cMTS+MIV} \\vspace{2mm}   \\\\  \n'); 
fprintf(file_1,'  \\multicolumn{10}{c}{ [Lower bound, Upper bound] = [%5.1f\\%%, %5.1f\\%%] }   \\\\  \n',[100*lbBench, 100*ubBench]); 
fprintf(file_1,'  \\multicolumn{10}{c}{ Confidence set = (%5.1f\\%%, %5.1f\\%%) \\vspace{1mm}}   \\\\  \n',[100*ImBiasCRlowBench, 100*ImBiasCRlowBench]); 
fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n '); 
fprintf(file_1,'  \\multicolumn{10}{c}{} \\vspace{-2mm} \\\\  \n'); 

fprintf(file_1,' & \\multicolumn{1}{c}{Lower bound}  & \\multicolumn{4}{c}{Upper bound} & \\multicolumn{4}{c}{[Lower Bound, Upper Bound]}   \\vspace{2mm} \\\\  \n'); 

fprintf(file_1,' & \\multicolumn{1}{c}{$\\alpha_{MTR}$}  & \\multicolumn{1}{c}{$\\alpha_{MOT}$} & \\multicolumn{1}{c}{$\\alpha_{cMTS}$} & \\multicolumn{1}{c}{$\\alpha_{MIV}$} & \\multicolumn{1}{c}{$\\alpha_{MISS}$} & \\multicolumn{2}{c}{all simultaneously} & \\multicolumn{2}{c}{all simultaneously} \\vspace{2mm} \\\\  \n'); 




fprintf(file_1,' Optimistic & \\multicolumn{1}{c}{$0.01$}  & \\multicolumn{1}{c}{$0.001$} & \\multicolumn{1}{c}{$0.01$} & \\multicolumn{1}{c}{$0.01$} & \\multicolumn{1}{c}{$0.01$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0.01$}  \\\\  \n');

 
fprintf(file_1,'      & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]}  \\\\  \n',...
    [100*resultsTable2(1,:)]); 
fprintf(file_1,'      & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} \\vspace{3mm} \\\\  \n',...
    [100*resultsTable2(2,:)]);

fprintf(file_1,' Pessimistic & \\multicolumn{1}{c}{$0.05$}  & \\multicolumn{1}{c}{$0.01$} & \\multicolumn{1}{c}{$0.05$} & \\multicolumn{1}{c}{$0.05$} & \\multicolumn{1}{c}{$0.1$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0$} & \\multicolumn{2}{c}{with $\\alpha_{MISS}=0.10$}  \\\\  \n');


 
fprintf(file_1,'      & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{1}{c}{%5.1f\\%%} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]} & \\multicolumn{2}{c}{[%5.1f\\%%, %5.1f\\%%]}  \\\\  \n',...
    [100*resultsTable2(3,:)]); 
fprintf(file_1,'      & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{1}{c}{(%5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)} & \\multicolumn{2}{c}{(%5.1f\\%%, %5.1f\\%%)}  \\\\  \n',...
    [100*resultsTable2(4,:)]);


fprintf(file_1,'   \\noalign{\\hrule height 2pt}  \n'); 
fprintf(file_1,'  Sample size & \\multicolumn{8}{c}{} & \\multicolumn{1}{c}{16912}  \\\\   \n'); 
fprintf(file_1,'  \\multicolumn{10}{l}{90\\%% confidence intervals in parentheses using the method of \\cite{im} } \\\\  \n'); 
fprintf(file_1,'    \\noalign{\\hrule height 2pt}\n');
fprintf(file_1,'  \\end{tabular}\n');
fprintf(file_1,'\\end{center}\n');
fprintf(file_1,'  } '); 

fclose(file_1);  

fid  = fopen([my_folder,'/tables/tables2','.tex'],'r');
f=fread(fid,'*char')';
fclose(fid);
f = regexprep(f,'-1.0\\%','-1\\%');
f = regexprep(f,'-5.0\\%','-5\\%');
f = regexprep(f,'0.0\\%','0\\%');
%f = regexprep(f,'-0\\%','0\\%');
fid  = fopen([my_folder,'/tables/tables2','.tex'],'w');
fprintf(fid,'%s',f);
fclose(fid);