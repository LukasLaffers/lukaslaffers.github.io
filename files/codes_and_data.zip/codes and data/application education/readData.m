function [Setup] = readData(scenario)

        
[num,~,~] = xlsread('data/data_pub.xlsx',['Scenario',num2str(scenario)]);

Setup.Y = [0 1];
Setup.sizeY = length(Setup.Y);
Setup.Z = [1 2];
Setup.sizeZ = length(Setup.Z);

if scenario == 1 || scenario == 3 
    Setup.I = [1 2 3 4];
else
    Setup.I = [1 2 3 4 5];
end


Setup.sizeI = length(Setup.I);

%Setup.vecUnobs = allcomb(Setup.Y,Y,Y,Y); %Setup.sizeZ times
%vector of unSetup.observables
Setup.vecUnobs = allcomb(Setup.Y,Setup.Y);

%vector of Setup.observables
Setup.vecObs = allcomb(Setup.Y,Setup.Z,Setup.I);



Setup.obs = zeros(Setup.sizeY,Setup.sizeZ,Setup.sizeI);
for i = 1:Setup.sizeY
     for j = 1:Setup.sizeZ
         for k = 1:Setup.sizeI
             %prob(Y,Z,I)
             Setup.obs(i,j,k) = num(2*(i-1)+j,2+k);             
         end
     end
end

Setup.nObs = sum(Setup.obs(:));
Setup.obs = Setup.obs/Setup.nObs;


