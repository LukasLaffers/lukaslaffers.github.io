%read data (takes a few seconds)
[num,txt,raw] = xlsread('data.xls');

%%
labels = txt(1,:);
numvec = [1:4 7:8 11:18];
textvec =  [5:6 9:10 19:20];
n = size(num,1);

for i = 1:size(numvec,2)
    v = genvarname(labels{1,numvec(i)});
    eval([v '= num(:,numvec(i));']);
end

for i = 1:size(textvec,2)
    v = genvarname(labels{1,textvec(i)});
    eval([v '= raw(2:end,textvec(i));']);
end

%%
global Y Z I sizeY sizeZ sizeI vecUnobs vecObs

II = {'Less than high school (<12 years)','High school (12 years)','Some college (13-15 years)','Bachelor degree (16 years)','Master degree or more (>=17 years)'};
III = {'High school or less (<=12 years)','Some college (13-15 years)','Bachelor degree (16 years)','Master degree or more (>=17 years)'};

edlevelm2 = zeros(n,1);
edlevelf2 = zeros(n,1);
edlevelf_miv2 = zeros(n,1);
edlevelm_miv2 = zeros(n,1);
edlevelheadmo2 = zeros(n,1);
edlevelheadfa2 = zeros(n,1);

for i = 1:size(II,2)
    edlevelm2(strcmp(edlevelm,II(1,i))) = i;
    edlevelf2(strcmp(edlevelf,II(1,i))) = i;
    edlevelheadmo2(strcmp(edlevelheadmo,II(1,i))) = i;
    edlevelheadfa2(strcmp(edlevelheadfa,II(1,i))) = i;
end

for i = 1:size(III,2)
    edlevelf_miv2(strcmp(edlevelf_miv,III(1,i))) = i;
    edlevelm_miv2(strcmp(edlevelm_miv,III(1,i))) = i;
end


