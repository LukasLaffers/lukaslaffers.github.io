
%% MTR+cMTS+MIV
%Manski's bounds on E[Y(2)]-E[Y(1)] using monotone treatment response, monotone
%treatment selection and monotone instrumental variable

lb = zeros(1,sizeI);
ub = ones(1,sizeI);

for i = 1:sizeI
    obs2 = obs(:,:,i)/sum(sum(obs(:,:,i)));
    py2 = sum(sum(obs2,3),2);
    pyz2 = sum(obs2,3);
    pz2 = sum(sum(obs2,3),1);
    %lb(i)=  sum(sum(obs2(2,Z<t,:))) + sum(sum(obs2(2,t,:))) + (sum(sum(sum(obs2(:,Z>t,:)))))*(sum(sum(obs2(2,Z==t,:)))/(sum(sum(sum(obs2(:,Z==t,:))))));
    %ub(i)= (sum(sum(sum(obs2(:,Z<t,:)))))*(sum(sum(obs2(2,Z==t,:)))/(sum(sum(sum(obs2(:,Z==t,:)))))) +sum(sum(obs2(2,t,:))) + sum(sum(obs2(2,Z>t,:)));
    lb(i) = Y*sum(pyz2(:,Z<t),2) + Y*pyz2(:,Z==t) + sum(pz2(Z>t))*(Y*pyz2(:,Z==t)/pz2(Z==t));
    ub(i) = sum(pz2(Z<t))*(Y*pyz2(:,Z==t)/pz2(Z==t)) + Y*pyz2(:,Z==t) + Y*sum(pyz2(:,Z>t),2);
end

lbb = zeros(1,sizeI);
ubb = ones(1,sizeI);

for i = 1: sizeI
    lbb(i) = sum(sum(obs(:,:,i)))*max(lb(1:i));
    ubb(i) = sum(sum(obs(:,:,i)))*min(ub(i:end));
end

lb_mtr_mts_mivt = sum(lbb);
ub_mtr_mts_mivt = sum(ubb);



lb = zeros(1,sizeI);
ub = ones(1,sizeI);

for i = 1:sizeI
    obs2 = obs(:,:,i)/sum(sum(obs(:,:,i)));
    py2 = sum(sum(obs2,3),2);
    pyz2 = sum(obs2,3);
    pz2 = sum(sum(obs2,3),1);
    lb(i) = Y*sum(pyz2(:,Z<s),2) + Y*pyz2(:,Z==s) + sum(pz2(Z>s))*(Y*pyz2(:,Z==s)/pz2(Z==s));
    ub(i) = sum(pz2(Z<s))*(Y*pyz2(:,Z==s)/pz2(Z==s)) + Y*pyz2(:,Z==s) + Y*sum(pyz2(:,Z>s),2);
end

lbb = zeros(1,sizeI);
ubb = ones(1,sizeI);

for i = 1: sizeI
    lbb(i) = sum(sum(obs(:,:,i)))*max(lb(1:i));
    ubb(i) = sum(sum(obs(:,:,i)))*min(ub(i:end));
end

lb_mtr_mts_mivs = sum(lbb);
ub_mtr_mts_mivs = sum(ubb);





lb_mtr_mts_miv = lb_mtr_mts_mivt - ub_mtr_mts_mivs;
ub_mtr_mts_miv = ub_mtr_mts_mivt - lb_mtr_mts_mivs;




    