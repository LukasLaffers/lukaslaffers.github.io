my_folder = 'c:\Laffo\school\nhh\research\partial identification\manski\note\';
file_1 = fopen([my_folder,'matrices','.tex'],'w');
%fprintf(file_1,'\\begin{center}\n');

% Y = [0 1];
% sizeY = length(Y);
% Z = [1 2];
% sizeZ = length(Z);
% I = [1 2];
% sizeI = length(I);
% 
% %vecUnobs = allcomb(Y,Y,Y,Y); %sizeZ times
% %vector of unobservables
% vecUnobs = allcomb(Y,Y);
% 
% %vector of observables
% vecObs = allcomb(Y,Z,I);
% 
% which = edlevelheadmo2>0;
% nn = sum(which);
% 
% obs = zeros(sizeY,sizeZ,sizeI);
% for i = 1:sizeY
%      for j = 1:sizeZ
%          for k = 1:sizeI
%              %prob(Y,Z,I)
%              obs(i,j,k) = sum((college_child(which) == Y(i)).*(college_m(which) == Z(j)).*(college_f(which) == I(k)))/nn;
%              %obs(i,j,k) = sum((college_child(which) == Y(i)).*(college_m(which) == Z(j)))/nn;
%          end
%      end
% end

mtrSupp = (1-MTR).*(1-SUPP);
sizeMtrSupp = sum(mtrSupp);


sol2_2 = reshape(sol2,1,[]);
sol2_2 = sol2_2(mtrSupp==1)


si = size(INEQUALITIES,1);
INEQUALITIES(INEQUALITIES==0) = 0;
INEQUALITIES_2 = INEQUALITIES([1 5 2:4 6:8],:)
se = size(EQUALITIES,1);
ATE = ATE2 - ATE1;


INEQUALITIES_2 = INEQUALITIES_2(:,mtrSupp==1);
EQUALITIES_2 = EQUALITIES(1:16,mtrSupp==1);
ATE_2 = ATE(mtrSupp==1);

%%

fprintf(file_1,'\\footnotesize \n');
fprintf(file_1,'$\\max_{\\pi} \\overbrace{\n');
fprintf(file_1,'\\left[ \n');
fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n');
fprintf(file_1,'');
for j = 1:23
    fprintf(file_1,'%g & ',ATE_2(1,j));
end
fprintf(file_1,'%g \\\\',ATE_2(1,j+1));
fprintf(file_1,'\\end{array}\n');
%fprintf(file_1,' \n');
fprintf(file_1,'\\right] \\times \\pi }^\\text{\\footnotesize Average Treatment Effect}$ \\\\  \n');

fprintf(file_1,'\\bigskip \n');
fprintf(file_1,'subject to \\\\ \n');
fprintf(file_1,'\\bigskip \n');

fprintf(file_1,'$\\left. \n');
fprintf(file_1,'\\begin{array}{tl}\n');
fprintf(file_1,'');
%fprintf(file_1,'$\\left{ \n');
fprintf(file_1,'DATA & \\left\\{ \\left[ ');
fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n');
for i = 1:16
    for j = 1:23
        fprintf(file_1,'%g & ',EQUALITIES_2(i,j));
    end
    fprintf(file_1,'%g \\\\',EQUALITIES_2(i,j+1));
end
fprintf(file_1,'\\end{array} \\right] \\right. \\\\ \n');

% fprintf(file_1,'noMOT & \\left\\{ \\phantom{i} \\left[ ');
% fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n');
% for j = 1:23
%     fprintf(file_1,'%g & ',EQUALITIES_2(10,j));
% end
% fprintf(file_1,'%g \\\\',EQUALITIES_2(10,j+1));
% fprintf(file_1,'\\end{array} \\right] \\right. \\\\ \n');
% 
% 
% fprintf(file_1,'MTR & \\left\\{ \\phantom{i} \\left[ ');
% fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n ');
% for j = 1:23
%     fprintf(file_1,'%g & ',EQUALITIES_2(9,j));
% end
% fprintf(file_1,'%g \\\\',EQUALITIES_2(9,j+1));
% fprintf(file_1,'\\end{array} \\right] \\right. \n');



fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right. \\times \\pi =  \n');

fprintf(file_1,'\\left. \n');
fprintf(file_1,'\\begin{array}{cc}\n');
fprintf(file_1,'');
fprintf(file_1,'\\left. \\left[ \n');
fprintf(file_1,'\\begin{array}{c}\n');
for i = 1:15
    fprintf(file_1,'%.3g \\\\',round(1000*EQvec(1,i))/1000);
end
fprintf(file_1,'%.3g',round(1000*EQvec(1,16))/1000);
fprintf(file_1,'\\end{array} \\right]  \\right\\} & \n');
fprintf(file_1,' \\begin{array}{t} \n');
fprintf(file_1,'{Observed} \\\\ probabilities  \n');
fprintf(file_1,' \\end{array} \\\\');
fprintf(file_1,' \n');

% fprintf(file_1,'\\left[ \n');
% fprintf(file_1,'\\begin{array}{c}\n');
% fprintf(file_1,'\\phantom{iiii} %.2g \\phantom{i} \\\\',round(1000*EQvec(1,9))/1000);
% fprintf(file_1,'\\end{array}  \\right]\\phantom{ii}&  \\\\ \n');
% 
% fprintf(file_1,'\\left[ \n');
% fprintf(file_1,'\\begin{array}{c}\n');
% fprintf(file_1,'\\phantom{iiii} %.2g \\phantom{i} ',round(1000*EQvec(1,10))/1000);
% fprintf(file_1,'\\end{array}  \\right]\\phantom{ii}& \n');

fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right.$\n');

fprintf(file_1,'\n');
fprintf(file_1,'\\bigskip \n');


fprintf(file_1,'$\\left. \n');
fprintf(file_1,'\\begin{array}{tl}\n');
fprintf(file_1,'');

fprintf(file_1,'MTS & \\left\\{ \\left[');
fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n');
for i = 1:2
    for j = 1:23
        if round(1000*INEQUALITIES_2(i,j))/1000 ~= 0
            if round(1000*INEQUALITIES_2(i,j))/1000 > 0
                sp = num2str(round(1000*INEQUALITIES_2(i,j))/1000);
                fprintf(file_1,'%s & ',sp(2:4));
            else
                sp = num2str(round(1000*INEQUALITIES_2(i,j))/1000);
                fprintf(file_1,'%s & ',[sp(1) sp(3:5)]);
            end
        else
            fprintf(file_1,'%g & ',round(1000*INEQUALITIES_2(i,j))/1000);
        end
        %fprintf(file_1,'%-.2g& ',round(1000*INEQUALITIES(i,j))/1000);
    end
        if round(1000*INEQUALITIES_2(i,j+1))/1000 ~= 0
            if round(1000*INEQUALITIES_2(i,j+1))/1000 > 0
                sp = num2str(round(1000*INEQUALITIES_2(i,j+1))/1000);
                fprintf(file_1,'%s \\\\',sp(2:4));
            else
                sp = num2str(round(1000*INEQUALITIES_2(i,j+1))/1000);
                fprintf(file_1,'%s \\\\',[sp(1) sp(3:5)]);
            end
        else
            fprintf(file_1,'%g \\\\',round(1000*INEQUALITIES_2(i,j+1))/1000);
        end
end
fprintf(file_1,'\\end{array} \\right] \\right. \\\\ \n');

fprintf(file_1,'MIV & \\left\\{ \\left[');
fprintf(file_1,'\\begin{array}{cccccccccccccccccccccccc}\n');
for i = 3:8
    for j = 1:23
        if round(1000*INEQUALITIES_2(i,j))/1000 ~= 0
            if round(1000*INEQUALITIES_2(i,j))/1000 > 0
                sp = num2str(round(1000*INEQUALITIES_2(i,j))/1000);
                fprintf(file_1,'%s & ',sp(2:4));
            else
                sp = num2str(round(1000*INEQUALITIES_2(i,j))/1000);
                fprintf(file_1,'%s & ',[sp(1) sp(3:5)]);
            end
        else
            fprintf(file_1,'%g & ',round(1000*INEQUALITIES_2(i,j))/1000);
        end
        %fprintf(file_1,'%-.2g& ',round(1000*INEQUALITIES(i,j))/1000);
    end
        if round(1000*INEQUALITIES_2(i,j+1))/1000 ~= 0
            if round(1000*INEQUALITIES_2(i,j+1))/1000 > 0
                sp = num2str(round(1000*INEQUALITIES_2(i,j+1))/1000);
                fprintf(file_1,'%s \\\\',sp(2:4));
            else
                sp = num2str(round(1000*INEQUALITIES_2(i,j+1))/1000);
                fprintf(file_1,'%s \\\\',[sp(1) sp(3:5)]);
            end
        else
            fprintf(file_1,'%g \\\\',round(1000*INEQUALITIES_2(i,j+1))/1000);
        end
end
fprintf(file_1,'\\end{array} \\right] \\right. \n');




fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right. \\times \\pi \\leq  \n');
fprintf(file_1,'\\left. \n');


fprintf(file_1,'\\begin{array}{c}\n');
fprintf(file_1,'');
fprintf(file_1,'\\left[ \n');
fprintf(file_1,'\\begin{array}{c}\n');
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,1))/1000);
fprintf(file_1,'%.2g ',round(1000*INEQvec(1,2))/1000);
fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right] \\\\ \n');

fprintf(file_1,'\\left[ \n');
fprintf(file_1,'\\begin{array}{c}\n');
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,3))/1000);
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,4))/1000);
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,5))/1000);
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,6))/1000);
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,7))/1000);
fprintf(file_1,'%.2g \\\\',round(1000*INEQvec(1,8))/1000);
fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right]\n');

fprintf(file_1,'\\end{array}\n');
fprintf(file_1,'\\right.$  \n');

fprintf(file_1,'\n');
fprintf(file_1,'\\bigskip \n');
fprintf(file_1,'$\\pi \\geq \\left[ \\begin{array}{c} 0 \\\\ \\vdots \\\\ 0 \\end{array} \\right]$, \n');
%fprintf(file_1,'\n');
%fprintf(file_1,'\n');
fprintf(file_1,'\n');
fprintf(file_1,'\\bigskip \n');


fprintf(file_1,'$\\pi^* = \\left[ \\begin{array}{c}  $ \n');
for i = 1:24
    fprintf(file_1,'%.2g ', round(1000*sol2_2(i))/1000);
end
fprintf(file_1,'$ \\end{array} \\right]'' .$ \n');

%fprintf(file_1,'\\end{center}\n');
fclose(file_1);