clear all
clc

display('Bounds obtained by Linear Programming');

%% Read data
fprintf(['Loading Data... ']);
read_data 
fprintf(['Data loaded.\n']);
%% Prepare
%bounds on the probability that child with a college educated mother
%will also get college education, monotone instrument is education level
%of a father

Y = [0 1];
sizeY = length(Y);
Z = [0 1];
sizeZ = length(Z);
I = 1:size(III,2);
sizeI = length(I);

%vecUnobs = allcomb(Y,Y,Y,Y); %sizeZ times
%vector of unobservables
vecUnobs = allcomb(Y,Y);

%vector of observables
vecObs = allcomb(Y,Z,I);

%we restrict the data to mother's for which we have data on their parent's
%schooling (so we can compute bound with different instrument(grandparent's schooling level)  on the same data)
%This was also done in deHaan (2010).
which = edlevelheadmo2>0;
nn = sum(which);

obs = zeros(sizeY,sizeZ,sizeI);
for i = 1:sizeY
     for j = 1:sizeZ
         for k = 1:sizeI
             %prob(Y,Z,I)
             obs(i,j,k) = sum((college_child(which) == Y(i)).*(college_m(which) == Z(j)+1).*(edlevelf_miv2(which) == I(k)))/nn;
         end
     end
end

s=0; t=1;


%% Calculate 

%no assumptions
mtr=0; mts=0; miv=0; supp=1;
[rootlow1,roothigh1,exitflag11,exitflag12] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mts
mtr=0; mts=1; miv=0; supp=1;
[rootlow2,roothigh2,exitflag21,exitflag22] = ateffect(s,t,obs,mtr,mts,miv,supp);

%cmts
mtr=0; mts=2; miv=0; supp=1;
[rootlow3,roothigh3,exitflag31,exitflag32] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mtr
mtr=1; mts=0; miv=0; supp=1;
[rootlow4,roothigh4,exitflag41,exitflag42] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mtr+mts
mtr=1; mts=1; miv=0; supp=1;
[rootlow5,roothigh5,exitflag51,exitflag52] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mtr+cmts
mtr=1; mts=2; miv=0; supp=1;
[rootlow6,roothigh6,exitflag61,exitflag62] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mtr+mts+miv
mtr=1; mts=1; miv=1; supp=1;
[rootlow7,roothigh7,exitflag71,exitflag72] = ateffect(s,t,obs,mtr,mts,miv,supp);

%mtr+cmts+miv
mtr=1; mts=2; miv=1; supp=1;
[rootlow8,roothigh8,exitflag81,exitflag82] = ateffect(s,t,obs,mtr,mts,miv,supp);

miv_on_mtr_mts

%% Display

if exitflag11==1  && exitflag12==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (no Assum): ']);
    fprintf('\t (%f, %f) \n', rootlow1, roothigh1)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (no Assum): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag21==1  && exitflag22==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTS): ']);
    fprintf('\t \t \t (%f, %f) \n', rootlow2, roothigh2)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTS): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag31==1  && exitflag32==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (cMTS): ']);
    fprintf('\t \t (%f, %f) \n', rootlow3, roothigh3)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (cMTS): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag41==1  && exitflag42==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR): ']);
    fprintf('\t \t \t (%f, %f) \n', rootlow4, roothigh4)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag51==1  && exitflag52==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-MTS): ']);
    fprintf('\t \t (%f, %f) \n', rootlow5, roothigh5)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-MTS): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag61==1  && exitflag62==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-cMTS): ']);
    fprintf('\t (%f, %f) \n', rootlow6, roothigh6)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-cMTS): ']);
    fprintf('The identified set is empty. \n');
end


if exitflag71==1  && exitflag72==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-MTS-MIV): ']);
    fprintf('\t (%f, %f) \n', rootlow7, roothigh7)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-MTS-MIV): ']);
    fprintf('The identified set is empty. \n');
end

if exitflag81==1  && exitflag82==1
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-cMTS-MIV): ']);
    fprintf(' (%f, %f) \n', rootlow8, roothigh8)
else
    fprintf(['Bounds on E[Y(2)]-E[Y(1)] using Linear Programming  (MTR-cMTS-MIV): ']);
    fprintf('The identified set is empty. \n');
end

fprintf(['Bounds on E[Y(2)]-E[Y(1)] using MIV on MTR-MTS (MTR-MTS-MIV?): ']);
if lb_mtr_mts_miv < ub_mtr_mts_miv
     fprintf('\t \t (%f, %f) \n', lb_mtr_mts_miv, ub_mtr_mts_miv);
else
     fprintf('The lower bound is greater than the upper bound. \n');
end


display('Done!');

%% Plot

plotpaper %reproduces Figure 1

