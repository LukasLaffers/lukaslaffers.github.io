function [lb,ub,exitflag1,exitflag2,sol1,sol2] = ateffect(s,t,obs,mtr,mts,miv,supp)

%this function calculate bounds on E[y(t)] - E[y(s)] using a linear program
s=0; t=1; mtr=0; mts=2; miv=1; supp=1;

global Y Z I sizeY sizeZ sizeI vecUnobs vecObs

%bounds using LP (using Laffers(2012))

%% Compatibility of the observed and unobserved component
%define matrix of penalty, set all the values to zero
SUPP = ones(sizeY^sizeZ,sizeY*sizeZ*sizeI);
for i = 1:sizeY
    for j = 1:sizeZ
        for k = 1:sizeI
            %set penalty equal to zero only to those pairs of obs-s and
            %unobser-s that are compatible. If I observe some fraction of
            %people with (Y,Z) equal to (0,1), it means that these people
            %will always have Y(1)=1, regardless of what Y(0) or Y(2) is.
            %find those rows in vecUnobs for which there is Y(i) in the
            %j-th column.
            where = find(vecUnobs(:,j) == Y(i));
            %pick column which corresponds to observed value (i,j,k)
            SUPP(where,(i-1)*sizeZ*sizeI + (j-1)*sizeI+k) = zeros(length(where),1);
        end
    end
end
SUPP = reshape(SUPP,1,[]);
SUPPvec = 1-supp;

%% MTR
%MTR assumption, monotone treatment response
%for all t1>=t2: y(t1)>=y(t2)
if mtr > 0
    %check all the rows in vecUnobs, if you find violation of MTR, set
    %check to 1.
    MTR = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
    check = zeros(sizeY^sizeZ,1);
    for i = 1:sizeY^sizeZ
        for j = 1:sizeZ-1
            if vecUnobs(i,j)>vecUnobs(i,j+1)
            check(i) =  1;
            end
        end
    end
    %put a penalty of one to the corresponding rows (those where MTR is violated)
    MTR(find(check),:) = ones(sum(check),sizeY*sizeZ*sizeI);
    MTRvec = 1-mtr;
    MTR = reshape(MTR,1,[]);
else
    MTR = [];
    MTRvec = [];
end

%% MTS for s
%MTS assumptions
%monotone treatment response
%for all t1>=t2: y(t1)>=y(t2)
%monotone treatment selection
%for all t,z1>=z2: E(y(s)|z=z1) >=E(y(s)|z=z2)
switch mts
    case 1
    %MTS (unconditional)
    %inequality is stored in MTS, so that MTS*pi >=0
    MTS = zeros(sizeZ-1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT3 is auxilliary matrix
    MAT3 = zeros(sizeZ,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
    
    for i = 1:sizeZ
        %the i-th row in MAT3(i,:) stands for P(y(s)==1 && Z==Z(i))
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);            
        for k = 1:sizeY
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==s))==Y(k)),find(vecObs(:,2)==Z(i))) = ones(sum(vecUnobs(:,find(Z==s))==Y(k)),sum(vecObs(:,2)==Z(i)));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT3(i,:) = Y*MEANMAT;  
    end


    for i = 1:sizeZ-1
        %P(y(s)==1 && Z==Z(i+1))/Pr(Z==Z(i+1)) >= P(y(s)==1 && Z==Z(i))/Pr(Z==Z(i))
        % which is equivalent to
        %P(y(s)==1 && Z==Z(i+1))*Pr(Z==Z(i)) >= P(y(s)==1 && Z==Z(i))*Pr(Z==Z(i+1))
        MTS(i,:) = MAT3(i+1,:)*(sum(sum(sum(obs(:,Z==Z(i),:)))))...
            - MAT3(i,:)*(sum(sum(sum(obs(:,Z==Z(i+1),:)))));
    end
    MTSvec = zeros(1,sizeZ-1);

    case 2
    %MTS (conditional)
    %inequality is stored in MTS, so that MTS*pi >=0
    MTS = zeros(sizeI*(sizeZ-1),(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT3 is auxilliary matrix
    MAT3 = zeros(sizeZ,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);

for j = 1:sizeI    
    for i = 1:sizeZ
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);            
        for k = 1:sizeY
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==s))==Y(k)),find((vecObs(:,2)==Z(i)) .* (vecObs(:,3)==I(j)))) = ones(sum(vecUnobs(:,find(Z==s))==Y(k)),sum((vecObs(:,2)==Z(i)) .* (vecObs(:,3)==I(j))));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT3(i,:) = Y*MEANMAT;   
    end


    for i = 1:sizeZ-1
        %P(y(s)==1 && Z==Z(i+1) && I==I(j))/Pr(Z==Z(i+1) && I==I(j)) >= P(y(s)==1 && Z==Z(i) && I==I(j))/Pr(Z==Z(i) && I==I(j))
        % which is equivalent to
        %P(y(s)==1 && Z==Z(i+1) && I==I(j))*Pr(Z==Z(i) && I==I(j)) >= P(y(s)==1 && Z==Z(i) && I==I(j))*Pr(Z==Z(i+1) && I==I(j))
        MTS((j-1)*(sizeZ-1)+i,:) = MAT3(i+1,:)*(sum(sum(sum(obs(:,Z==Z(i),I==I(j))))))...
            - MAT3(i,:)*(sum(sum(sum(obs(:,Z==Z(i+1),I==I(j))))));
    end
end
    MTSvec = zeros(1,sizeI*(sizeZ-1));
    
    otherwise
    MTS = [];
    MTSvec = [];
end

%% MIV for s
switch miv
    case 1
    %MIV (unconditional)
    %monotone IV
    %inequality is stored in MIV, so that MIV*pi >=0
    MIV = zeros(sizeI-1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT5 is auxilliary matrix
    MAT5 = zeros(sizeI,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
    
    for i = 1:sizeI
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI); 
        for k = 1:sizeY
            %the i-th row in MAT3(i,:) stands for P(y(s)==1 && Z==Z(i))
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==s))==Y(k)),find(vecObs(:,3)==I(i))) = ones(sum(vecUnobs(:,find(Z==s))==Y(k)),sum(vecObs(:,3)==I(i)));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT5(i,:) = Y*MEANMAT;
    end
    
    for i = 1:sizeI-1
        %P(y(s)==1 && I==I(i+1))/Pr(I==I(i+1)) >= P(y(s)==1 && I==I(i))/Pr(I==I(i))
        % which is equivalent to
        %P(y(s)==1 && I==I(i+1))*Pr(I==I(i)) >= P(y(s)==1 && I==I(i))*Pr(I==I(i+1))
        MIV(i,:) = MAT5(i+1,:)*(sum(sum(sum(obs(:,:,I==I(i))))))...
            - MAT5(i,:)*(sum(sum(sum(obs(:,:,I==I(i+1))))));
    end
    MIVvec = zeros(1,sizeI-1);
    
    otherwise
    MIV = [];
    MIVvec = [];
end

%% compatibility with observed probabilities obs
MAT = zeros(sizeY*sizeZ*sizeI,sizeY^sizeZ*sizeY*sizeZ*sizeI);
for i = 1:sizeY*sizeZ*sizeI
    hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
    hlp(:,i) = ones(sizeY^sizeZ,1);
    MAT(i,:) = reshape(hlp,1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
end


%reshape the 3D array obs into vobs so that the ordering is compatible with
%allcomb function
hlp = reshape(obs(:,:,1)',1,[]);
for i = 1:sizeI
    if i ~= sizeI
        hlp = [hlp;reshape(obs(:,:,i+1)',1,[])];
    end
end
vobs = reshape(hlp,1,sizeY*sizeZ*sizeI);


%% E(Y(s))

hlp2 = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
ATEMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);
%take only t-th column of vecUnobs where the value of Y is 1
for i = 1:sizeY
    hlp2 = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
    hlp2(find(vecUnobs(:,find(Z==s))==Y(i)),:) = ones(sum(vecUnobs(:,find(Z==s))==Y(i)),sizeY*sizeZ*sizeI);
    ATEMAT(i,:) = reshape(hlp2,1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
end
%ATE = reshape(hlp2,1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
ATE1 = Y*ATEMAT;


%% 
INEQUALITIES = [-MTS;-MIV];
INEQvec = [MTSvec MIVvec];
EQUALITIES = [MAT];
EQvec =  vobs;

if mtr == 1
    EQUALITIES = [EQUALITIES;MTR;SUPP];
    EQvec = [EQvec MTRvec SUPPvec];
else
    EQUALITIES = [EQUALITIES;SUPP];
    EQvec = [EQvec SUPPvec];
    INEQUALITIES = [INEQUALITIES;MTR];
    INEQvec = [INEQvec MTRvec];  
end




%% MTS for t


%MTS assumptions
%monotone treatment response
%for all t1>=t2: y(t1)>=y(t2)
%monotone treatment selection
%for all t,z1>=z2: E(y(t)|z=z1) >=E(y(t)|z=z2)
switch mts
    case 1
    %MTS (unconditional)
    %inequality is stored in MTS, so that MTS*pi >=0
    MTS = zeros(sizeZ-1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT3 is auxilliary matrix
    MAT3 = zeros(sizeZ,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
    
    for i = 1:sizeZ
        %the i-th row in MAT3(i,:) stands for P(y(t)==1 && Z==Z(i))
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);            
        for k = 1:sizeY
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==t))==Y(k)),find(vecObs(:,2)==Z(i))) = ones(sum(vecUnobs(:,find(Z==t))==Y(k)),sum(vecObs(:,2)==Z(i)));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT3(i,:) = Y*MEANMAT;  
    end


    for i = 1:sizeZ-1
        %P(y(t)==1 && Z==Z(i+1))/Pr(Z==Z(i+1)) >= P(y(t)==1 && Z==Z(i))/Pr(Z==Z(i))
        % which is equivalent to
        %P(y(t)==1 && Z==Z(i+1))*Pr(Z==Z(i)) >= P(y(t)==1 && Z==Z(i))*Pr(Z==Z(i+1))
        MTS(i,:) = MAT3(i+1,:)*(sum(sum(sum(obs(:,Z==Z(i),:)))))...
            - MAT3(i,:)*(sum(sum(sum(obs(:,Z==Z(i+1),:)))));
    end
    MTSvec = zeros(1,sizeZ-1);

    case 2
    %MTS (conditional)
    %inequality is stored in MTS, so that MTS*pi >=0
    MTS = zeros(sizeI*(sizeZ-1),(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT3 is auxilliary matrix
    MAT3 = zeros(sizeZ,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);

for j = 1:sizeI    
    for i = 1:sizeZ
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);            
        for k = 1:sizeY
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==t))==Y(k)),find((vecObs(:,2)==Z(i)) .* (vecObs(:,3)==I(j)))) = ones(sum(vecUnobs(:,find(Z==t))==Y(k)),sum((vecObs(:,2)==Z(i)) .* (vecObs(:,3)==I(j))));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT3(i,:) = Y*MEANMAT;   
    end


    for i = 1:sizeZ-1
        %P(y(t)==1 && Z==Z(i+1) && I==I(j))/Pr(Z==Z(i+1) && I==I(j)) >= P(y(t)==1 && Z==Z(i) && I==I(j))/Pr(Z==Z(i) && I==I(j))
        % which is equivalent to
        %P(y(t)==1 && Z==Z(i+1) && I==I(j))*Pr(Z==Z(i) && I==I(j)) >= P(y(t)==1 && Z==Z(i) && I==I(j))*Pr(Z==Z(i+1) && I==I(j))
        MTS((j-1)*(sizeZ-1)+i,:) = MAT3(i+1,:)*(sum(sum(sum(obs(:,Z==Z(i),I==I(j))))))...
            - MAT3(i,:)*(sum(sum(sum(obs(:,Z==Z(i+1),I==I(j))))));
    end
end
    MTSvec = zeros(1,sizeI*(sizeZ-1));
    
    otherwise
    MTS = [];
    MTSvec = [];
end

%% MIV for t

switch miv
    case 1
    %MIV (unconditional)
    %monotone IV
    %inequality is stored in MIV, so that MIV*pi >=0
    MIV = zeros(sizeI-1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);%MTS
    %MAT5 is auxilliary matrix
    MAT5 = zeros(sizeI,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
    
    for i = 1:sizeI
        MEANMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI); 
        for k = 1:sizeY
            %the i-th row in MAT3(i,:) stands for P(y(t)==1 && Z==Z(i))
            hlp = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
            hlp(find(vecUnobs(:,find(Z==t))==Y(k)),find(vecObs(:,3)==I(i))) = ones(sum(vecUnobs(:,find(Z==t))==Y(k)),sum(vecObs(:,3)==I(i)));
            MEANMAT(k,:) = reshape(hlp,1,(sizeY^sizeZ)*sizeY*sizeZ*sizeI);
        end
            MAT5(i,:) = Y*MEANMAT;
    end
    
    for i = 1:sizeI-1
        %P(y(t)==1 && I==I(i+1))/Pr(I==I(i+1)) >= P(y(t)==1 && I==I(i))/Pr(I==I(i))
        % which is equivalent to
        %P(y(t)==1 && I==I(i+1))*Pr(I==I(i)) >= P(y(t)==1 && I==I(i))*Pr(I==I(i+1))
        MIV(i,:) = MAT5(i+1,:)*(sum(sum(sum(obs(:,:,I==I(i))))))...
            - MAT5(i,:)*(sum(sum(sum(obs(:,:,I==I(i+1))))));
    end
    MIVvec = zeros(1,sizeI-1);
    
    otherwise
    MIV = [];
    MIVvec = [];
end

%% E(Y(t))

hlp2 = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
ATEMAT = zeros(sizeY,sizeY^sizeZ*sizeY*sizeZ*sizeI);
%take only t-th column of vecUnobs where the value of Y is 1
for i = 1:sizeY
    hlp2 = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
    hlp2(find(vecUnobs(:,find(Z==t))==Y(i)),:) = ones(sum(vecUnobs(:,find(Z==t))==Y(i)),sizeY*sizeZ*sizeI);
    ATEMAT(i,:) = reshape(hlp2,1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
end
%ATE = reshape(hlp2,1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
ATE2 = Y*ATEMAT;

%probabilities must be in [0,1]
ze = zeros(1,sizeY^sizeZ*sizeY*sizeZ*sizeI);
on = ones(1,sizeY^sizeZ*sizeY*sizeZ*sizeI);

options = optimset('linprog');
%chose simplex as it can give us exact(!) zero
options = optimset(options,'TolFun',1e-8,'Simplex','on','LargeScale','off','Display','off');


if mtr == 1
    EQUALITIES = [EQUALITIES];
    EQvec = [EQvec];
else
    INEQUALITIES = [INEQUALITIES;MTR];
    INEQvec = [INEQvec MTRvec];        
end


INEQUALITIES = [INEQUALITIES;-MTS;-MIV];
INEQvec = [INEQvec MTSvec MIVvec];

%% Calculate bounds
[sol1,fval1,exitflag1] = linprog(ATE2-ATE1,INEQUALITIES,INEQvec,EQUALITIES,EQvec,ze,on,[],options);
[sol2,fval2,exitflag2] = linprog(-ATE2+ATE1,INEQUALITIES,INEQvec,EQUALITIES,EQvec,ze,on,[],options);

[x,fval,exitflag,output,lambda] = linprog(-ATE2+ATE1,INEQUALITIES,INEQvec,EQUALITIES,EQvec,ze,on,[],options);

lb = fval1;
ub = -fval2;




