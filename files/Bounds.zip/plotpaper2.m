

%%
%matrix SUPP stores so called "support restrictions", it is a restriction
%that every individual has a deterministic (yet unknown) function from the
%space of treatments to the space of outcomes
SUPP = ones(sizeY^sizeZ,sizeY*sizeZ*sizeI);
for i = 1:sizeY
    for j = 1:sizeZ
        for k = 1:sizeI
            %set penalty equal to zero only to those pairs of obs-s and
            %unobser-s that are compatible. If I observe some fraction of
            %people with (Y,Z) equal to (0,1), it means that these people
            %will always have Y(1)=1, regardless of what Y(0) or Y(2) is.
            %find those rows in vecUnobs for which there is Y(i) in the
            %j-th column.
            where = find(vecUnobs(:,j) == Y(i));
            %pick column which corresponds to observed value (i,j,k)
            SUPP(where,(i-1)*sizeZ*sizeI + (j-1)*sizeI+k) = zeros(length(where),1);
        end
    end
end
%%
%matrix MTR stores the restriction that for every individual, outcome must
%be monotonous in potential outcomes.
    MTR = zeros(sizeY^sizeZ,sizeY*sizeZ*sizeI);
    check = zeros(sizeY^sizeZ,1); 
    for i = 1:sizeY^sizeZ
        for j = 1:sizeZ-1
            if vecUnobs(i,j)>vecUnobs(i,j+1)
            check(i) =  1;
            end
        end
    end
    %put a penalty of one to the corresponding rows (those where MTR is violated)
    MTR(find(check),:) = ones(sum(check),sizeY*sizeZ*sizeI);
%%

%reshape the 3D array obs into vobs so that the ordering is compatible with
%allcomb function
hlp = reshape(obs(:,:,1)',1,[]);
for i = 1:sizeI
    if i ~= sizeI
        hlp = [hlp;reshape(obs(:,:,i+1)',1,[])];
    end
end
vobs = reshape(hlp,1,sizeY*sizeZ*sizeI);


%%

F = figure;
maxfig(F,1);


[row_supp,col_supp] = find(1-SUPP');
[row_supp1,col_supp1] = find(SUPP');
so = size(vecObs,1);
su = size(vecUnobs,1);

s=0; t=1; mtr=1; mts=1; miv=1; supp=1;
[lb,ub,exitflag1,exitflag2,sol1,sol2] = ateffect(s,t,obs,mtr,mts,miv,supp);
sol1 = reshape(sol1,size(vecUnobs,1),[]);
sol2 = reshape(sol2,size(vecUnobs,1),[]);

[row_supp,col_supp] = find(1-SUPP');
[row_supp1,col_supp1] = find(SUPP');
[row_mtr,col_mtr] = find((1-SUPP').*(MTR'));
so = size(vecObs,1);
su = size(vecUnobs,1);

reset(gca);
a = gca;
scatter(row_supp,col_supp,100,'black','filled')
hold on;
scatter(row_supp1,col_supp1,250,[0.95 0.95 0.95],'Marker','x','LineWidth',2)
hold on;
scatter(row_mtr,col_mtr,250,'red','Marker','x','LineWidth',2)
hold on;
scatter(row_supp1,col_supp1,100,[0.95 0.95 0.95],'filled')

for i = 1:su
    for j = 1:so
        text(j,i-0.2,num2str(round(1000*sol2(i,j))/1000),'FontSize',12,'HorizontalAlignment','center');
    end
end

xticker = [repmat('(',[so,1]),num2str(vecObs(:,1))];
yticker = [repmat('(y(0)=',[su,1]),num2str(vecUnobs(:,1))];

for i = 1:2
    xticker = [xticker,repmat(',',[so,1]), num2str(vecObs(:,i+1))];
end
for i = 1:sizeZ-1
    yticker = [yticker,repmat(',y(1)=',[su,1]), num2str(vecUnobs(:,i+1))];
end

xticker = [xticker,repmat([')'],[so,1])];
yticker = [yticker,repmat(')',[su,1])];


set(a,'FontSize',15)
%set(a,'Title',text('String','Compatibility with Observed Data','Color','black','FontSize',20,'FontWeight','bold'))
%set(a,'Title',text('String',['\textsf{ The Joint Distribution - Max Upper Bound on ATE under MTR+MTS+MIV = }',round(10000*eval(num2str(ub)))/10000],'Color','black','FontSize',20,'FontWeight','bold','Interpreter','latex'))
set(a,'Title',text('String',['\textsf{ Joint Distribution - Max Upper Bound on ATE under MTR+MTS+MIV = 0.3646}'],'Color','black','FontSize',20,'FontWeight','bold','Interpreter','latex'))
set(get(a,'XLabel'),'String',{'';'';'\textsf{ Observed} $(y,z,v)$'},'Color','black','FontSize',20,'Interpreter','latex')
set(get(a,'YLabel'),'String','\textsf{Unobserved} $\left(y(0),y(1)\right)$','Color','black','FontSize',20,'Interpreter','latex')
set(a,'Xlim',[0.5,so+0.5])
set(a,'Ylim',[0.5,su+1])
set(a,'XTick',[1:so])
set(a,'YTick',[1:su])
set(a,'XTickLabel',xticker)
set(a,'YTickLabel',yticker)

hleg = legend('Observed and unobserved component are compatible','Observed and unobserved component are not compatible','Ruled out by the MTR assumption');
set(hleg,'Location','NorthWest')

M = findobj(hleg,'type','patch'); % Find objects of type 'patch'
set(M,'MarkerSize', 10,'LineWidth',2)

%
%set(gca,'yticklabel',[], 'xticklabel', []) %Remove tick labels
set(gca, 'xticklabel', [])

% Get tick positions
yTicks = get(gca,'ytick');
xTicks = get(gca, 'xtick');

% Reset the XTicklabels onto multiple lines, 2nd line being twice of first
minY = min(yTicks);
% You will have to adjust the offset based on the size of figure
VerticalOffset = 0.6;
HorizontalOffset = 0.0;

for xx = 1:length(xTicks)
% Create a text box at every Tick label position
% String is specified as LaTeX string and other appropriate properties are set
%text(xTicks(xx) - HorizontalOffset, minY - VerticalOffset, ['$$\begin{array}{c}',xticker(xx,:),'\\',num2str(round(1000*vobs(xx))/1000),'\end{array}$$'],'FontSize',15, 'Interpreter', 'latex','FontWeight','bold')
text(xTicks(xx) - HorizontalOffset, minY - VerticalOffset, [xticker(xx,:)],'FontSize',15,...
                    'HorizontalAlignment','center')
text(xTicks(xx) - HorizontalOffset, minY - 0.8, [num2str(round(1000*vobs(xx))/1000)],'FontSize',12,...
                    'HorizontalAlignment','center')
% {c} specifies that the elements of the different lines will be center
% aligned. It may be replaced by {l} or {r} for left or right alignment
end

xlabh = get(gca,'XLabel');
set(xlabh,'Units','data');
set(xlabh,'Position',get(xlabh,'Position') + [0 0.1 0])

%% save to file
% 
%     set(gcf, 'PaperPositionMode', 'auto');
%    print -depsc2 PlotFigure1.eps

