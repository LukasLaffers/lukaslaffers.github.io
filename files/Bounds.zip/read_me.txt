copy the content of this directory
and run "runthis.m"